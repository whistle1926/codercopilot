






export type BankFeedStatus = 'Connected' | 'Disconnected' | 'Expiring Soon' | 'Needs Reconnection';

export type BankFeed = {
  id: string;
  bankName: string;
  status: BankFeedStatus;
};

export type UnpaidInvoice = {
  invoiceNumber: string;
  dueDate: string;
  amount: number;
};

export type DayOfWeek = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export type TimeLimit = {
    day: DayOfWeek;
    startTime: string; // "HH:MM"
    endTime: string;   // "HH:MM"
};

export type CostLimits = {
    daily?: number;
    weekly?: number;
    monthly?: number;
};

export type UserStatus = 'Online' | 'Offline' | 'Busy';

export type QuestionnaireSubmission = {
    companyId: string;
    projectName?: string;
    projectDescription?: string;
    professionalType: string[];
    tasks: string[];
    workload: string;
    software?: string[];
    otherSoftware?: string;
    technologies?: string;
    skills: string;
    submissionDate: string;
};

export type HourRequest = {
  id: string;
  companyId: string;
  staffId: string;
  timeLimits: TimeLimit[];
  status: 'Pending Approval' | 'Approved' | 'Rejected';
  requestDate: string;
};

export type ProjectUpdate = {
    id: string;
    date: string;
    author: string;
    content: string;
};

export type Client = {
  id: string;
  name: string;
  tradingName?: string;
  referenceNo: string;
  vatNumber: string;
  utrNo?: string;
  currency?: 'GBP' | 'EUR';
  vatBasis?: 'accrual' | 'cash';
  companyType?: 'ltd' | 'sole-trader' | 'partnership';
  hmrcStatus: 'Connected' | 'Disconnected';
  vatReturnDueDate: string;
  vatReturnDays: number;
  mtdIncomeTaxDueDate: string;
  mtdIncomeTaxDays: number;
  bankFeeds: BankFeed[];
  bankFeedStatus: BankFeedStatus; // Keep for overview, can be derived
  mainContactPerson: string;
  email: string;
  password?: string;
  phoneNumber: string;
  address: string;
  zipcode: string;
  country?: string;
  unpaidInvoices: UnpaidInvoice[];
  status: 'Active' | 'Pending Approval' | 'Declined' | 'Inactive';
  cashBalance?: number;
  timezone?: string;
  online?: boolean; // This will be deprecated by user-selectable status
  questionnaireCompleted?: boolean;
  assignedTeamLeadId?: string | null;
  allocatedStaffIds?: string[];
  projectUpdates?: ProjectUpdate[];
};


export interface LineItem {
  id: number;
  description: string;
  quantity: number;
  unitPrice: number;
  vatRate: string;
  productName?: string;
}

export interface MtdDetails {
  includeInMtd: boolean;
  incomeSource: string;
  allowYapilyPayment: boolean;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  client: Client;
  date: string;
  dueDate: string;
  lineItems: LineItem[];
  discount: number;
  totals: {
    net: number;
    vat: number;
    gross: number;
  };
  status: 'Draft' | 'Sent' | 'Paid' | 'Overdue' | 'Credit Note';
  mtdDetails: MtdDetails;
  creditNoteFor?: string; // Original invoice number
}


export type IncomeSource = {
  id: string;
  name:string;
};

export type NominalCode = {
  id: string;
  name: string;
  code: string;
}

export type AdditionalDescription = {
    id: string;
    name: string;
}

export type ProductCategory = {
  id: string;
  name: string;
};

export type Product = {
  id: string;
  name: string;
  description: string;
  unitPrice: number;
  vatRate: string;
  type: 'Product' | 'Service';
  categoryId: string;
};

export type BankTransaction = {
  id: string;
  bankId: string;
  date: string;
  description: string;
  debit: number | null;
  credit: number | null;
  balance: number;
  additionalDescription: string;
  nominalCode: string;
  incomeSource: string;
  includeInMtd: boolean;
  isApproved: boolean;
};

export type ConnectionHistory = {
  id: string;
  bankId: string;
  dateTime: string;
  balance: number;
};

export type Reconciliation = {
  id: string;
  bankId: string;
  fromDate: string | null;
  toDate: string;
  statementBalance: number;
  calculatedBalance: number;
};

export type DownloadHistory = {
  id: string;
  fileName: string;
  date: string;
};

export type VatExportHistory = {
    id: string;
    fileName: string;
    date: string;
    content: string; // CSV content or JSON of transactions
    type: 'Download' | 'Email' | 'HMRC Submission';
    totals?: VatTotals;
}

export type UploadedDocument = {
  id: string;
  referenceName: string;
  fileName: string;
  uploadDate: string;
  fileType: string;
  fileSize: number;
};

export type License = {
  id: string;
  key: string;
  purchaseDate: string;
  assignedToClientId: string | null;
};

export type PricingTier = {
    id: string;
    name: string;
    total: number;
    licenses: number;
    pricePer: 'month' | 'year';
    pricePerLicense: number;
    description: string;
    isMostPopular: boolean;
    mostPopularText?: string;
    isFeatured: boolean;
    featuredOfferText?: string;
    bannerText?: string;
    icon: 'Star' | 'Zap' | 'Flame';
    features: string[];
    displayOnLicensesPage: boolean;
    displayOnRegistrationPage: boolean;
};

export type VatRate = 
  | '20' 
  | '5' 
  | '0' // Zero Rated
  | 'exempt'
  | 'no-vat'
  | 'drc-20' // Domestic Reverse Charge 20%
  | 'drc-5';  // Domestic Reverse Charge 5%

export type VatTransaction = {
  id: string;
  transactionType: string;
  customer: string;
  date: string;
  nominalCode: string;
  netAmount: number;
  vatAmount: number;
  vatPercentage: VatRate | string; // Keep string for backward compatibility with old values
  subjectToCIS: 'Y' | 'N';
  includeInMtd: boolean;
  details?: string;
  documentReference?: string;
  additionalReference?: string;
  dept?: string;
  attachment?: string | null;
}

export interface VatTotals {
    box1: number;
    box2: number;
    box3: number;
    box4: number;
    box5: number;
    box6: number;
    box7: number;
    box8: number;
    box9: number;
}

export type VatReturn = {
  id: string;
  clientId: string;
  periodStart: string;
  periodEnd: string;
  openFrom: string;
  closesOn: string;
  dueDate: string;
  status: 'Due' | 'Filed';
  submittedDate?: string;
  submittedBy?: string;
  vatAmountDue?: number;
  vatAmountRefundable?: number;
};

export type LandlordTaxReturn = {
    id: string;
    taxYear: string;
    taxpayerName: string;
    utr: string;
    niNumber: string;
    address: string;
    propertyType: 'Residential' | 'FHL' | 'Commercial' | 'Mixed';
    rentalIncome: number | '';
    reversePremiums: number | '';
    propertyRepairs: number | '';
    maintenance: number | '';
    utilities: number | '';
    insurance: number | '';
    managementFees: number | '';
    loanInterest: number | '';
    allowableExpenses: number | '';
    capitalAllowance: number | '';
    privateUseAdjustment: number | '';
    totalExpenses: number | '';
    netProfitOrLoss: number | '';
    adjustment: number | '';
    taxableProfit: number | '';
    taxDue: number | '';
    paymentDeadline: string;
    status: 'Draft' | 'Submitted';
};

export type LandlordSubmissionHistory = {
    id: string;
    submissionDate: string;
    propertyAddress: string;
    taxableProfit: number;
    taxDue: number;
    hmrcReference: string;
    submittedReturn: LandlordTaxReturn;
};

export type SelfEmployedTaxReturn = {
    id: string;
    status: 'Draft' | 'Submitted';
    // Taxpayer Details
    taxpayerName: string;
    utr: string;
    niNumber: string;
    businessName: string;
    accountingPeriodStartDate: string;
    accountingPeriodEndDate: string;
    // Income
    grossTurnover: number | '';
    otherBusinessIncome: number | '';
    // Allowable Expenses
    costOfGoods: number | '';
    wagesAndStaffCosts: number | '';
    rentRatesPowerInsurance: number | '';
    repairsAndMaintenance: number | '';
    phoneInternetOfficeCosts: number | '';
    travelAndSubsistence: number | '';
    professionalFees: number | '';
    advertisingAndMarketing: number | '';
    otherAllowableExpenses: number | '';
    consolidatedExpenses: number | '';
    // Adjustments
    disallowableExpenses: number | '';
    capitalAllowances: number | '';
    privateUseAdjustments: number | '';
    balancingCharges: number | '';
    // Profit Calculations
    lossBroughtForward: number | '';
    // Other Income (simplified for this form)
    employmentIncome: number | '';
    propertyIncome: number | '';
    dividends: number | '';
    interest: number | '';
    // Tax Reliefs
    personalAllowance: number | '';
    tradingAllowance: number | '';
    otherReliefs: number | '';
    // Tax Due
    paymentsOnAccount: number | '';

    // Calculated Fields
    totalBusinessIncome: number | '';
    totalExpenses: number | '';
    netProfitBeforeTax: number | '';
    adjustedTaxableProfit: number | '';
    incomeTaxDue: number | '';
    class2Nics: number | '';
    class4Nics: number | '';
};

export type SelfEmployedSubmissionHistory = {
    id: string;
    submissionDate: string;
    businessName: string;
    taxableProfit: number;
    taxDue: number;
    hmrcReference: string;
    submittedReturn: SelfEmployedTaxReturn;
};

export type DeadlineDate = {
    id: string;
    name: string;
    periodEnd: string;
    openFrom: string;
    closes: string;
    dueDate: string;
};

export type Comment = {
    id: string;
    author: string;
    text: string;
    timestamp: string;
};

export type SubTask = {
    id: string;
    title: string;
    completed: boolean;
};

export type TaskStatus = 'To Do' | 'In Progress' | 'Done' | 'Waiting for Approval' | 'Approved' | 'Rejected' | 'Paid';
export type TaskPriority = 'Low' | 'Medium' | 'High';

export interface Task {
    id: string;
    title: string;
    details: string;
    dueDate?: Date;
    status: TaskStatus;
    priority: TaskPriority;
    hoursLogged: number;
    startTime?: number; // Unix timestamp
    pausedTime?: number; // Total time paused in milliseconds
    comments: Comment[];
    subTasks: SubTask[];
    completionDate?: string;
    cost: number;
};

export type Skill = {
    name: string;
    level: 'Expert' | 'Advanced' | 'Intermediate';
    years: number;
}

export type StaffMember = {
  id: string;
  name: string;
  email?: string;
  password?: string;
  role: string;
  location: string;
  avatarUrl: string;
  skills: string[];
  technicalSkills: Skill[];
  softSkills: Skill[];
  rate: number;
  costRate?: number;
  availability: 'Available For Hire' | 'Currently Hired';
  hiredBy: string[] | null; // Client IDs
  hiredByHistory?: string[]; // Array of client IDs
  lastActive: string;
  experience: string;
  rating: number;
  reviews: number;
  projects: number;
  joinedDate: string;
  about: string;
  verified: boolean;
  premium: boolean;
  isVisible: boolean;
  timeLimits?: TimeLimit[];
  costLimits?: CostLimits;
  isLocked?: boolean;
  timezone?: string;
  status: UserStatus;
  isTeamLead?: boolean;
  showPricing?: boolean;
};

export type CreditPackage = {
    id: string;
    price: number;
    description: string;
};

export interface ChatMessage {
  id: string;
  senderId: string; // ID of the client or staff member
  sender: 'user' | 'staff';
  text: string;
  timestamp: string;
  read: boolean;
}
    
