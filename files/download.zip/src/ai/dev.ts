import { config } from 'dotenv';
config();

import '@/ai/flows/parse-uploaded-invoices.ts';
import '@/ai/flows/categorize-transaction.ts';
