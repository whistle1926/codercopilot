// This is a server-side file.
'use server';

/**
 * @fileOverview Parses uploaded invoice documents using AI to extract and verify key information.
 *
 * - parseUploadedInvoice - Function to initiate the invoice parsing flow.
 * - ParseUploadedInvoiceInput - Input type for the parseUploadedInvoice function.
 * - ParseUploadedInvoiceOutput - Return type for the parseUploadedInvoice function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ParseUploadedInvoiceInputSchema = z.object({
  invoiceDataUri: z
    .string()
    .describe(
      "The invoice document as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type ParseUploadedInvoiceInput = z.infer<typeof ParseUploadedInvoiceInputSchema>;

const ParseUploadedInvoiceOutputSchema = z.object({
  customer: z.string().describe('The name of the customer.'),
  invoiceNumber: z.string().describe('The invoice number.'),
  date: z.string().describe('The invoice date.'),
  dueDate: z.string().describe('The invoice due date.'),
  lineItems: z.array(
    z.object({
      description: z.string().describe('The description of the item.'),
      quantity: z.number().describe('The quantity of the item.'),
      unitPrice: z.number().describe('The unit price of the item.'),
      discount: z.number().describe('The discount applied to the item.'),
      vatRate: z.string().describe('The VAT rate applied to the item.'),
    })
  ).describe('The line items in the invoice.'),
  totals: z.object({
    net: z.number().describe('The net amount of the invoice.'),
    vat: z.number().describe('The VAT amount of the invoice.'),
    gross: z.number().describe('The gross amount of the invoice.'),
  }).describe('The totals for the invoice.'),
});
export type ParseUploadedInvoiceOutput = z.infer<typeof ParseUploadedInvoiceOutputSchema>;

export async function parseUploadedInvoice(input: ParseUploadedInvoiceInput): Promise<ParseUploadedInvoiceOutput> {
  return parseUploadedInvoiceFlow(input);
}

const parseUploadedInvoicePrompt = ai.definePrompt({
  name: 'parseUploadedInvoicePrompt',
  input: {schema: ParseUploadedInvoiceInputSchema},
  output: {schema: ParseUploadedInvoiceOutputSchema},
  prompt: `You are an expert accountant specializing in extracting information from invoices. Extract the following information from the invoice document provided.

Invoice Document: {{media url=invoiceDataUri}}

Consider all the text in the document, and provide a structured JSON output.
`,
});

const parseUploadedInvoiceFlow = ai.defineFlow(
  {
    name: 'parseUploadedInvoiceFlow',
    inputSchema: ParseUploadedInvoiceInputSchema,
    outputSchema: ParseUploadedInvoiceOutputSchema,
  },
  async input => {
    const {output} = await parseUploadedInvoicePrompt(input);
    return output!;
  }
);
