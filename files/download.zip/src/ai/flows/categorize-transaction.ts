
// This is a server-side file.
'use server';

/**
 * @fileOverview Categorizes a bank transaction based on historical data using AI.
 *
 * - categorizeTransaction - Function to initiate the transaction categorization flow.
 * - CategorizeTransactionInput - Input type for the categorizeTransaction function.
 * - CategorizeTransactionOutput - Return type for the categorizeTransaction function.
 */

import {ai} from '@/ai/genkit';
import type { BankTransaction } from '@/lib/types';
import {z} from 'genkit';


const BankTransactionSchema = z.object({
  id: z.string(),
  bankId: z.string(),
  date: z.string(),
  description: z.string(),
  debit: z.number().nullable(),
  credit: z.number().nullable(),
  balance: z.number(),
  additionalDescription: z.string(),
  nominalCode: z.string(),
  incomeSource: z.string(),
  includeInMtd: z.boolean(),
});

const CategorizeTransactionInputSchema = z.object({
  transaction: BankTransactionSchema.describe("The new, uncategorized transaction to be processed."),
  history: z.array(BankTransactionSchema).describe("A list of previously categorized transactions to learn from."),
});
export type CategorizeTransactionInput = z.infer<typeof CategorizeTransactionInputSchema>;

const CategorizeTransactionOutputSchema = z.object({
  additionalDescription: z.string().describe("The suggested additional description for the transaction."),
  nominalCode: z.string().describe("The suggested nominal code for the transaction."),
  incomeSource: z.string().describe("The suggested income source for the transaction."),
});
export type CategorizeTransactionOutput = z.infer<typeof CategorizeTransactionOutputSchema>;

export async function categorizeTransaction(input: CategorizeTransactionInput): Promise<CategorizeTransactionOutput> {
  return categorizeTransactionFlow(input);
}

const categorizeTransactionPrompt = ai.definePrompt({
  name: 'categorizeTransactionPrompt',
  input: {schema: CategorizeTransactionInputSchema},
  output: {schema: CategorizeTransactionOutputSchema},
  prompt: `You are an expert accountant who is brilliant at categorizing bank transactions.
    You will be given a new transaction and a history of already categorized transactions.
    Your task is to analyze the new transaction's description and determine the most appropriate 'additionalDescription', 'nominalCode', and 'incomeSource' based on how similar transactions have been categorized in the past.

    New Transaction to categorize:
    - Description: {{{transaction.description}}}
    - Debit: {{{transaction.debit}}}
    - Credit: {{{transaction.credit}}}

    Historical transactions to learn from:
    {{#each history}}
    - Description: {{{this.description}}}, Additional Description: {{{this.additionalDescription}}}, Nominal Code: {{{this.nominalCode}}}, Income Source: {{{this.incomeSource}}}
    {{/each}}

    Based on the history, provide the most likely categorization for the new transaction.
`,
});

const categorizeTransactionFlow = ai.defineFlow(
  {
    name: 'categorizeTransactionFlow',
    inputSchema: CategorizeTransactionInputSchema,
    outputSchema: CategorizeTransactionOutputSchema,
  },
  async input => {
    // If history is empty, we can't make a prediction.
    if (input.history.length === 0) {
        return {
            additionalDescription: '',
            nominalCode: '',
            incomeSource: '',
        }
    }
    const {output} = await categorizeTransactionPrompt(input);
    return output!;
  }
);
