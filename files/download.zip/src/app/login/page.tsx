

"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CoderCoPilotLogo } from '@/components/icons';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import type { Client } from '@/lib/types';
import { useActiveClient } from '@/hooks/use-active-client';
import { clients as initialClients } from '@/lib/data';

function SignUpForm({ onLoginClick }: { onLoginClick: () => void }) {
  const router = useRouter();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
        title: "Details Submitted",
        description: "Please book your setup call on the next page.",
    });
    router.push('/signup/schedule');
  };
  
  return (
    <Card className="w-full max-w-sm bg-muted/50 shadow-2xl">
      <CardHeader>
        <CardTitle className="text-2xl">Sign Up</CardTitle>
        <CardDescription>
          Create an account to get started.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={handleSubmit}>
           <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              type="text"
              placeholder="John Doe"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="m@example.com"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" required />
          </div>
          <Button type="submit" className="w-full">
            Sign Up
          </Button>
        </form>
        <div className="mt-4 text-center text-sm">
          Already have an account?{' '}
          <Button variant="link" onClick={onLoginClick} className="p-0 h-auto">
            Login
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function LoginForm({ onSignUpClick }: { onSignUpClick: () => void }) {
  const router = useRouter();
  const { toast } = useToast();
  const { setActiveClient } = useActiveClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleCompanyLogin = (e: React.FormEvent) => {
    e.preventDefault();
    let allClients: Client[] = [];
    try {
        const storedClients = sessionStorage.getItem('clients');
        allClients = storedClients ? JSON.parse(storedClients) : initialClients as Client[];
        if (allClients.length === 0) {
            allClients = initialClients as Client[];
            sessionStorage.setItem('clients', JSON.stringify(allClients));
        }
    } catch {
        allClients = initialClients as Client[];
    }

    const foundClient = allClients.find(c => c.email === email && c.password === password);

    if (foundClient) {
      sessionStorage.setItem('activeClientId', foundClient.id);
      setActiveClient(foundClient);
      router.push('/dashboard');
    } else {
        toast({
            variant: 'destructive',
            title: 'Login Failed',
            description: 'Invalid company email or password.',
        });
    }
  };
  
  const handleSuperAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'super.admin@example.com' && password === 'superadmin123') {
      sessionStorage.removeItem('activeClientId');
      setActiveClient(null);
      router.push('/dashboard/super-admin');
    } else {
      toast({
        variant: 'destructive',
        title: 'Login Failed',
        description: 'Invalid Super Admin credentials.',
      });
    }
  };

  return (
    <Card className="w-full max-w-sm bg-muted/50 shadow-2xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Account Login</CardTitle>
        <CardDescription>
          Welcome back! Please enter your details.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email-login">Email</Label>
            <Input
              id="email-login"
              type="email"
              placeholder="Enter your email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password-login">Password</Label>
            <Input 
                id="password-login" 
                type="password" 
                required 
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Button onClick={handleCompanyLogin} className="w-full">
                Login as Company
            </Button>
             <Button onClick={handleSuperAdminLogin} className="w-full" variant="secondary">
                Login as Super Admin
            </Button>
          </div>
        </form>
        <div className="mt-4 text-center text-sm">
          Don't have an account?{' '}
          <Button variant="link" onClick={onSignUpClick} className="p-0 h-auto">
            Sign Up
          </Button>
        </div>
        <div className="mt-4 text-center text-sm">
          Are you a staff member?{' '}
          <Button variant="link" asChild className="p-0 h-auto">
            <Link href="/staff-login">Login as Staff</Link>
          </Button>
        </div>
         <div className="mt-4 text-center text-sm">
          Are you a Team Manager?{' '}
          <Button variant="link" asChild className="p-0 h-auto">
            <Link href="/team-manager-login">Login here</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}


function LoginPage() {
  const [showLogin, setShowLogin] = useState(true);

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-white p-4 text-foreground">
        <div className="mb-8">
            <CoderCoPilotLogo className="h-24 w-auto text-primary" />
        </div>
        <div className="mb-8 max-w-3xl text-center">
            <h1 className="text-4xl font-bold text-foreground">
                Build Your Dream Team with Coder Co-Pilot
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
                Coder Co-Pilot is the perfect partner for any AI project, preventing code overload by providing vetted, on-demand tech talent and expert project management.
            </p>
            <p className="mt-4 font-semibold text-lg text-foreground">
                Your growth starts here.
            </p>
        </div>
      {showLogin ? (
          <LoginForm onSignUpClick={() => setShowLogin(false)} />
      ) : (
          <SignUpForm onLoginClick={() => setShowLogin(true)} />
      )}
    </div>
  );
}

export default LoginPage;
    

    



