

"use server";

import type { Client } from "@/lib/types";

// This is a simplified server action. In a real application, you would
// interact with a database. Here, we'll just manipulate an in-memory array.
// For the purpose of this prototype, we won't be persisting the new client
// to the initialClients array in data.ts, but we will return it.

export async function addClient(newClientData: Omit<Client, 'id' | 'hmrcStatus' | 'vatReturnDueDate' | 'mtdIncomeTaxDueDate' | 'bankFeeds' | 'bankFeedStatus' | 'unpaidInvoices' | 'vatReturnDays' | 'mtdIncomeTaxDays' | 'status'>): Promise<Client> {
    
    // In a real app, you'd save to a DB and get a new ID.
    const newId = `client-${Date.now()}`;
    
    const newClient: Client = {
        ...newClientData,
        id: newId,
        hmrcStatus: 'Disconnected',
        vatReturnDays: 999, // Default values
        mtdIncomeTaxDays: 999,
        bankFeeds: [],
        bankFeedStatus: 'Disconnected',
        unpaidInvoices: [],
        // These will be calculated dynamically in the component
        vatReturnDueDate: '', 
        mtdIncomeTaxDueDate: '',
        status: 'Pending Approval'
    };

    // Note: This doesn't actually persist the client in our mock data file,
    // but simulates the creation of a new client object. The frontend
    // will manage adding this to its local state.
    console.log("New client created (simulated):", newClient);
    
    return newClient;
}
