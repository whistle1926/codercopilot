
"use server";

import { format } from 'date-fns';

export async function getHistoricalExchangeRate(apiKey: string, date: Date, sourceCurrency: string): Promise<number> {
    if (!apiKey) {
        throw new Error("Currency API key is not configured.");
    }
    
    const formattedDate = format(date, 'yyyy-MM-dd');
    const url = `http://api.currencylayer.com/historical?access_key=${apiKey}&date=${formattedDate}&currencies=${sourceCurrency},GBP`;

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (!data.success) {
            // currencylayer returns error info in an 'error' object
            if (data.error && data.error.info) {
                 // Free plan only supports USD as source. This is a common error.
                if (data.error.code === 105) {
                    throw new Error(`Your currencylayer plan does not support changing the source currency. It must be USD. (${data.error.info})`);
                }
                throw new Error(`Currency API Error: ${data.error.info}`);
            }
            throw new Error('Failed to fetch exchange rate from API.');
        }

        const quotes = data.quotes;
        const usdToSource = quotes[`USD${sourceCurrency}`];
        const usdToGbp = quotes['USDGBP'];
        
        if (typeof usdToSource !== 'number' || typeof usdToGbp !== 'number') {
             throw new Error(`Could not retrieve valid rates for ${sourceCurrency} and GBP from API response.`);
        }
        
        // Calculate the cross-rate from source to GBP
        const sourceToGbpRate = usdToGbp / usdToSource;
        
        return sourceToGbpRate;

    } catch (error) {
        console.error("Error fetching exchange rate:", error);
        if (error instanceof Error) {
            throw error;
        }
        throw new Error("An unknown error occurred while fetching the exchange rate.");
    }
}
