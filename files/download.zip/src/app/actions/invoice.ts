
"use server";

import { parseUploadedInvoice } from '@/ai/flows/parse-uploaded-invoices';
import type { ParseUploadedInvoiceOutput, ParseUploadedInvoiceInput } from '@/ai/flows/parse-uploaded-invoices';
import { categorizeTransaction } from '@/ai/flows/categorize-transaction';
import type { BankTransaction } from '@/lib/types';


export async function handleParseInvoice(invoiceDataUri: string): Promise<ParseUploadedInvoiceOutput> {
  try {
    const input: ParseUploadedInvoiceInput = { invoiceDataUri };
    const result = await parseUploadedInvoice(input);
    return result;
  } catch (error) {
    console.error('Error in handleParseInvoice action:', error);
    // It's good practice to not expose raw error messages to the client.
    throw new Error('Failed to parse invoice due to a server error.');
  }
}

export async function handleCategorizeTransactions(allTransactions: BankTransaction[]): Promise<BankTransaction[]> {
    const categorizedHistory = allTransactions.filter(t => 
        t.additionalDescription || t.nominalCode || t.incomeSource
    );
    const uncategorized = allTransactions.filter(t => 
        !t.additionalDescription && !t.nominalCode && !t.incomeSource
    );

    if (uncategorized.length === 0) {
        return allTransactions;
    }

    const promises = uncategorized.map(transaction => 
        categorizeTransaction({ transaction, history: categorizedHistory })
            .then(result => ({
                ...transaction,
                additionalDescription: result.additionalDescription,
                nominalCode: result.nominalCode,
                incomeSource: result.incomeSource,
            }))
            .catch(error => {
                console.error(`Failed to categorize transaction ${transaction.id}:`, error);
                // Return original transaction on error
                return transaction; 
            })
    );

    const newlyCategorized = await Promise.all(promises);

    // Merge the results
    const finalTransactions = allTransactions.map(t => {
        const found = newlyCategorized.find(nc => nc.id === t.id);
        return found || t;
    });

    return finalTransactions;
}

