
"use server";

// This is a mock of the VIES VAT number validation service.
// In a real application, this would make a SOAP or REST call to the
// European Commission's VIES service.
// http://ec.europa.eu/taxation_customs/vies/checkVatService.wsdl

interface ValidationResult {
    isValid: boolean;
    message: string;
    name?: string;
    address?: string;
}

export async function verifyVatNumber(vatNumber: string): Promise<ValidationResult> {
    
    // Basic validation
    if (!vatNumber || vatNumber.length < 5) {
        return { isValid: false, message: 'VAT number is too short.' };
    }

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 750));

    // Mock responses based on the provided number
    if (vatNumber.toUpperCase() === 'GB123456789') {
        return { 
            isValid: true, 
            message: 'VAT number is valid.',
            name: 'Innovate Inc.',
            address: '123 Main St, Anytown, 12345'
        };
    }
    
    if (vatNumber.toUpperCase().startsWith('GB')) {
         return { isValid: true, message: 'VAT number is valid (mocked).' };
    }

    if (vatNumber.includes("error")) {
        return { isValid: false, message: 'Invalid VAT number format (mocked).' };
    }

    return { isValid: false, message: 'VAT number could not be validated (mocked).' };
}
