
"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Users, FileText, Landmark, Banknote, Folder, Key, Sparkles, Workflow, ClipboardCheck } from "lucide-react";

const benefits = [
    {
        icon: Users,
        title: "Unified Project Management",
        description: "View and manage all your projects and hired experts from a single, intuitive dashboard. Get a complete overview of deadlines, team progress, and project statuses at a glance."
    },
    {
        icon: Landmark,
        title: "Expert Project Managers",
        description: "Your project is supervised by a highly trained tech project manager, ensuring tasks are managed efficiently and the project stays on track."
    },
    {
        icon: Banknote,
        title: "Flexible On-Demand Teams",
        description: "Scale your team up or down with zero friction. Hire from a pool of vetted professionals for as little or as long as you need, without long-term contracts."
    },
    {
        icon: Sparkles,
        title: "AI-Powered Talent Matching",
        description: "Leverage AI to get matched with the perfect professionals for your project based on your specific technical needs, ensuring the right fit for every task."
    },
    {
        icon: FileText,
        title: "Streamlined Invoicing & Payments",
        description: "Handle all payments and invoicing directly through our secure platform. We streamline the financial side so you can focus on building great products."
    },
    {
        icon: Workflow,
        title: "Seamless Collaboration",
        description: "Integrate our professionals directly into your existing workflow. Our platform provides the tools you need for smooth communication and project management."
    },
    {
        icon: Folder,
        title: "Secure Code & Asset Management",
        description: "Securely upload, store, and access important project assets anytime. Keep everything organized and eliminate the need for separate storage solutions."
    },
    {
        icon: Key,
        title: "Simple & Transparent Billing",
        description: "Easily manage your billing and subscriptions with clear, transparent pricing. Our flexible tiers scale with your needs as your projects grow."
    },
    {
        icon: ClipboardCheck,
        title: "Focus on Quality & Delivery",
        description: "Our platform includes only what you need to build and deliver high-quality tech projects, removing unnecessary complexity and making it easy to use."
    }
];

export default function BenefitsPage() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <main className="container mx-auto px-4 py-16">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-primary">
            A Better Way to Build Your Tech Team
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Our platform is an all-in-one solution for sourcing, managing, and collaborating with on-demand tech experts. Streamline your development process, enhance productivity, and deliver exceptional results with tools built for efficiency.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="bg-primary/10 text-primary p-3 rounded-lg">
                        <Icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-xl">{benefit.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
}
