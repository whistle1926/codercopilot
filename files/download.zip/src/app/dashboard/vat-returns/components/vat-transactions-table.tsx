

"use client";

import { useState, useRef, useEffect, useMemo } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, Check, ChevronsUpDown, Plus, Trash2, User, Undo, Paperclip, XCircle, Calculator, Loader2, Copy, Info } from 'lucide-react';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import type { Client, NominalCode, VatTransaction, VatReturn, VatRate } from '@/lib/types';
import { cn } from '@/lib/utils';
import { format, isWithinInterval } from 'date-fns';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import type { useToast } from '@/hooks/use-toast';
import { Dialog, DialogClose, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { getHistoricalExchangeRate } from '@/app/actions/currency';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

function CurrencyConverterDialog({ 
    open, 
    onOpenChange, 
    onApply,
    toast 
}: { 
    open: boolean, 
    onOpenChange: (open: boolean) => void,
    onApply: (gbpAmount: number) => void,
    toast: ReturnType<typeof useToast>['toast'],
}) {
    const [foreignAmount, setForeignAmount] = useState<number | ''>('');
    const [exchangeRate, setExchangeRate] = useState<number | ''>('');
    const [currency, setCurrency] = useState('EUR');
    const [transactionDate, setTransactionDate] = useState<Date | undefined>(new Date());
    const [isLoading, setIsLoading] = useState(false);

    const gbpAmount = useMemo(() => {
        if (typeof foreignAmount === 'number' && typeof exchangeRate === 'number' && exchangeRate > 0) {
            return foreignAmount * exchangeRate;
        }
        return 0;
    }, [foreignAmount, exchangeRate]);
    
    useEffect(() => {
        const fetchRate = async () => {
            if (transactionDate && currency) {
                setIsLoading(true);
                setExchangeRate(''); // Clear previous rate
                const apiKey = localStorage.getItem('currencyLayerApiKey');
                if (!apiKey) {
                    toast({
                        variant: 'destructive',
                        title: 'API Key Missing',
                        description: 'Please set your currencylayer.com API key in the settings page.',
                    });
                    setIsLoading(false);
                    return;
                }
                
                try {
                    const rate = await getHistoricalExchangeRate(apiKey, transactionDate, currency);
                    setExchangeRate(rate);
                } catch (error) {
                     toast({
                        variant: 'destructive',
                        title: 'Could not fetch exchange rate',
                        description: error instanceof Error ? error.message : 'An unknown error occurred.',
                    });
                } finally {
                    setIsLoading(false);
                }
            }
        };
        fetchRate();

    }, [transactionDate, currency, toast]);

    const handleApply = () => {
        onApply(gbpAmount);
        onOpenChange(false);
        // Reset state
        setForeignAmount('');
        setExchangeRate('');
        setTransactionDate(new Date());
    }

    const handleCopy = () => {
        if (gbpAmount > 0) {
            navigator.clipboard.writeText(gbpAmount.toFixed(2));
            toast({
                title: 'Copied to clipboard',
                description: `£${gbpAmount.toFixed(2)} has been copied.`,
            });
        }
    };


    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Currency Exchange Calculator</DialogTitle>
                    <DialogDescription>
                        Calculate the GBP equivalent for a foreign currency transaction. The exchange rate is fetched automatically for the selected date.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                     <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <Label htmlFor="transaction-date">Transaction Date</Label>
                            <TooltipProvider>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Select the date of payment to calculate the exchange rate of that specific date</p>
                                    </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        </div>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full justify-start text-left font-normal",
                                    !transactionDate && "text-muted-foreground"
                                )}
                                >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {transactionDate ? format(transactionDate, "PPP") : <span>Pick a date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                mode="single"
                                selected={transactionDate}
                                onSelect={setTransactionDate}
                                initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                            <Label htmlFor="currency">Currency</Label>
                            <Select value={currency} onValueChange={setCurrency}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="EUR">EUR (€)</SelectItem>
                                    <SelectItem value="USD">USD ($)</SelectItem>
                                    {/* Add other currencies as needed */}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <div className="flex items-center gap-2">
                                <Label htmlFor="foreign-amount">Amount ({currency})</Label>
                                <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger asChild>
                                            <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                                        </TooltipTrigger>
                                        <TooltipContent>
                                            <p>Enter The Amount Your Received in Euro</p>
                                        </TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>
                            </div>
                            <Input
                                id="foreign-amount"
                                type="number"
                                value={foreignAmount}
                                onChange={(e) => setForeignAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                placeholder="e.g., 5000"
                            />
                        </div>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="exchange-rate">Exchange Rate (1 {currency} to GBP)</Label>
                        <div className="relative">
                            {isLoading && <Loader2 className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin" />}
                             <Input
                                id="exchange-rate"
                                type="number"
                                value={exchangeRate}
                                onChange={(e) => setExchangeRate(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                placeholder={isLoading ? "Fetching rate..." : "e.g., 0.85"}
                                readOnly={isLoading}
                            />
                        </div>
                         <p className="text-xs text-muted-foreground">This rate is fetched automatically from currencylayer.com for the selected date.</p>
                    </div>
                     <div className="space-y-2 rounded-lg border bg-muted p-4">
                        <div className="flex justify-between items-center">
                            <Label>Calculated GBP Amount</Label>
                            <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={handleCopy}
                                disabled={gbpAmount <= 0}
                            >
                                <Copy className="mr-2 h-4 w-4" />
                                Copy
                            </Button>
                        </div>
                        <div className="text-2xl font-bold font-mono">£{gbpAmount.toFixed(2)}</div>
                    </div>
                </div>
                <DialogFooter>
                    <DialogClose asChild>
                        <Button type="button" variant="secondary">Cancel</Button>
                    </DialogClose>
                    <Button type="button" onClick={handleApply}>Apply to Net Amount</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

interface VatTransactionsTableProps {
    title: string;
    subtitle: string;
    transactions: VatTransaction[];
    setTransactions: (transactions: VatTransaction[]) => void;
    activeCompany: Client;
    nominalCodes: NominalCode[];
    vatReturnPeriod: VatReturn;
    toast: ReturnType<typeof useToast>['toast'];
    rateType: 'income' | 'expenditure';
    allowDrc: boolean;
    showCurrencyConverter?: boolean;
}

export function VatTransactionsTable({ 
    title, 
    subtitle, 
    transactions, 
    setTransactions, 
    activeCompany, 
    nominalCodes,
    vatReturnPeriod,
    toast,
    rateType,
    allowDrc,
    showCurrencyConverter = false,
}: VatTransactionsTableProps) {
    const [customRowCount, setCustomRowCount] = useState<number | ''>('');
    const [history, setHistory] = useState<VatTransaction[][]>([]);
    const [isConverterOpen, setIsConverterOpen] = useState(false);
    const [activeTransactionId, setActiveTransactionId] = useState<string | null>(null);

    const createNewTransaction = (): VatTransaction => ({
        id: `new-${Date.now()}-${Math.random()}`,
        transactionType: '',
        customer: activeCompany.name,
        date: format(new Date(), 'yyyy-MM-dd'),
        nominalCode: '',
        netAmount: 0,
        vatAmount: 0,
        vatPercentage: '20',
        subjectToCIS: 'N',
        attachment: null,
        includeInMtd: true,
    });

    useEffect(() => {
        if (transactions.length === 0) {
            setTransactions([createNewTransaction()]);
        }
    }, [transactions, setTransactions]);

    const saveToHistory = () => {
        setHistory(prev => [...prev.slice(-9), transactions]); // Keep last 10 states
    };

    const handleUndo = () => {
        if (history.length > 0) {
            const previousState = history[history.length - 1];
            setTransactions(previousState);
            setHistory(prev => prev.slice(0, -1));
        }
    };
    
    const updateTransaction = (id: string, field: keyof VatTransaction, value: any) => {
        saveToHistory();
        const newTransactions = transactions.map(t => {
            if (t.id === id) {
                const updatedTx = { ...t, [field]: value };
                // Recalculate VAT if net amount or percentage changes
                if ((field === 'netAmount' || field === 'vatPercentage') && updatedTx.vatPercentage !== 'exempt' && updatedTx.vatPercentage !== 'no-vat' && updatedTx.vatPercentage !== '0') {
                    const net = field === 'netAmount' ? parseFloat(value) : parseFloat(updatedTx.netAmount as any);
                    let vatRate: number;
                    
                    switch(updatedTx.vatPercentage) {
                        case 'drc-20':
                        case '20':
                            vatRate = 20;
                            break;
                        case 'drc-5':
                        case '5':
                            vatRate = 5;
                            break;
                        default:
                            vatRate = parseFloat(updatedTx.vatPercentage);
                    }

                    if (!isNaN(net) && !isNaN(vatRate)) {
                        updatedTx.vatAmount = net * (vatRate / 100);
                    }
                } else if (field === 'vatPercentage' && (updatedTx.vatPercentage === 'exempt' || updatedTx.vatPercentage === 'no-vat' || updatedTx.vatPercentage === '0')) {
                    updatedTx.vatAmount = 0;
                }
                
                if (field === 'date') {
                    const selectedDate = new Date(value);
                    const periodStart = new Date(vatReturnPeriod.periodStart);
                    const periodEnd = new Date(vatReturnPeriod.periodEnd);
                    if (!isWithinInterval(selectedDate, { start: periodStart, end: periodEnd })) {
                        toast({
                            variant: 'destructive',
                            title: 'Date Outside VAT Period',
                            description: 'Please note this invoice date falls outside your current VAT return period.',
                        });
                    }
                }
                return updatedTx;
            }
            return t;
        });
        setTransactions(newTransactions);
    };

    const addTransactions = (count: number) => {
        if (count <= 0) return;
        saveToHistory();
        const newTransactions: VatTransaction[] = [];
        for (let i = 0; i < count; i++) {
            newTransactions.push(createNewTransaction());
        }
        setTransactions([...transactions, ...newTransactions]);
    };

    const deleteTransaction = (id: string) => {
        saveToHistory();
        const newTransactions = transactions.filter(t => t.id !== id);
        if (newTransactions.length === 0) {
            setTransactions([createNewTransaction()]);
        } else {
            setTransactions(newTransactions);
        }
    };

    const handleCustomAdd = () => {
        const count = typeof customRowCount === 'number' ? customRowCount : 0;
        if (count > 0) {
            addTransactions(count);
            setCustomRowCount('');
        }
    };

    const totalVat = useMemo(() => {
        return transactions.reduce((acc, tx) => acc + (Number(tx.vatAmount) || 0), 0);
    }, [transactions]);

    const openConverter = (txId: string | null) => {
        setActiveTransactionId(txId);
        setIsConverterOpen(true);
    };

    const applyConversion = (gbpAmount: number) => {
        if (activeTransactionId) {
            updateTransaction(activeTransactionId, 'netAmount', gbpAmount.toFixed(2));
        }
    };

    return (
        <Card className="mt-4">
            <CardHeader>
                <div>
                    <CardTitle>{title}</CardTitle>
                    <CardDescription>{subtitle}</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                 <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-4">
                        {showCurrencyConverter && (
                            <div className="flex items-center gap-2">
                                <Button variant="outline" onClick={() => openConverter(null)}>
                                    <Calculator className="mr-2 h-4 w-4" /> Currency Calculator
                                </Button>
                                <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger>
                                            <Info className="h-4 w-4 text-muted-foreground" />
                                        </TooltipTrigger>
                                        <TooltipContent>
                                            <p>Just click on the calculator icon next to the net amount on the line you are working on to calculate the exchange rate on a specific date in the past</p>
                                        </TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>
                            </div>
                        )}
                        <div className="flex items-center gap-2 text-sm text-muted-foreground ml-4">
                            <Info className="h-4 w-4" />
                            <span>Toggle 'Yes' for CIS column if transaction falls under the Construction Industry Scheme.</span>
                        </div>
                    </div>
                    <div className="p-4 rounded-lg bg-muted text-center">
                        <p className="text-sm font-medium text-muted-foreground">Total VAT for this section</p>
                        <p className="text-2xl font-bold font-mono">£{totalVat.toFixed(2)}</p>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="border-r">Transaction Type</TableHead>
                                <TableHead className="border-r">Customer</TableHead>
                                <TableHead className="border-r">Date</TableHead>
                                <TableHead className="border-r">Nominal Code</TableHead>
                                <TableHead className="border-r">Net Amount</TableHead>
                                <TableHead className="border-r">VAT Amount</TableHead>
                                <TableHead className="border-r">Gross Amount</TableHead>
                                <TableHead className="border-r">VAT %</TableHead>
                                <TableHead className="border-r">
                                    <div className="flex items-center gap-2">
                                        <span>CIS</span>
                                        <TooltipProvider>
                                            <Tooltip>
                                                <TooltipTrigger>
                                                    <Info className="h-4 w-4 text-muted-foreground" />
                                                </TooltipTrigger>
                                                <TooltipContent className="max-w-xs">
                                                    <p className="font-bold mb-2">What is the Construction Industry Scheme (CIS)?</p>
                                                    <p>CIS is a set of rules for how payments to subcontractors for construction work must be handled. Under the scheme, contractors deduct money from a subcontractor's payments and pass it to HM Revenue and Customs (HMRC). The deductions count as advance payments towards the subcontractor's tax and National Insurance.</p>
                                                </TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    </div>
                                </TableHead>
                                <TableHead className="border-r">Attachment</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {transactions.map(tx => (
                                <TransactionRow 
                                    key={tx.id} 
                                    transaction={tx} 
                                    onUpdate={updateTransaction}
                                    onDelete={deleteTransaction}
                                    activeCompany={activeCompany}
                                    nominalCodes={nominalCodes}
                                    vatReturnPeriod={vatReturnPeriod}
                                    rateType={rateType}
                                    allowDrc={allowDrc}
                                    onOpenConverter={showCurrencyConverter ? () => openConverter(tx.id) : undefined}
                                />
                            ))}
                        </TableBody>
                    </Table>
                </div>
                 <div className="flex items-center gap-2 mt-4">
                     <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button>
                                <Plus className="mr-2 h-4 w-4" /> Add Rows
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => addTransactions(1)}>+ 1 Row</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => addTransactions(5)}>+ 5 Rows</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => addTransactions(10)}>+ 10 Rows</DropdownMenuItem>
                            <DropdownMenuSeparator />
                             <div className="p-2 space-y-2">
                                <label className="text-sm font-medium px-2">Custom</label>
                                 <div className="flex items-center gap-2">
                                    <Input 
                                        type="number"
                                        value={customRowCount}
                                        onChange={(e) => setCustomRowCount(e.target.value === '' ? '' : parseInt(e.target.value))}
                                        className="w-24 h-8"
                                        min="1"
                                        placeholder="e.g., 20"
                                        onClick={(e) => e.stopPropagation()}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter') {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                handleCustomAdd();
                                            }
                                        }}
                                    />
                                    <Button size="sm" className="h-8" onClick={handleCustomAdd}>Add</Button>
                                </div>
                            </div>
                        </DropdownMenuContent>
                    </DropdownMenu>
                     <Button variant="outline" onClick={handleUndo} disabled={history.length === 0}>
                        <Undo className="mr-2 h-4 w-4" /> Undo Last Action
                    </Button>
                 </div>
            </CardContent>
            {showCurrencyConverter && <CurrencyConverterDialog open={isConverterOpen} onOpenChange={setIsConverterOpen} onApply={applyConversion} toast={toast} />}
        </Card>
    );
}


function TransactionRow({ 
    transaction, 
    onUpdate, 
    onDelete, 
    activeCompany, 
    nominalCodes, 
    vatReturnPeriod, 
    rateType, 
    allowDrc,
    onOpenConverter,
}: {
    transaction: VatTransaction,
    onUpdate: (id: string, field: keyof VatTransaction, value: any) => void,
    onDelete: (id: string) => void,
    activeCompany: Client,
    nominalCodes: NominalCode[],
    vatReturnPeriod: VatReturn,
    rateType: 'income' | 'expenditure',
    allowDrc: boolean,
    onOpenConverter?: (txId: string) => void,
}) {
    const [datePopoverOpen, setDatePopoverOpen] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onUpdate(transaction.id, 'attachment', e.target.files[0].name);
        }
    };
    
    const isDateOutsidePeriod = () => {
        if (!transaction.date) return false;
        const selectedDate = new Date(transaction.date);
        const periodStart = new Date(vatReturnPeriod.periodStart);
        const periodEnd = new Date(vatReturnPeriod.periodEnd);
        return !isWithinInterval(selectedDate, { start: periodStart, end: periodEnd });
    };

    const grossAmount = (Number(transaction.netAmount) || 0) + (Number(transaction.vatAmount) || 0);

    const incomeRates = useMemo(() => {
        const baseRates = [
            { value: "20", label: "20% (Standard)" },
            { value: "5", label: "5% (Reduced)" },
            { value: "0", label: "0% (Zero Rated)" },
            { value: "exempt", label: "Exempt" },
        ];
        if (allowDrc) {
            return [
                ...baseRates,
                { value: "drc-20", label: "DRC 20%" },
                { value: "drc-5", label: "DRC 5%" },
            ];
        }
        return baseRates;
    }, [allowDrc]);

    const expenditureRates = useMemo(() => {
        const baseRates = [
            { value: "20", label: "20% (Standard)" },
            { value: "5", label: "5% (Reduced)" },
            { value: "0", label: "0% (Zero Rated)" },
            { value: "exempt", label: "Exempt" },
            { value: "no-vat", label: "No VAT" },
        ];
        if (allowDrc) {
            return [
                ...baseRates,
                { value: "drc-20", label: "DRC 20%" },
                { value: "drc-5", label: "DRC 5%" },
            ];
        }
        return baseRates;
    }, [allowDrc]);

    const currentRates = rateType === 'income' ? incomeRates : expenditureRates;

    return (
        <TableRow>
            <TableCell className="border-r"><Input value={transaction.transactionType} onChange={e => onUpdate(transaction.id, 'transactionType', e.target.value)} className="min-w-[100px]" /></TableCell>
            <TableCell className="border-r">
                 <div className="flex items-center p-2 rounded-md bg-muted min-w-[200px]">
                    <User className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{activeCompany.name}</span>
                </div>
            </TableCell>
            <TableCell className="border-r">
                 <Popover open={datePopoverOpen} onOpenChange={setDatePopoverOpen}>
                    <PopoverTrigger asChild>
                        <Button variant="outline" className={cn("w-auto justify-start text-left font-normal", !transaction.date && "text-muted-foreground", isDateOutsidePeriod() && "border-destructive text-destructive focus-visible:ring-destructive")}>
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {transaction.date ? format(new Date(transaction.date), "PPP") : <span>Pick a date</span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                        <Calendar
                            mode="single"
                            selected={new Date(transaction.date)}
                            onSelect={(date) => {
                                if (date) {
                                    onUpdate(transaction.id, 'date', format(date, 'yyyy-MM-dd'));
                                    setDatePopoverOpen(false);
                                }
                            }}
                            initialFocus
                        />
                    </PopoverContent>
                </Popover>
            </TableCell>
            <TableCell className="min-w-[170px] border-r">
                 <Select value={transaction.nominalCode} onValueChange={v => onUpdate(transaction.id, 'nominalCode', v)}>
                    <SelectTrigger><SelectValue placeholder="Select code" /></SelectTrigger>
                    <SelectContent>
                        {nominalCodes.map(code => <SelectItem key={code.id} value={code.name}>{code.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </TableCell>
            <TableCell className="border-r">
                <div className="relative">
                    {onOpenConverter && (
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="absolute -left-8 top-1/2 -translate-y-1/2 h-6 w-6 z-10"
                            onClick={() => onOpenConverter(transaction.id)}
                        >
                            <Calculator className="h-4 w-4 text-muted-foreground" />
                        </Button>
                    )}
                    <Input 
                        type="number" 
                        value={transaction.netAmount} 
                        onFocus={e => e.target.select()}
                        onChange={e => onUpdate(transaction.id, 'netAmount', e.target.value)} 
                        className="min-w-[100px] text-right" 
                    />
                </div>
            </TableCell>
            <TableCell className="border-r">
                <Input 
                    type="number" 
                    value={transaction.vatAmount}
                    onFocus={e => e.target.select()}
                    onChange={e => onUpdate(transaction.id, 'vatAmount', e.target.value)}
                    className="min-w-[100px] text-right" 
                />
            </TableCell>
            <TableCell className="border-r">
                <div className="font-mono text-right min-w-[100px] px-3 py-2 rounded-md bg-muted">
                    £{grossAmount.toFixed(2)}
                </div>
            </TableCell>
            <TableCell className="border-r">
                <Select value={transaction.vatPercentage} onValueChange={v => onUpdate(transaction.id, 'vatPercentage', v)}>
                    <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        {currentRates.map(rate => (
                            <SelectItem key={rate.value} value={rate.value}>{rate.label}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </TableCell>
             <TableCell className="border-r">
                <Button
                    onClick={() => onUpdate(transaction.id, 'subjectToCIS', transaction.subjectToCIS === 'Y' ? 'N' : 'Y')}
                    variant={transaction.subjectToCIS === 'Y' ? 'default' : 'destructive'}
                    className={cn('w-[70px]', transaction.subjectToCIS === 'Y' ? 'bg-green-500' : 'bg-red-500', 'text-white hover:bg-opacity-80')}
                    size="sm"
                >
                    {transaction.subjectToCIS === 'Y' ? 'Yes' : 'No'}
                </Button>
            </TableCell>
            <TableCell className="border-r">
                 <Input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
                 {transaction.attachment ? (
                     <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Paperclip className="h-4 w-4" />
                        <span className="truncate max-w-[100px]">{transaction.attachment}</span>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onUpdate(transaction.id, 'attachment', null)}>
                            <XCircle className="h-4 w-4 text-destructive" />
                        </Button>
                     </div>
                 ) : (
                    <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                        <Paperclip className="mr-2 h-4 w-4" />
                        Attach Invoice
                    </Button>
                 )}
            </TableCell>
            <TableCell>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete this transaction line.
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => onDelete(transaction.id)}>
                            Delete
                        </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </TableCell>
        </TableRow>
    )
}

    
