

"use client";

import { useMemo, useState, useEffect } from 'react';
import type { VatTransaction, VatTotals, VatExportHistory, VatRate } from '@/lib/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Send } from 'lucide-react';
import type { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';

interface VatReturnSummaryProps {
    sales: VatTransaction[];
    euSales: VatTransaction[];
    purchases: VatTransaction[];
    ecAcquisitions: VatTransaction[];
    onSubmission: (submission: VatExportHistory) => void;
    toast: ReturnType<typeof useToast>['toast'];
}


export const boxDescriptions: { [key in keyof VatTotals]: string } = {
    box1: 'VAT due on sales and other outputs',
    box2: 'VAT due on acquisitions from other EC Member States',
    box3: 'Total VAT due (Box 1 + Box 2)',
    box4: 'VAT reclaimed on purchases and other inputs',
    box5: 'Net VAT to pay or reclaim',
    box6: 'Total value of sales and all other outputs',
    box7: 'Total value of purchases and all other inputs',
    box8: 'Total value of supplies of goods to other EC Member States',
    box9: 'Total value of acquisitions of goods from other EC Member States',
};


export function VatReturnSummary({ sales, euSales, purchases, ecAcquisitions, onSubmission, toast }: VatReturnSummaryProps) {
    const [isConfirming, setIsConfirming] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDeclared, setIsDeclared] = useState(false);
    const [isReceiptOpen, setIsReceiptOpen] = useState(false);
    const [submissionRef, setSubmissionRef] = useState('');
    const [submissionDate, setSubmissionDate] = useState<Date | null>(null);

     useEffect(() => {
        if (!isConfirming) {
            // Reset declaration when dialog is closed
            setIsDeclared(false);
        }
    }, [isConfirming]);

    const totals = useMemo<VatTotals>(() => {
        const getSum = (txs: VatTransaction[], key: 'netAmount' | 'vatAmount') =>
            txs.reduce((acc, tx) => acc + (Number(tx[key]) || 0), 0);

        let box1 = 0;
        let box4 = 0;
        let box6 = 0;
        let box7 = 0;

        // Process sales (excluding EC sales)
        sales.forEach(tx => {
            const vatRate = tx.vatPercentage as VatRate;
            
            // Handle DRC on Income
            if (vatRate === 'drc-20' || vatRate === 'drc-5') {
                box6 += Number(tx.netAmount) || 0;
                return; // No VAT amount for Box 1 on DRC income
            }

            if (vatRate !== 'no-vat' && vatRate !== 'exempt') {
                box6 += Number(tx.netAmount) || 0;
            }

            if (vatRate === '20' || vatRate === '5') {
                box1 += Number(tx.vatAmount) || 0;
            }
        });

        // Process purchases (excluding EC acquisitions)
        purchases.forEach(tx => {
            const vatRate = tx.vatPercentage as VatRate;

            // Handle DRC on Expenses
            if (vatRate === 'drc-20' || vatRate === 'drc-5') {
                box1 += Number(tx.vatAmount) || 0; // VAT amount goes to Box 1
                box4 += Number(tx.vatAmount) || 0; // and also to Box 4
                box7 += Number(tx.netAmount) || 0; // Net amount to Box 7
                return;
            }
            
            if (vatRate !== 'no-vat' && vatRate !== 'exempt') {
                box7 += Number(tx.netAmount) || 0;
            }
            
            if (vatRate === '20' || vatRate === '5') {
                box4 += Number(tx.vatAmount) || 0;
            }
        });

        const box2 = getSum(ecAcquisitions.filter(tx => tx.vatPercentage === '20'), 'vatAmount');
        const box3 = box1 + box2;

        box4 += getSum(ecAcquisitions.filter(tx => tx.vatPercentage === '20'), 'vatAmount'); // Reverse charge amount

        const box5 = box3 - box4;
        const box8 = getSum(euSales, 'netAmount');
        const box9 = getSum(ecAcquisitions, 'netAmount');

        box6 += getSum(euSales.filter(tx => tx.vatPercentage !== 'exempt'), 'netAmount');
        box7 += box9;


        return { box1, box2, box3, box4, box5, box6, box7, box8, box9 };
    }, [sales, euSales, purchases, ecAcquisitions]);

    const handleHMRCSubmit = () => {
        setIsSubmitting(true);
        //Simulate API Call
        setTimeout(() => {
            const ref = `HMRC-VAT-${Date.now()}`;
            const subDate = new Date();
            const allSubmittedTransactions = [...sales, ...euSales, ...purchases, ...ecAcquisitions];

            const newSubmission: VatExportHistory = {
                id: subDate.toISOString(),
                fileName: ref,
                date: subDate.toISOString(),
                content: JSON.stringify(allSubmittedTransactions),
                type: 'HMRC Submission',
                totals: totals,
            };

            onSubmission(newSubmission);

            setSubmissionRef(ref);
            setSubmissionDate(subDate);
            toast({
                title: "Successfully Submitted to HMRC",
                description: `Your VAT return has been submitted. Reference: ${ref}`,
            });
            setIsSubmitting(false);
            setIsConfirming(false);
            setIsReceiptOpen(true);
        }, 2000);
    };

    return (
        <>
            <Card className="mt-4">
                <CardHeader>
                    <CardTitle>VAT Return Summary</CardTitle>
                    <CardDescription>This summary is calculated from the transactions in the preceding tabs.</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 gap-2 max-w-lg mx-auto">
                    {Object.entries(totals).map(([key, value], index) => (
                        <VatBox key={key} boxNumber={index + 1} value={value} />
                    ))}
                </CardContent>
                <CardFooter className="max-w-lg mx-auto">
                    <Button onClick={() => setIsConfirming(true)}>
                        <Send className="mr-2 h-4 w-4" />
                        Submit to HMRC
                    </Button>
                </CardFooter>
            </Card>

            <Dialog open={isConfirming} onOpenChange={setIsConfirming}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>VAT Submission Declaration</DialogTitle>
                        <DialogDescription asChild>
                           <div className="space-y-2">
                             <div className="font-bold">When you submit this VAT information you are making a legal declaration that the information is true and complete. A false declaration can result in prosecution.</div>
                             <div>Once this VAT information is submitted to HMRC no changes can be made.</div>
                           </div>
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-4 grid grid-cols-2 gap-2">
                        {Object.entries(totals).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-center p-2 rounded-lg bg-muted">
                                <span className="text-sm text-muted-foreground">{boxDescriptions[key as keyof VatTotals]}</span>
                                <span className="font-mono font-bold">£{value.toFixed(2)}</span>
                            </div>
                        ))}
                    </div>
                     <div className="flex justify-between items-center p-2 rounded-lg bg-primary/10 text-primary mt-4">
                        <span className="font-bold">{totals.box5 >= 0 ? 'Net VAT to Pay' : 'Net VAT to Reclaim'}</span>
                        <span className="font-mono font-bold text-lg">£{Math.abs(totals.box5).toFixed(2)}</span>
                    </div>

                    <div className="flex items-center space-x-2 pt-4">
                        <Checkbox id="declaration" checked={isDeclared} onCheckedChange={(checked) => setIsDeclared(checked as boolean)} />
                        <Label htmlFor="declaration" className="text-sm">
                           I confirm that I have read the above legal declaration and have authority to submit this VAT information
                        </Label>
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsConfirming(false)} disabled={isSubmitting}>Cancel</Button>
                        <Button onClick={handleHMRCSubmit} disabled={isSubmitting || !isDeclared}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Confirm & Submit to HMRC
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            
            <Dialog open={isReceiptOpen} onOpenChange={setIsReceiptOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>VAT Submission Receipt</DialogTitle>
                        <DialogDescription>
                           This is a confirmation of your VAT submission to HMRC.
                        </DialogDescription>
                    </DialogHeader>
                     <div className="py-4 grid grid-cols-2 gap-2">
                        {Object.entries(totals).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-center p-2 rounded-lg bg-muted">
                                <span className="text-sm text-muted-foreground">{boxDescriptions[key as keyof VatTotals]}</span>
                                <span className="font-mono font-bold">£{value.toFixed(2)}</span>
                            </div>
                        ))}
                    </div>
                     <div className="flex justify-between items-center p-2 rounded-lg bg-primary/10 text-primary mt-4">
                        <span className="font-bold">{totals.box5 >= 0 ? 'Net VAT to Pay' : 'Net VAT to Reclaim'}</span>
                        <span className="font-mono font-bold text-lg">£{Math.abs(totals.box5).toFixed(2)}</span>
                    </div>
                    <div className="mt-4 p-3 rounded-md border text-center space-y-2">
                        <div>
                            <p className="text-sm text-muted-foreground">Submission Reference</p>
                            <p className="font-mono font-semibold">{submissionRef}</p>
                        </div>
                        {submissionDate && (
                             <div>
                                <p className="text-sm text-muted-foreground">Submission Date</p>
                                <p className="font-mono font-semibold">{format(submissionDate, 'dd MMM yyyy, HH:mm:ss')}</p>
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                         <Button onClick={() => setIsReceiptOpen(false)}>Close</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}

function VatBox({ boxNumber, value }: { boxNumber: number; value: number }) {
    const key = `box${boxNumber}` as keyof VatTotals;
    
    return (
        <Card className="flex items-center justify-between p-4">
            <div className="flex flex-col">
                <CardTitle className="text-sm font-medium text-muted-foreground">Box {boxNumber}</CardTitle>
                <CardDescription className="text-sm">{boxDescriptions[key]}</CardDescription>
            </div>
            <p className="text-xl font-bold font-mono">£{value.toFixed(2)}</p>
        </Card>
    );
}
