
"use client";

import { useState, useEffect } from 'react';
import type { Client, VatReturn } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format, differenceInDays } from 'date-fns';
import { ArrowLeft, Calendar as CalendarIcon, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { DateRange } from 'react-day-picker';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';

interface VatSummaryPageProps {
    client: Client;
    vatReturns: VatReturn[];
    onSelectReturn: (vatReturn: VatReturn) => void;
    onPrepareNew: (dateRange?: DateRange) => void;
}

export function VatSummaryPage({ client, vatReturns, onSelectReturn, onPrepareNew }: VatSummaryPageProps) {
    const [needsAttention, setNeedsAttention] = useState<VatReturn[]>([]);
    const [completed, setCompleted] = useState<VatReturn[]>([]);
    const [customDateRange, setCustomDateRange] = useState<DateRange | undefined>();

    useEffect(() => {
        setNeedsAttention(vatReturns.filter(vr => vr.status === 'Due'));
        setCompleted(vatReturns.filter(vr => vr.status === 'Filed'));
    }, [vatReturns]);

    const getDaysDue = (dueDate: string) => {
        const days = differenceInDays(new Date(dueDate), new Date());
        if (days < 0) return 'Overdue';
        return `Due in ${days} days`;
    };
    
    const handlePrepareCustom = () => {
        if (customDateRange?.from && customDateRange?.to) {
            onPrepareNew(customDateRange);
        }
    };

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle>VAT information from HMRC as of {format(new Date(), 'dd MMM yyyy')}</CardTitle>
                        <div className="flex gap-2">
                             <Button asChild variant="outline">
                                <Link href={`/dashboard/client/${client.id}`}>
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    Back to Client View
                                </Link>
                            </Button>
                            <Button onClick={() => onPrepareNew()}>Prepare New Vat Return</Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
                    <div>
                        <p className="text-sm text-muted-foreground">VAT amount due</p>
                        <p className="text-2xl font-bold">Nothing to pay</p>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">Payment due</p>
                        <p className="text-2xl font-bold">07 Aug 2025</p>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">Payment method</p>
                        <p className="text-2xl font-bold">Direct debit to HMRC</p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Needs Attention</CardTitle>
                </CardHeader>
                <CardContent>
                    {needsAttention.length > 0 ? needsAttention.map(vr => (
                        <div key={vr.id} className="flex justify-between items-center p-4 border rounded-lg">
                            <div>
                                <p className="font-semibold">{format(new Date(vr.periodStart), 'dd MMM yyyy')} - {format(new Date(vr.periodEnd), 'dd MMM yyyy')}</p>
                                <p className="text-sm text-muted-foreground">Due {format(new Date(vr.dueDate), 'dd MMM yyyy')}</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <Badge variant="destructive">{getDaysDue(vr.dueDate)}</Badge>
                                <Button variant="outline" onClick={() => onSelectReturn(vr)}>Review</Button>
                            </div>
                        </div>
                    )) : <p className="text-muted-foreground">No returns need attention at the moment.</p>}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle>Completed</CardTitle>
                        <p className="text-sm text-muted-foreground">Looking to see VAT Transactions for your own date range?</p>
                    </div>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="p-4 rounded-lg border bg-muted/50 flex flex-col sm:flex-row items-center justify-center gap-4">
                        <p className="font-semibold">Select a custom date range:</p>
                         <Popover>
                            <PopoverTrigger asChild>
                                <Button
                                    variant={"outline"}
                                    className={cn("w-full sm:w-[300px] justify-start text-left font-normal", !customDateRange && "text-muted-foreground")}
                                >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {customDateRange?.from ? (
                                        customDateRange.to ? (
                                            <>{format(customDateRange.from, "LLL dd, y")} - {format(customDateRange.to, "LLL dd, y")}</>
                                        ) : (format(customDateRange.from, "LLL dd, y"))
                                    ) : (
                                        <span>Pick a date range</span>
                                    )}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="center">
                                <Calendar
                                    initialFocus
                                    mode="range"
                                    selected={customDateRange}
                                    onSelect={setCustomDateRange}
                                    numberOfMonths={2}
                                />
                            </PopoverContent>
                        </Popover>
                         <Button onClick={handlePrepareCustom} disabled={!customDateRange?.from || !customDateRange?.to}>
                            Filter By Dates <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                    {completed.map(vr => (
                        <div key={vr.id} className="flex justify-between items-center p-4 border rounded-lg">
                            <div>
                                <div className="flex items-center gap-2">
                                    <p className="font-semibold">{format(new Date(vr.periodStart), 'dd MMM yyyy')} - {format(new Date(vr.periodEnd), 'dd MMM yyyy')}</p>
                                    <Badge>Filed</Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">Submitted {vr.submittedDate ? format(new Date(vr.submittedDate), 'dd MMM yyyy') : ''} by {vr.submittedBy}</p>
                            </div>
                            <div className="flex items-center gap-4">
                                {vr.vatAmountDue !== undefined && <p>VAT amount due <span className="font-mono font-semibold">£{vr.vatAmountDue.toFixed(2)}</span></p>}
                                {vr.vatAmountRefundable !== undefined && <p>VAT amount refundable <span className="font-mono font-semibold">£{vr.vatAmountRefundable.toFixed(2)}</span></p>}
                                <Button variant="outline" onClick={() => onSelectReturn(vr)}>Review</Button>
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
