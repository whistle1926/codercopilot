"use client";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Client } from "@/lib/types";

export function ClientSelection({ clients, onClientSelect }: { clients: Client[], onClientSelect: (client: Client) => void }) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>Select a Client</CardTitle>
                <CardDescription>Choose which client you want to prepare a VAT return for.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {clients.map(client => (
                    <Card key={client.id} className="hover:border-primary">
                        <CardContent className="p-4">
                            <h3 className="font-semibold">{client.name}</h3>
                            <p className="text-sm text-muted-foreground">{client.vatNumber}</p>
                            <Button className="w-full mt-4" onClick={() => onClientSelect(client)}>
                                Select
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </CardContent>
        </Card>
    )
}