

"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Client, NominalCode, VatTransaction, VatExportHistory, VatReturn, VatTotals, VatRate, DeadlineDate } from '@/lib/types';
import { clients as allClients, nominalCodes as allNominalCodes, initialVatReturns, initialDeadlineDates } from '@/lib/data';
import { VatTransactionsTable } from './components/vat-transactions-table';
import { VatReturnSummary } from './components/vat-return-summary';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Eye, FileText, ArrowRight, UserSearch, RefreshCw, Save, Download, ArrowLeft, CalendarIcon, Info } from 'lucide-react';
import { format, addDays, addQuarters, endOfQuarter, startOfQuarter } from 'date-fns';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { boxDescriptions } from './components/vat-return-summary';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { useActiveClient } from '@/hooks/use-active-client';
import { VatSummaryPage } from './components/vat-summary';
import { ClientSelection } from './components/client-selection';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import type { DateRange } from 'react-day-picker';


function FiledVatReturnView({ 
    vatReturn, 
    onBack, 
    submission 
}: { 
    vatReturn: VatReturn, 
    onBack: () => void,
    submission: VatExportHistory | undefined
}) {
    if (!submission || !submission.totals) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Submission Details Not Found</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">The details for this submission could not be loaded.</p>
                    <Button onClick={onBack} variant="outline" className="mt-4"><ArrowLeft className="mr-2 h-4 w-4" />Back to Summary</Button>
                </CardContent>
            </Card>
        );
    }
    
    const allTransactions: VatTransaction[] = JSON.parse(submission.content || '[]').map((tx: VatTransaction) => ({
        ...tx,
        netAmount: Number(tx.netAmount),
        vatAmount: Number(tx.vatAmount)
    }));

    const handleDownloadCSV = () => {
        const headers = ["Transaction Type", "Customer", "Date", "Nominal Code", "Net Amount", "VAT Amount", "VAT %", "Subject to CIS"];
        const rows = allTransactions.map(tx => [
            tx.transactionType,
            `"${tx.customer.replace(/"/g, '""')}"`,
            tx.date,
            tx.nominalCode,
            tx.netAmount.toFixed(2),
            tx.vatAmount.toFixed(2),
            tx.vatPercentage,
            tx.subjectToCIS,
        ].join(','));
        
        const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        const fileName = `vat-audit-log-${submission.fileName}.csv`;
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader className="flex flex-row justify-between items-start">
                    <div>
                        <CardTitle>Review Filed VAT Return</CardTitle>
                        <CardDescription>
                            Review of VAT return for period {format(new Date(vatReturn.periodStart), 'dd MMM yyyy')} to {format(new Date(vatReturn.periodEnd), 'dd MMM yyyy')}.
                        </CardDescription>
                    </div>
                    <Button onClick={onBack} variant="outline"><ArrowLeft className="mr-2 h-4 w-4" />Back to Summary</Button>
                </CardHeader>
                <CardContent className="space-y-6">
                    <Card>
                        <CardHeader>
                             <CardTitle>Submission Receipt</CardTitle>
                        </CardHeader>
                        <CardContent className="grid md:grid-cols-3 gap-4 text-sm">
                            <div className="space-y-1">
                                <p className="text-muted-foreground">Submission Date</p>
                                <p className="font-semibold">{format(new Date(submission.date), 'dd MMM yyyy, HH:mm:ss')}</p>
                            </div>
                             <div className="space-y-1">
                                <p className="text-muted-foreground">HMRC Submission ID</p>
                                <p className="font-mono">{submission.fileName}</p>
                            </div>
                             <div className="space-y-1">
                                <p className="text-muted-foreground">Submitted By</p>
                                <p className="font-semibold">{vatReturn.submittedBy}</p>
                            </div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader>
                             <CardTitle>VAT Return Summary (Boxes 1-9)</CardTitle>
                        </CardHeader>
                        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {Object.entries(submission.totals).map(([key, value], index) => (
                                <div key={key} className="p-4 rounded-lg bg-muted">
                                    <p className="text-sm text-muted-foreground">Box {index + 1}: {boxDescriptions[key as keyof VatTotals]}</p>
                                    <p className="text-xl font-bold font-mono">£{(value as number).toFixed(2)}</p>
                                </div>
                            ))}
                        </CardContent>
                         <CardFooter className="flex justify-between items-center p-4 border-t">
                            <div className="text-lg font-bold">
                                {submission.totals.box5 >= 0 ? 'Net VAT to Pay:' : 'Net VAT to Reclaim:'}
                                <span className="ml-2 font-mono">£{Math.abs(submission.totals.box5).toFixed(2)}</span>
                            </div>
                             <div className="flex gap-2">
                                <Button variant="outline" onClick={() => alert('PDF download is a prototype feature.')}><Download className="mr-2 h-4 w-4"/>Download PDF Receipt</Button>
                                <Button onClick={handleDownloadCSV}><Download className="mr-2 h-4 w-4"/>Download CSV Audit Log</Button>
                            </div>
                        </CardFooter>
                    </Card>

                    <Card>
                         <CardHeader>
                             <CardTitle>Transaction Audit Log</CardTitle>
                             <CardDescription>The {allTransactions.length} transactions included in this VAT return.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Date</TableHead>
                                        <TableHead>Type</TableHead>
                                        <TableHead>Customer</TableHead>
                                        <TableHead>Nominal Code</TableHead>
                                        <TableHead className="text-right">Net</TableHead>
                                        <TableHead className="text-right">VAT</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {allTransactions.map(tx => (
                                        <TableRow key={tx.id}>
                                            <TableCell>{format(new Date(tx.date), 'dd MMM yy')}</TableCell>
                                            <TableCell>{tx.transactionType}</TableCell>
                                            <TableCell>{tx.customer}</TableCell>
                                            <TableCell>{tx.nominalCode}</TableCell>
                                            <TableCell className="text-right font-mono">£{tx.netAmount.toFixed(2)}</TableCell>
                                            <TableCell className="text-right font-mono">£{tx.vatAmount.toFixed(2)}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </CardContent>
            </Card>
        </div>
    );
}

function VatReturnDetailView({ 
    activeCompany,
    currentVatReturn,
    onBack,
    sales, setSales,
    euSales, setEuSales,
    purchases, setPurchases,
    ecAcquisitions, setEcAcquisitions,
    unsubmittedInvoices, setUnsubmittedInvoices,
    handleNewSubmission,
    nominalCodes,
    toast,
}: { 
    activeCompany: Client, 
    currentVatReturn: VatReturn,
    onBack: () => void,
    sales: VatTransaction[], setSales: (txs: VatTransaction[]) => void,
    euSales: VatTransaction[], setEuSales: (txs: VatTransaction[]) => void,
    purchases: VatTransaction[], setPurchases: (txs: VatTransaction[]) => void,
    ecAcquisitions: VatTransaction[], setEcAcquisitions: (txs: VatTransaction[]) => void,
    unsubmittedInvoices: VatTransaction[], setUnsubmittedInvoices: (txs: VatTransaction[]) => void,
    handleNewSubmission: (submission: VatExportHistory) => void,
    nominalCodes: NominalCode[],
    toast: ReturnType<typeof useToast>['toast'],
}) {
    const [allowDrc, setAllowDrc] = useState(false);

    const handleTransactionUpdate = (
        type: 'sales' | 'euSales' | 'purchases' | 'ecAcquisitions', 
        updatedTransactions: VatTransaction[]
    ) => {
        if (!activeCompany) return;

        // Update local component state
        switch(type) {
            case 'sales': setSales(updatedTransactions); break;
            case 'euSales': setEuSales(updatedTransactions); break;
            case 'purchases': setPurchases(updatedTransactions); break;
            case 'ecAcquisitions': setEcAcquisitions(updatedTransactions); break;
        }

        // Save entire draft state for the active client and return period
        const draftData = {
            sales: type === 'sales' ? updatedTransactions : sales,
            euSales: type === 'euSales' ? updatedTransactions : euSales,
            purchases: type === 'purchases' ? updatedTransactions : purchases,
            ecAcquisitions: type === 'ecAcquisitions' ? updatedTransactions : ecAcquisitions,
        };
        localStorage.setItem(`vat_draft_${activeCompany.id}_${currentVatReturn.id}`, JSON.stringify(draftData));
    };

    const handleSaveDraft = () => {
        const draftData = { sales, euSales, purchases, ecAcquisitions };
        localStorage.setItem(`vat_draft_${activeCompany.id}_${currentVatReturn.id}`, JSON.stringify(draftData));
        toast({
            title: "Draft Saved",
            description: "Your VAT return draft has been successfully saved.",
        });
    };

     const addInvoicesToReturn = () => {
        if (!activeCompany) return;
        const clientUnsubmitted = unsubmittedInvoices.filter(inv => inv.customer === activeCompany?.name);
        const otherUnsubmitted = unsubmittedInvoices.filter(inv => inv.customer !== activeCompany?.name);

        const updatedSales = [...sales, ...clientUnsubmitted.map(inv => ({...inv, details: `Invoice ${inv.documentReference}`}))];
        
        handleTransactionUpdate('sales', updatedSales);
        
        setUnsubmittedInvoices(otherUnsubmitted);
        localStorage.setItem('vat_unsubmitted_invoices', JSON.stringify(otherUnsubmitted));
        
        toast({
            title: "Invoices Added to Return",
            description: `${clientUnsubmitted.length} invoice(s) for ${activeCompany?.name} have been added to the Sales tab.`,
        });
    }

     const relevantUnsubmittedInvoices = unsubmittedInvoices.filter(inv => inv.customer === activeCompany.name);

     return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>Prepare VAT Return</CardTitle>
                            <CardDescription>
                                Manage your VAT transactions and prepare returns for HMRC submission.
                            </CardDescription>
                            <div className="text-sm text-muted-foreground pt-2">
                                <span className="font-semibold text-foreground">Company:</span> {activeCompany?.name} <span className="font-semibold text-foreground ml-4">VAT Number:</span> {activeCompany?.vatNumber}
                            </div>
                        </div>
                         <div className="flex items-center gap-4">
                             <TooltipProvider>
                                <div className="flex items-center gap-2 bg-muted p-2 rounded-md">
                                    <Label className="text-muted-foreground text-xs">Toggle on Yes to include Domestic Reverse Charge Feature for Vat dropdown</Label>
                                    <Button
                                        onClick={() => setAllowDrc(!allowDrc)}
                                        variant={allowDrc ? 'default' : 'destructive'}
                                        className={cn('w-[70px]', allowDrc ? 'bg-green-500' : 'bg-red-500', 'text-white hover:bg-opacity-80')}
                                        size="sm"
                                    >
                                        {allowDrc ? 'Yes' : 'No'}
                                    </Button>
                                    <Tooltip>
                                        <TooltipTrigger>
                                            <Info className="h-4 w-4 text-muted-foreground" />
                                        </TooltipTrigger>
                                        <TooltipContent className="max-w-xs">
                                            <p className="font-bold mb-2">What is Domestic Reverse Charge (DRC)?</p>
                                            <p>For certain building and construction services, the customer (contractor) is responsible for paying the VAT directly to HMRC instead of paying the supplier (subcontractor). This is called the 'reverse charge'. If this applies to you, toggle this on to see DRC VAT rates in the dropdowns.</p>
                                        </TooltipContent>
                                    </Tooltip>
                                </div>
                             </TooltipProvider>
                            <Button variant="outline" onClick={handleSaveDraft}>
                                <Save className="mr-2 h-4 w-4" /> Save Draft
                            </Button>
                            <Button variant="outline" onClick={onBack}>
                                <UserSearch className="mr-2 h-4 w-4" /> Back to VAT Summary
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 p-4 border rounded-lg bg-muted/50">
                        <div className="space-y-2">
                            <Label>Quarter</Label>
                             <div className="flex h-10 w-full items-center justify-start rounded-md border border-input bg-muted px-3 py-2 text-sm">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                <span>{`${format(new Date(currentVatReturn.periodStart), "MMM yyyy")} - ${format(new Date(currentVatReturn.periodEnd), "MMM yyyy")}`}</span>
                            </div>
                        </div>
                         <div className="space-y-2">
                            <Label>Period End Date</Label>
                             <div className="flex h-10 w-full items-center justify-start rounded-md border border-input bg-muted px-3 py-2 text-sm">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                <span>{format(new Date(currentVatReturn.periodEnd), "PPP")}</span>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label>Open From</Label>
                            <div className="flex h-10 w-full items-center justify-start rounded-md border border-input bg-muted px-3 py-2 text-sm">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                <span>{format(new Date(currentVatReturn.openFrom), "PPP")}</span>
                            </div>
                        </div>
                         <div className="space-y-2">
                            <Label>Closes</Label>
                             <div className="flex h-10 w-full items-center justify-start rounded-md border border-input bg-muted px-3 py-2 text-sm">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                <span>{format(new Date(currentVatReturn.closesOn), "PPP")}</span>
                            </div>
                        </div>
                    </div>
                    <Tabs defaultValue="sales" className="w-full">
                        <TooltipProvider>
                            <TabsList className="grid w-full grid-cols-5 data-[state=active]:bg-primary">
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <TabsTrigger value="sales" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2">
                                            Sales <Info className="h-4 w-4" />
                                        </TabsTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Enter all sales made within the UK (excluding EU countries).</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <TabsTrigger value="eu_sales" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2">
                                            EU Sales <Info className="h-4 w-4" />
                                        </TabsTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Enter all sales made to countries within the European Union.</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <TabsTrigger value="purchases" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2">
                                            Purchases <Info className="h-4 w-4" />
                                        </TabsTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Enter all purchases made within the UK (excluding EU countries).</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <TabsTrigger value="ec_acquisitions" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2">
                                            EC Acquisitions <Info className="h-4 w-4" />
                                        </TabsTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Enter all purchases (acquisitions) from countries within the European Union.</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <TabsTrigger value="summary" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2">
                                            Return Summary <Info className="h-4 w-4" />
                                        </TabsTrigger>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Review the calculated totals for your VAT return before submitting to HMRC.</p>
                                    </TooltipContent>
                                </Tooltip>
                            </TabsList>
                        </TooltipProvider>
                        <TabsContent value="sales">
                            <VatTransactionsTable
                                title="Sales and Other Outputs"
                                subtitle="Goods and Services - Excluding transactions with EU member states"
                                transactions={sales}
                                setTransactions={(newTxs) => handleTransactionUpdate('sales', newTxs)}
                                activeCompany={activeCompany}
                                nominalCodes={nominalCodes}
                                vatReturnPeriod={currentVatReturn}
                                toast={toast}
                                rateType="income"
                                allowDrc={allowDrc}
                            />
                        </TabsContent>
                        <TabsContent value="eu_sales">
                             <VatTransactionsTable
                                title="EU Sales"
                                subtitle="Goods and Services - Transactions with EU member states"
                                transactions={euSales}
                                setTransactions={(newTxs) => handleTransactionUpdate('euSales', newTxs)}
                                 activeCompany={activeCompany}
                                nominalCodes={nominalCodes}
                                vatReturnPeriod={currentVatReturn}
                                toast={toast}
                                rateType="income"
                                allowDrc={allowDrc}
                            />
                        </TabsContent>
                        <TabsContent value="purchases">
                            <VatTransactionsTable
                                title="Purchases and Other Inputs"
                                subtitle="Goods and Services - Excluding transactions with EU member states"
                                transactions={purchases}
                                setTransactions={(newTxs) => handleTransactionUpdate('purchases', newTxs)}
                                 activeCompany={activeCompany}
                                nominalCodes={nominalCodes}
                                vatReturnPeriod={currentVatReturn}
                                toast={toast}
                                rateType="expenditure"
                                allowDrc={allowDrc}
                            />
                        </TabsContent>
                        <TabsContent value="ec_acquisitions">
                            <VatTransactionsTable
                                title="EC Acquisitions"
                                subtitle="Goods and Services - Acquisitions from EU member states"
                                transactions={ecAcquisitions}
                                setTransactions={(newTxs) => handleTransactionUpdate('ecAcquisitions', newTxs)}
                                activeCompany={activeCompany}
                                nominalCodes={nominalCodes}
                                vatReturnPeriod={currentVatReturn}
                                toast={toast}
                                rateType="expenditure"
                                allowDrc={allowDrc}
                                showCurrencyConverter={true}
                            />
                        </TabsContent>
                        <TabsContent value="summary">
                            <VatReturnSummary
                                sales={sales}
                                euSales={euSales}
                                purchases={purchases}
                                ecAcquisitions={ecAcquisitions}
                                onSubmission={handleNewSubmission}
                                toast={toast}
                            />
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>

            {relevantUnsubmittedInvoices.length > 0 && (
                 <Card>
                    <CardHeader>
                        <CardTitle>Invoices Ready for Submission for {activeCompany.name}</CardTitle>
                        <CardDescription>These invoices have been created but are not yet included in the current VAT return.</CardDescription>
                    </CardHeader>
                    <CardContent>
                         <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Customer</TableHead>
                                    <TableHead>Details</TableHead>
                                    <TableHead className="text-right">Net Amount</TableHead>
                                    <TableHead className="text-right">VAT Amount</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {relevantUnsubmittedInvoices.map(item => (
                                    <TableRow key={item.id}>
                                        <TableCell>{format(new Date(item.date), 'dd MMM yyyy')}</TableCell>
                                        <TableCell>{item.customer}</TableCell>
                                        <TableCell>{item.details}</TableCell>
                                        <TableCell className="text-right font-mono">£{item.netAmount.toFixed(2)}</TableCell>
                                        <TableCell className="text-right font-mono">£{item.vatAmount.toFixed(2)}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                    <CardContent>
                        <Button onClick={addInvoicesToReturn}>
                            Add {relevantUnsubmittedInvoices.length} Invoice(s) to Return <ArrowRight className="ml-2 h-4 w-4"/>
                        </Button>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}

function VatReturnsPageContent() {
    const { toast } = useToast();
    const { activeClient, setActiveClient } = useActiveClient();
    
    const [view, setView] = useState<'summary' | 'details' | 'filed-details' | 'select-client'>('select-client');
    const [vatReturns, setVatReturns] = useState<VatReturn[]>(initialVatReturns);
    const [currentVatReturn, setCurrentVatReturn] = useState<VatReturn | null>(null);

    const [clients, setClients] = useState<Client[]>([]);
    const [nominalCodes, setNominalCodes] = useState<NominalCode[]>([]);
    
    // State for each tab's transactions
    const [sales, setSales] = useState<VatTransaction[]>([]);
    const [euSales, setEuSales] = useState<VatTransaction[]>([]);
    const [purchases, setPurchases] = useState<VatTransaction[]>([]);
    const [ecAcquisitions, setEcAcquisitions] = useState<VatTransaction[]>([]);
    const [submissionHistory, setSubmissionHistory] = useState<VatExportHistory[]>([]);
    
    const [unsubmittedInvoices, setUnsubmittedInvoices] = useState<VatTransaction[]>([]);

    const [viewingSubmission, setViewingSubmission] = useState<VatExportHistory | undefined>(undefined);

    const loadGlobalData = useCallback(() => {
        const clientData = allClients as Client[];
        setClients(clientData);
        setNominalCodes(allNominalCodes);
        
        const loadGlobalTransactions = (key: string, initialData: VatTransaction[]): VatTransaction[] => {
            try {
                const stored = localStorage.getItem(key);
                return stored ? JSON.parse(stored) : initialData;
            } catch (error) {
                console.error(`Error loading ${key} from localStorage`, error);
                return initialData;
            }
        };

        setUnsubmittedInvoices(loadGlobalTransactions('vat_unsubmitted_invoices', []).map(inv => ({...inv, details: `Invoice ${inv.documentReference}`})));
        const storedHistory = localStorage.getItem('vatSubmissionHistory');
        setSubmissionHistory(storedHistory ? JSON.parse(storedHistory) : []);
        
        const storedVatReturns = localStorage.getItem('vatReturns');
        setVatReturns(storedVatReturns ? JSON.parse(storedVatReturns) : initialVatReturns);

    }, []);

    useEffect(() => {
        loadGlobalData();
    }, [loadGlobalData]);

     useEffect(() => {
        if (activeClient) {
            setView('summary');
        } else {
            setView('select-client');
        }
    }, [activeClient]);


    const handleSelectReturn = (vatReturn: VatReturn) => {
        const client = clients.find(c => c.id === vatReturn.clientId);
        if (!client) return;

        setActiveClient(client);
        setCurrentVatReturn(vatReturn);
        
        if (vatReturn.status === 'Due') {
            const draftData = JSON.parse(localStorage.getItem(`vat_draft_${client.id}_${vatReturn.id}`) || '{}');
            setSales(draftData.sales || []);
            setEuSales(draftData.euSales || []);
            setPurchases(draftData.purchases || []);
            setEcAcquisitions(draftData.ecAcquisitions || []);
            setView('details');
        } else { // 'Filed'
            // Find the corresponding submission from history
            const submission = submissionHistory.find(sub => sub.id === vatReturn.id);
            setViewingSubmission(submission);
            setView('filed-details');
        }
    };

    const handlePrepareNew = (dateRange?: DateRange) => {
        if (!activeClient) return;

        let newVatReturn: VatReturn;

        if (dateRange && dateRange.from && dateRange.to) {
            // Custom date range
            newVatReturn = {
                id: `new-vr-${Date.now()}`,
                clientId: activeClient.id,
                periodStart: format(dateRange.from, 'yyyy-MM-dd'),
                periodEnd: format(dateRange.to, 'yyyy-MM-dd'),
                openFrom: format(dateRange.from, 'yyyy-MM-dd'),
                closesOn: format(addDays(dateRange.to, 37), 'yyyy-MM-dd'), // e.g., 1 month + 7 days
                dueDate: format(addDays(dateRange.to, 37), 'yyyy-MM-dd'),
                status: 'Due',
            };
        } else {
            // Standard quarterly logic
            const today = new Date();
            const currentQuarterStart = startOfQuarter(today);
            
            const alreadyExists = vatReturns.some(vr => 
                vr.clientId === activeClient.id && 
                new Date(vr.periodStart).getTime() === currentQuarterStart.getTime()
            );

            if (alreadyExists) {
                const existingReturn = vatReturns.find(vr => vr.clientId === activeClient.id && new Date(vr.periodStart).getTime() === currentQuarterStart.getTime());
                if (existingReturn) {
                     handleSelectReturn(existingReturn);
                     return;
                }
            }
            
            const endOfCurrentQuarter = endOfQuarter(today);

            const deadlines = JSON.parse(localStorage.getItem('deadlineDates') || '[]') as DeadlineDate[];
            const deadline = deadlines.find(d => {
                try {
                    const periodEndDate = new Date(d.periodEnd);
                    return periodEndDate.getFullYear() === endOfCurrentQuarter.getFullYear() &&
                           Math.floor(periodEndDate.getMonth() / 3) === Math.floor(endOfCurrentQuarter.getMonth() / 3);
                } catch {
                    return false;
                }
            });
            
            newVatReturn = {
                id: `new-vr-${Date.now()}`,
                clientId: activeClient.id,
                periodStart: format(currentQuarterStart, 'yyyy-MM-dd'),
                periodEnd: format(endOfCurrentQuarter, 'yyyy-MM-dd'),
                openFrom: deadline ? deadline.openFrom : format(addDays(endOfCurrentQuarter, 1), 'yyyy-MM-dd'),
                closesOn: deadline ? deadline.closes : format(addDays(addQuarters(endOfCurrentQuarter, 1), 7), 'yyyy-MM-dd'),
                dueDate: deadline ? deadline.closes : format(addDays(addQuarters(endOfCurrentQuarter, 1), 7), 'yyyy-MM-dd'),
                status: 'Due',
            };
        }

        handleSelectReturn(newVatReturn);
    };
    
    const handleBackToSummary = () => {
        setView('summary');
        setCurrentVatReturn(null);
        // Clear transaction data
        setSales([]);
        setEuSales([]);
        setPurchases([]);
        setEcAcquisitions([]);
        setViewingSubmission(undefined);
    };
    
    const handleNewSubmission = (submission: VatExportHistory) => {
        if (!activeClient || !currentVatReturn) return;
        
        const isNewReturn = currentVatReturn.id.startsWith('new-');
        const returnId = isNewReturn ? `vr-${Date.now()}` : currentVatReturn.id;
        
        const submissionWithId = { ...submission, id: returnId };
        const updatedHistory = [submissionWithId, ...submissionHistory];
        setSubmissionHistory(updatedHistory);
        localStorage.setItem('vatSubmissionHistory', JSON.stringify(updatedHistory));
        
        
        localStorage.removeItem(`vat_draft_${activeClient.id}_${currentVatReturn.id}`);
        
        let updatedVatReturns = [...vatReturns];
        const submittedReturn: VatReturn = {
            ...currentVatReturn,
            id: returnId,
            status: 'Filed',
            submittedDate: submission.date,
            submittedBy: 'Accountant Name',
            vatAmountDue: submission.totals?.box5,
        };

        if (isNewReturn) {
            updatedVatReturns.push(submittedReturn);
        } else {
             updatedVatReturns = vatReturns.map(vr => 
                vr.id === currentVatReturn.id ? submittedReturn : vr
            );
        }

        setVatReturns(updatedVatReturns);
        localStorage.setItem('vatReturns', JSON.stringify(updatedVatReturns));
        
        handleBackToSummary();
    };


    if (view === 'select-client' || !activeClient) {
        return <ClientSelection clients={clients} onClientSelect={(client) => setActiveClient(client)} />;
    }

    if (view === 'details' && activeClient && currentVatReturn) {
        return <VatReturnDetailView 
            activeCompany={activeClient}
            currentVatReturn={currentVatReturn}
            onBack={handleBackToSummary}
            sales={sales} setSales={setSales}
            euSales={euSales} setEuSales={setEuSales}
            purchases={purchases} setPurchases={setPurchases}
            ecAcquisitions={ecAcquisitions} setEcAcquisitions={setEcAcquisitions}
            unsubmittedInvoices={unsubmittedInvoices} setUnsubmittedInvoices={setUnsubmittedInvoices}
            handleNewSubmission={handleNewSubmission}
            nominalCodes={nominalCodes}
            toast={toast}
        />;
    }
    
     if (view === 'filed-details' && activeClient && currentVatReturn) {
        return <FiledVatReturnView 
            vatReturn={currentVatReturn}
            onBack={handleBackToSummary}
            submission={viewingSubmission}
        />
    }

    return <VatSummaryPage 
        client={activeClient} 
        onSelectReturn={handleSelectReturn}
        vatReturns={vatReturns.filter(vr => vr.clientId === activeClient.id)}
        onPrepareNew={handlePrepareNew} 
    />;
}

export default function VatReturnsPageWrapper() {
    // This wrapper is needed because the main layout provider is what this page needs to interact with.
    // It avoids creating a new provider instance which would isolate its state.
    return <VatReturnsPageContent />;
}
