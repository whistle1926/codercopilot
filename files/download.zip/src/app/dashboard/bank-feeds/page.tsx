
"use client";

import { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { PlusCircle, ArrowLeft } from 'lucide-react';
import { BankSelection } from './components/bank-selection';
import { ConnectedBanksList } from './components/connected-banks-list';
import { connectedBanks } from '@/lib/data';
import { useActiveClient } from '@/hooks/use-active-client';
import Link from 'next/link';

export default function BankFeedsPage() {
  const [showBankSelection, setShowBankSelection] = useState(false);
  const { activeClient } = useActiveClient();

  const handleAddBankClick = () => {
    setShowBankSelection(true);
  };
  
  const handleBankSelectionClose = () => {
    setShowBankSelection(false);
  }

  if (showBankSelection) {
    return <BankSelection onClose={handleBankSelectionClose} connectedBanks={connectedBanks} />;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
            <div>
                <CardTitle>Bank Feeds</CardTitle>
                <CardDescription>Manage your connected bank accounts and their transaction feeds.</CardDescription>
            </div>
            {activeClient && (
                <Button asChild variant="outline">
                    <Link href={`/dashboard/client/${activeClient.id}`}>
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to Client View
                    </Link>
                </Button>
            )}
        </div>
      </CardHeader>
      <CardContent>
        <ConnectedBanksList />
      </CardContent>
      <CardFooter className="border-t pt-6">
        <Button onClick={handleAddBankClick}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add a Bank Feed
        </Button>
      </CardFooter>
    </Card>
  );
}
