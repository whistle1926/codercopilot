
"use client";

import { useState, useEffect, useTransition, useMemo } from 'react';
import { useParams, notFound } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHeader, TableHead, TableRow } from '@/components/ui/table';
import { RefreshCw, History, Info, Sparkles, Loader2, Download, FileText, Filter, ArrowLeft } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
    Collapsible,
    CollapsibleContent,
    CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { 
    connectedBanks, 
    bankTransactions as initialBankTransactions, 
    connectionHistory, 
    incomeSources as initialIncomeSources,
    nominalCodes as initialNominalCodes,
    clients as initialClients,
} from '@/lib/data';
import type { BankTransaction, ConnectionHistory, IncomeSource, NominalCode, Client } from '@/lib/types';
import { format, differenceInDays } from 'date-fns';
import { cn } from '@/lib/utils';
import { TransactionActions } from './components/transaction-actions';
import { handleCategorizeTransactions } from '@/app/actions/invoice';
import { BankReconciliation } from './components/bank-reconciliation';
import { TransactionFilters } from './components/transaction-filters';
import type { Filters } from './components/transaction-filters';
import { useActiveClient } from '@/hooks/use-active-client';
import Link from 'next/link';

export default function BankAccountDetailsPage() {
    const params = useParams();
    const bankId = params.id as string;

    const [bank, setBank] = useState<(typeof connectedBanks)[0] | null>(null);
    const [transactions, setTransactions] = useState<BankTransaction[]>([]);
    const [incomeSources, setIncomeSources] = useState<IncomeSource[]>([]);
    const [nominalCodes, setNominalCodes] = useState<NominalCode[]>([]);
    const [isPending, startTransition] = useTransition();
    const { activeClient, setActiveClient } = useActiveClient();


    const [filters, setFilters] = useState<Filters>({
        date: undefined,
        description: '',
        debitMin: '',
        debitMax: '',
        creditMin: '',
        creditMax: '',
        nominalCode: 'all',
        incomeSource: 'all',
        includeInMtd: 'all',
    });

    useEffect(() => {
        const foundBank = connectedBanks.find(b => b.id === bankId);
        if (foundBank) {
            setBank(foundBank);

            const allClients = JSON.parse(localStorage.getItem('clients') || 'null') as Client[] || initialClients;
            const client = allClients.find(c => c.bankFeeds.some(feed => feed.id === bankId));
            if (client) {
                setActiveClient(client);
            }
            
            const allStoredTransactions = JSON.parse(localStorage.getItem('bankTransactions') || 'null') as BankTransaction[] | null;
            const initialData = allStoredTransactions || initialBankTransactions;
            if (!allStoredTransactions) {
                localStorage.setItem('bankTransactions', JSON.stringify(initialBankTransactions));
            }
            
            const foundTransactions = initialData.filter(t => t.bankId === bankId);
            setTransactions(foundTransactions);
            
            const loadFromStorage = <T,>(key: string, initialData: T[], setter: React.Dispatch<React.SetStateAction<T[]>>) => {
                const storedData = localStorage.getItem(key);
                setter(storedData ? JSON.parse(storedData) : initialData);
            };
            
            loadFromStorage('incomeSources', initialIncomeSources, setIncomeSources);
            loadFromStorage('nominalCodes', initialNominalCodes, setNominalCodes);
            
        } else {
            notFound();
        }
    }, [bankId, setActiveClient]);
    
    useEffect(() => {
        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === 'incomeSources') setIncomeSources(JSON.parse(e.newValue || '[]'));
            if (e.key === 'nominalCodes') setNominalCodes(JSON.parse(e.newValue || '[]'));
            if (e.key === 'bankTransactions') {
                const allTransactions = JSON.parse(e.newValue || '[]') as BankTransaction[];
                setTransactions(allTransactions.filter(t => t.bankId === bankId));
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }, [bankId]);

    const filteredTransactions = useMemo(() => {
        return transactions.filter(t => {
            const date = new Date(t.date);
            if (filters.date?.from && date < filters.date.from) return false;
            if (filters.date?.to && date > filters.date.to) return false;
            if (filters.description && !t.description.toLowerCase().includes(filters.description.toLowerCase())) return false;
            if (filters.debitMin && (t.debit === null || t.debit < parseFloat(filters.debitMin))) return false;
            if (filters.debitMax && (t.debit === null || t.debit > parseFloat(filters.debitMax))) return false;
            if (filters.creditMin && (t.credit === null || t.credit < parseFloat(filters.creditMin))) return false;
            if (filters.creditMax && (t.credit === null || t.credit > parseFloat(filters.creditMax))) return false;
            if (filters.nominalCode !== 'all' && t.nominalCode !== filters.nominalCode) return false;
            if (filters.incomeSource !== 'all' && t.incomeSource !== filters.incomeSource) return false;
            if (filters.includeInMtd !== 'all') {
                if (filters.includeInMtd === 'yes' && !t.includeInMtd) return false;
                if (filters.includeInMtd === 'no' && t.includeInMtd) return false;
            }
            return true;
        });
    }, [transactions, filters]);
    
    const handleUpdateTransaction = (transactionId: string, updatedData: Partial<BankTransaction>) => {
        const updatedTransactions = transactions.map(t => 
            t.id === transactionId ? {...t, ...updatedData} : t
        );
        setTransactions(updatedTransactions);

        const allStoredTransactions = JSON.parse(localStorage.getItem('bankTransactions') || '[]') as BankTransaction[];
        const otherBankTransactions = allStoredTransactions.filter(t => t.bankId !== bankId);
        const newAllTransactions = [...otherBankTransactions, ...updatedTransactions];
        localStorage.setItem('bankTransactions', JSON.stringify(newAllTransactions));
    };

    const handleAutoCategorize = () => {
        startTransition(async () => {
            const transactionsToCategorize = filteredTransactions.filter(t => !t.additionalDescription && !t.nominalCode && !t.incomeSource);
            const categorizedHistory = transactions.filter(t => t.additionalDescription || t.nominalCode || t.incomeSource);
            
            const results = await handleCategorizeTransactions([...transactionsToCategorize, ...categorizedHistory]);
            
            const updatedTransactions = transactions.map(t => {
                const found = results.find(nc => nc.id === t.id);
                return found || t;
            });
            setTransactions(updatedTransactions);

            const allStoredTransactions = JSON.parse(localStorage.getItem('bankTransactions') || '[]') as BankTransaction[];
            const otherBankTransactions = allStoredTransactions.filter(t => t.bankId !== bankId);
            const newAllTransactions = [...otherBankTransactions, ...updatedTransactions];
            localStorage.setItem('bankTransactions', JSON.stringify(newAllTransactions));
        });
    }
    
    const handleDownload = () => {
        const headers = ["Date", "Description", "Debit", "Credit", "Balance", "Additional Description", "Nominal Code", "Income Source", "Include in MTD", "Approved"];
        const rows = filteredTransactions.map(t => [
            t.date,
            `"${t.description.replace(/"/g, '""')}"`,
            t.debit ?? '',
            t.credit ?? '',
            t.balance,
            t.additionalDescription,
            t.nominalCode,
            t.incomeSource,
            t.includeInMtd ? 'Yes' : 'No',
            t.isApproved ? 'Yes' : 'No',
        ].join(','));
        
        const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        const fileName = `mtd-simple-transactions-${bankId}-${format(new Date(), 'yyyyMMddHHmmss')}.csv`;
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    if (!bank) {
        return <div>Loading...</div>;
    }

    const lastTransactionDate = bank.lastTransaction ? format(new Date(bank.lastTransaction), 'dd MMM yyyy') : 'N/A';
    const isFeedStale = bank.lastTransaction ? differenceInDays(new Date(), new Date(bank.lastTransaction)) > 1 : false;

    return (
        <div className="space-y-6">
            <Card>
                <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                        <div>
                            <h1 className="text-2xl font-bold">{bank.bankName}</h1>
                            <p className="text-muted-foreground">
                                Balance as at {lastTransactionDate}: <span className="font-mono">£{bank.balance.toFixed(2)}</span>
                            </p>
                        </div>
                        <div className="flex items-center gap-4">
                            {activeClient && (
                                <Button asChild variant="outline">
                                    <Link href={`/dashboard/client/${activeClient.id}`}>
                                        <ArrowLeft className="mr-2 h-4 w-4" />
                                        Back to Client View
                                    </Link>
                                </Button>
                            )}
                            <div className="flex flex-col items-center gap-1">
                                <Button onClick={handleAutoCategorize} disabled={isPending}>
                                    {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                                    Auto-categorize with AI
                                </Button>
                                <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger>
                                            <Info className="h-4 w-4 text-muted-foreground" />
                                        </TooltipTrigger>
                                        <TooltipContent side="bottom" className="max-w-xs">
                                            <p>This flow will take an uncategorized transaction and a history of your past categorized transactions. It will then use AI to predict the correct "Additional Description", "Nominal Code", and "Income Source" based on what you've entered before for similar transactions.</p>
                                        </TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>
                            </div>
                             <div className="flex flex-col items-center gap-1">
                                <Button variant={isFeedStale ? 'destructive' : 'default'}>
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Refresh/Reconnect Bank Feed
                                </Button>
                                 <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger>
                                            <Info className="h-4 w-4 text-muted-foreground" />
                                        </TooltipTrigger>
                                        <TooltipContent side="bottom" className="max-w-xs">
                                            <p>If the feed hasn't updated in over a day, we recommend reconnecting to ensure your data is current.</p>
                                        </TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
            
            <div className="space-y-6">
                <Card>
                    <Collapsible>
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle>Transactions</CardTitle>
                                <CollapsibleTrigger asChild>
                                     <Button variant="default" className="bg-primary">
                                        <Filter className="mr-2 h-4 w-4" />
                                        Search Here Using Filters
                                    </Button>
                                </CollapsibleTrigger>
                            </div>
                        </CardHeader>
                         <CollapsibleContent>
                            <TransactionFilters
                                filters={filters}
                                setFilters={setFilters}
                                incomeSources={incomeSources}
                                nominalCodes={nominalCodes}
                            />
                        </CollapsibleContent>
                    </Collapsible>
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead className="border-r">Date</TableHead>
                                    <TableHead className="border-r">Description</TableHead>
                                    <TableHead className="text-right border-r">Debit</TableHead>
                                    <TableHead className="text-right border-r">Credit</TableHead>
                                    <TableHead className="text-right border-r">Balance</TableHead>
                                    <TableHead className="border-r">Additional Description</TableHead>
                                    <TableHead className="border-r">Nominal Code</TableHead>
                                    <TableHead className="border-r">Income Source</TableHead>
                                    <TableHead className="border-r">
                                        <div className="flex items-center gap-2">
                                            <span>Include In MTD</span>
                                            <TooltipProvider>
                                                <Tooltip>
                                                    <TooltipTrigger>
                                                        <Info className="h-4 w-4 text-muted-foreground" />
                                                    </TooltipTrigger>
                                                    <TooltipContent>
                                                        <p>Just click to Select Yes or No for this coloum</p>
                                                    </TooltipContent>
                                                </Tooltip>
                                            </TooltipProvider>
                                        </div>
                                    </TableHead>
                                    <TableHead>Approved</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredTransactions.map((t) => (
                                    <TableRow key={t.id}>
                                        <TableCell className="border-r">{format(new Date(t.date), 'dd/MM/yyyy')}</TableCell>
                                        <TableCell className="border-r">{t.description}</TableCell>
                                        <TableCell className="text-right font-mono border-r">{t.debit ? `£${t.debit.toFixed(2)}` : '-'}</TableCell>
                                        <TableCell className="text-right font-mono border-r">{t.credit ? `£${t.credit.toFixed(2)}` : '-'}</TableCell>
                                        <TableCell className="text-right font-mono border-r">£{t.balance.toFixed(2)}</TableCell>
                                        
                                        <TransactionActions 
                                            transaction={t}
                                            incomeSources={incomeSources}
                                            nominalCodes={nominalCodes}
                                            onUpdate={handleUpdateTransaction}
                                        />

                                        <TableCell className="border-r">
                                            <Button 
                                                variant={t.includeInMtd ? 'default' : 'destructive'} 
                                                className={cn(t.includeInMtd ? 'bg-green-500' : 'bg-red-500', 'text-white hover:bg-opacity-80')}
                                                onClick={() => handleUpdateTransaction(t.id, { includeInMtd: !t.includeInMtd })}
                                                size="sm"
                                            >
                                                {t.includeInMtd ? 'Yes' : 'No'}
                                            </Button>
                                        </TableCell>
                                        <TableCell>
                                            <Button 
                                                variant={t.isApproved ? 'default' : 'destructive'} 
                                                className={cn(t.isApproved ? 'bg-green-500' : 'bg-red-500', 'text-white hover:bg-opacity-80')}
                                                onClick={() => handleUpdateTransaction(t.id, { isApproved: !t.isApproved })}
                                                size="sm"
                                            >
                                                {t.isApproved ? 'Yes' : 'No'}
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {filteredTransactions.length === 0 && (
                            <div className="text-center p-8 text-muted-foreground">
                                No transactions found matching your filters.
                            </div>
                        )}
                    </CardContent>
                     <CardFooter className="border-t p-4 flex items-center gap-4">
                        <Button onClick={handleDownload} disabled={filteredTransactions.length === 0}>
                            <Download className="mr-2 h-4 w-4" />
                            Download Feed
                        </Button>
                        <p className="text-sm text-muted-foreground">Use Search Filters Button Above to Search For Transactions Between Custom Dates</p>
                    </CardFooter>
                </Card>
                
                <BankReconciliation transactions={transactions} bankId={bankId} />

            </div>
        </div>
    );
}
