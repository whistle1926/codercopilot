
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarIcon, X } from 'lucide-react';
import { format } from 'date-fns';
import type { DateRange } from 'react-day-picker';
import { cn } from '@/lib/utils';
import type { IncomeSource, NominalCode } from '@/lib/types';
import { ArrowRight } from 'lucide-react';

export interface Filters {
  date: DateRange | undefined;
  description: string;
  debitMin: string;
  debitMax: string;
  creditMin: string;
  creditMax: string;
  nominalCode: string;
  incomeSource: string;
  includeInMtd: 'all' | 'yes' | 'no';
}

interface TransactionFiltersProps {
  filters: Filters;
  setFilters: React.Dispatch<React.SetStateAction<Filters>>;
  incomeSources: IncomeSource[];
  nominalCodes: NominalCode[];
}

export function TransactionFilters({ 
    filters, 
    setFilters, 
    incomeSources, 
    nominalCodes, 
}: TransactionFiltersProps) {
  
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);

  const handleInputChange = (field: keyof Filters, value: string | DateRange | undefined) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const clearFilters = () => {
    setFilters({
      date: undefined,
      description: '',
      debitMin: '',
      debitMax: '',
      creditMin: '',
      creditMax: '',
      nominalCode: 'all',
      incomeSource: 'all',
      includeInMtd: 'all',
    });
  };

  return (
    <div className="p-4 border-b space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* Date Range Filter */}
        <div className="space-y-2">
          <Label>Date Range</Label>
          <Popover open={isDatePopoverOpen} onOpenChange={setIsDatePopoverOpen}>
            <PopoverTrigger asChild>
              <Button
                variant={"outline"}
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !filters.date && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {filters.date?.from ? (
                  filters.date.to ? (
                    <>
                      {format(filters.date.from, "LLL dd, y")} - {format(filters.date.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(filters.date.from, "LLL dd, y")
                  )
                ) : (
                  <span>Pick a date range</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={filters.date?.from}
                selected={filters.date}
                onSelect={(date) => handleInputChange('date', date)}
                numberOfMonths={2}
              />
               <div className="p-2 border-t flex justify-end">
                    <Button onClick={() => setIsDatePopoverOpen(false)}>
                        Next <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Description Filter */}
        <div className="space-y-2">
            <Label htmlFor="desc-filter">Description</Label>
            <Input 
                id="desc-filter"
                placeholder="e.g., Virgin Media"
                value={filters.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
            />
        </div>

        {/* Debit Filter */}
        <div className="space-y-2">
            <Label>Debit Amount</Label>
            <div className="flex gap-2">
                <Input type="number" placeholder="Min" value={filters.debitMin} onChange={(e) => handleInputChange('debitMin', e.target.value)} />
                <Input type="number" placeholder="Max" value={filters.debitMax} onChange={(e) => handleInputChange('debitMax', e.target.value)} />
            </div>
        </div>

        {/* Credit Filter */}
        <div className="space-y-2">
            <Label>Credit Amount</Label>
            <div className="flex gap-2">
                <Input type="number" placeholder="Min" value={filters.creditMin} onChange={(e) => handleInputChange('creditMin', e.target.value)} />
                <Input type="number" placeholder="Max" value={filters.creditMax} onChange={(e) => handleInputChange('creditMax', e.target.value)} />
            </div>
        </div>
        
        {/* Nominal Code Filter */}
        <div className="space-y-2">
          <Label>Nominal Code</Label>
          <Select value={filters.nominalCode} onValueChange={(v) => handleInputChange('nominalCode', v)}>
            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Codes</SelectItem>
              {nominalCodes.map(c => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Income Source Filter */}
        <div className="space-y-2">
          <Label>Income Source</Label>
          <Select value={filters.incomeSource} onValueChange={(v) => handleInputChange('incomeSource', v)}>
            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              {incomeSources.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        
        {/* Include in MTD Filter */}
        <div className="space-y-2">
          <Label>Include in MTD</Label>
          <Select value={filters.includeInMtd} onValueChange={(v) => handleInputChange('includeInMtd', v)}>
            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="yes">Yes</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="flex justify-end">
        <Button variant="ghost" onClick={clearFilters}>
          <X className="mr-2 h-4 w-4" />
          Reset Filters
        </Button>
      </div>
    </div>
  );
}
