
"use client";

import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, PlayCircle, History, Info, Eye, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import type { BankTransaction, Reconciliation } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { 
    Dialog, 
    DialogContent, 
    DialogHeader, 
    DialogTitle, 
    DialogDescription 
} from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import type { DateRange } from 'react-day-picker';
import { Separator } from '@/components/ui/separator';

interface BankReconciliationProps {
  transactions: BankTransaction[];
  bankId: string;
}

export function BankReconciliation({ transactions, bankId }: BankReconciliationProps) {
  const [reconciliationDate, setReconciliationDate] = useState<DateRange | undefined>();
  const [statementBalance, setStatementBalance] = useState<number | string>('');
  const [history, setHistory] = useState<Reconciliation[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [viewingRec, setViewingRec] = useState<Reconciliation | null>(null);
  const { toast } = useToast();
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);

  useEffect(() => {
    const allReconciliations = JSON.parse(localStorage.getItem('reconciliations') || '[]') as Reconciliation[];
    const bankReconciliations = allReconciliations.filter(r => r.bankId === bankId);
    setHistory(bankReconciliations);
  }, [bankId, isHistoryOpen]);


  const calculatedBalance = useMemo(() => {
    const endDate = reconciliationDate?.to;
    if (!endDate || transactions.length === 0) {
      return 0;
    }
    
    const sortedTransactions = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    let lastTransactionBeforeDate = null;
    for (let i = sortedTransactions.length - 1; i >= 0; i--) {
        const transactionDate = new Date(sortedTransactions[i].date);
        if (transactionDate <= endDate) {
            lastTransactionBeforeDate = sortedTransactions[i];
            break;
        }
    }
    
    return lastTransactionBeforeDate ? lastTransactionBeforeDate.balance : 0;

  }, [reconciliationDate, transactions]);

  const difference = useMemo(() => {
    const numericStatementBalance = typeof statementBalance === 'string' ? parseFloat(statementBalance) : statementBalance;
    if (isNaN(numericStatementBalance)) return 0;
    return numericStatementBalance - calculatedBalance;
  }, [statementBalance, calculatedBalance]);

  const handleSubmit = () => {
    const numericStatementBalance = typeof statementBalance === 'string' ? parseFloat(statementBalance) : statementBalance;
    if (difference !== 0) {
      toast({
        variant: 'destructive',
        title: 'Reconciliation Failed',
        description: 'The difference must be £0.00 to submit.',
      });
    } else {
      const newReconciliation: Reconciliation = {
        id: Date.now().toString(),
        bankId,
        fromDate: reconciliationDate!.from?.toISOString() ?? null,
        toDate: reconciliationDate!.to!.toISOString(),
        statementBalance: numericStatementBalance,
        calculatedBalance: calculatedBalance,
      };

      const allReconciliations = JSON.parse(localStorage.getItem('reconciliations') || '[]') as Reconciliation[];
      localStorage.setItem('reconciliations', JSON.stringify([...allReconciliations, newReconciliation]));
      
      toast({
        title: 'Reconciliation Submitted',
        description: `Reconciliation up to ${reconciliationDate?.to ? format(reconciliationDate.to, 'PPP') : ''} has been successfully submitted.`,
      });
      // Reset form
      setReconciliationDate(undefined);
      setStatementBalance('');
    }
  }
  
  const validHistory = useMemo(() => history.filter(rec => rec.toDate && !isNaN(new Date(rec.toDate).getTime())), [history]);


  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Bank Reconciliation</CardTitle>
           <Button variant="outline" onClick={() => setIsHistoryOpen(true)}>
              <History className="mr-2 h-4 w-4" />
              View Previous Reconciliation Logs
           </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Choose a Date Range</Label>
            <Popover open={isDatePopoverOpen} onOpenChange={setIsDatePopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  id="date"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !reconciliationDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {reconciliationDate?.from ? (
                    reconciliationDate.to ? (
                      <>
                        {format(reconciliationDate.from, "LLL dd, y")} -{" "}
                        {format(reconciliationDate.to, "LLL dd, y")}
                      </>
                    ) : (
                      format(reconciliationDate.from, "LLL dd, y")
                    )
                  ) : (
                    <span>Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={reconciliationDate?.from}
                  selected={reconciliationDate}
                  onSelect={setReconciliationDate}
                  numberOfMonths={2}
                />
                <div className="p-2 border-t flex justify-end">
                    <Button onClick={() => setIsDatePopoverOpen(false)}>
                        Next <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
          
          <div className="space-y-4 rounded-lg border p-4">
              <div className="flex justify-between items-center">
                  <Label>Balance Per Below</Label>
                  <span className="font-mono">£{calculatedBalance.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                  <Label htmlFor="statement-balance">Balance Per Statement</Label>
                  <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">£</span>
                      <Input
                          id="statement-balance"
                          type="number"
                          placeholder="100,000.00"
                          value={statementBalance}
                          onChange={(e) => setStatementBalance(e.target.value)}
                          className="w-40 pl-6"
                      />
                  </div>
              </div>
              <div className={cn("flex justify-between items-center font-bold", difference !== 0 ? 'text-destructive' : 'text-green-500')}>
                  <Label>Difference</Label>
                  <span className="font-mono">£{difference.toFixed(2)}</span>
              </div>
          </div>

          <Button onClick={handleSubmit} className="w-full" disabled={!reconciliationDate?.to || statementBalance === '' || difference !== 0}>
            <PlayCircle className="mr-2 h-4 w-4" />
            Submit Reconciliation
          </Button>
        </CardContent>
      </Card>

      <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Reconciliation History</DialogTitle>
            <DialogDescription>A log of your previously submitted bank reconciliations for this account.</DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            {validHistory.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="border-r">Date</TableHead>
                    <TableHead className="text-right border-r">Statement Balance</TableHead>
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {validHistory.sort((a,b) => new Date(b.toDate).getTime() - new Date(a.toDate).getTime()).map(rec => (
                    <TableRow key={rec.id}>
                      <TableCell className="border-r">{format(new Date(rec.toDate), 'PPP')}</TableCell>
                      <TableCell className="text-right font-mono border-r">£{rec.statementBalance.toFixed(2)}</TableCell>
                       <TableCell className="text-center">
                          <Button variant="ghost" size="sm" onClick={() => setViewingRec(rec)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </Button>
                       </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-muted-foreground text-center">No reconciliation history found for this bank account.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      <Dialog open={!!viewingRec} onOpenChange={() => setViewingRec(null)}>
        <DialogContent className="max-w-md">
            {viewingRec && (
                <>
                <DialogHeader>
                    <DialogTitle>Reconciliation Details</DialogTitle>
                    <DialogDescription>Details for the reconciliation on {format(new Date(viewingRec.toDate), 'PPP')}.</DialogDescription>
                </DialogHeader>
                <div className="mt-4 space-y-4">
                    <div className="space-y-2 rounded-lg border p-4">
                         <div className="flex justify-between items-center">
                            <Label>Date Range</Label>
                            <span className="font-mono text-sm">{viewingRec.fromDate ? format(new Date(viewingRec.fromDate), 'PPP') : '...'} - {format(new Date(viewingRec.toDate), 'PPP')}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center">
                            <Label>Balance Per App</Label>
                            <span className="font-mono">£{viewingRec.calculatedBalance.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <Label>Balance Per Statement</Label>
                            <span className="font-mono">£{viewingRec.statementBalance.toFixed(2)}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between items-center font-bold text-green-500">
                            <Label>Difference</Label>
                            <span className="font-mono">£{(viewingRec.statementBalance - viewingRec.calculatedBalance).toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                </>
            )}
        </DialogContent>
      </Dialog>
    </>
  );
}
