
"use client";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { TableCell } from "@/components/ui/table";
import type { BankTransaction, IncomeSource, NominalCode } from "@/lib/types";

interface TransactionActionsProps {
    transaction: BankTransaction;
    incomeSources: IncomeSource[];
    nominalCodes: NominalCode[];
    onUpdate: (transactionId: string, updatedData: Partial<BankTransaction>) => void;
}

export function TransactionActions({ 
    transaction, 
    incomeSources, 
    nominalCodes, 
    onUpdate 
}: TransactionActionsProps) {

    const handleFieldChange = (field: keyof BankTransaction, value: string) => {
        onUpdate(transaction.id, { [field]: value });
    };

    return (
        <>
            <TableCell className="border-r">
                 <Input 
                    value={transaction.additionalDescription} 
                    onChange={(e) => handleFieldChange('additionalDescription', e.target.value)}
                    placeholder="Type description..."
                 />
            </TableCell>
            <TableCell className="border-r">
                <Select value={transaction.nominalCode} onValueChange={(v) => handleFieldChange('nominalCode', v)}>
                    <SelectTrigger>
                        <SelectValue placeholder="Select code" />
                    </SelectTrigger>
                    <SelectContent>
                        {nominalCodes.map(source => (
                            <SelectItem key={source.id} value={source.name}>
                                {source.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </TableCell>
            <TableCell className="border-r">
                <Select value={transaction.incomeSource} onValueChange={(v) => handleFieldChange('incomeSource', v)}>
                    <SelectTrigger>
                        <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent>
                        {incomeSources.map(source => (
                            <SelectItem key={source.id} value={source.name}>
                                {source.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </TableCell>
        </>
    )
}
