
"use client";

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle, ShieldCheck } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

type Step = 'consent' | 'connecting' | 'success';

export function ConnectBankFlow({ bankName, open, onClose }: { bankName: string, open: boolean, onClose: () => void }) {
  const [step, setStep] = useState<Step>('consent');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (open) {
      setStep('consent');
      setProgress(0);
    }
  }, [open]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'connecting' && progress < 100) {
      timer = setTimeout(() => {
        setProgress(prev => {
          const newProgress = prev + Math.random() * 20;
          if (newProgress >= 100) {
            setStep('success');
            return 100;
          }
          return newProgress;
        });
      }, 500);
    }
    return () => clearTimeout(timer);
  }, [step, progress]);


  const handleConsent = () => {
    setStep('connecting');
  };

  const renderContent = () => {
    switch (step) {
      case 'consent':
        return (
          <>
            <DialogHeader>
              <DialogTitle>Connect to {bankName}</DialogTitle>
              <DialogDescription>You will be redirected to {bankName} to authorise the connection.</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
                <div className="flex items-start gap-4 rounded-lg border bg-muted/50 p-4">
                    <ShieldCheck className="h-8 w-8 text-primary" />
                    <div>
                        <h4 className="font-semibold">Your data is safe</h4>
                        <p className="text-sm text-muted-foreground">We use bank-level security to protect your financial data. We will have read-only access and will not store your bank credentials.</p>
                    </div>
                </div>
                 <div className="flex items-center justify-center gap-2 rounded-lg border bg-muted/50 p-4">
                    <p className="text-sm text-muted-foreground">Securely powered by</p>
                    <span className="font-bold text-lg">Yapily</span>
                </div>
                <p className="text-sm text-muted-foreground">
                    By continuing, you agree to allow MTD Simple to access your account information from {bankName} for the next 90 days.
                </p>
            </div>
            <DialogFooter className="sm:justify-between">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={handleConsent}>Continue</Button>
            </DialogFooter>
          </>
        );
      case 'connecting':
        return (
            <>
                <DialogHeader>
                    <DialogTitle>Connecting to {bankName}...</DialogTitle>
                    <DialogDescription>Please wait while we securely connect to your bank. Do not close this window.</DialogDescription>
                </DialogHeader>
                <div className="py-8 flex flex-col items-center justify-center space-y-4">
                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                    <p className="text-muted-foreground">Redirecting to bank... authorising... retrieving accounts...</p>
                    <Progress value={progress} className="w-[60%]" />
                </div>
          </>
        );
      case 'success':
        return (
            <>
                <DialogHeader>
                    <DialogTitle>Connection Successful!</DialogTitle>
                    <DialogDescription>Your {bankName} account has been successfully linked.</DialogDescription>
                </DialogHeader>
                <div className="py-8 flex flex-col items-center justify-center space-y-4">
                    <CheckCircle className="h-16 w-16 text-green-500" />
                    <p className="text-muted-foreground text-center">Your transactions will now be automatically imported into MTD Simple.</p>
                </div>
                 <DialogFooter>
                    <Button onClick={onClose} className="w-full">Done</Button>
                </DialogFooter>
            </>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
}
