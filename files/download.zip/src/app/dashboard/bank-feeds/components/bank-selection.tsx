
"use client";

import { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Landmark, Search, ArrowLeft, CheckCircle } from 'lucide-react';
import { ConnectBankFlow } from './connect-bank-flow';
import type { connectedBanks as ConnectedBanksType } from '@/lib/data';
import { cn } from '@/lib/utils';

const ukBanks = [
  "Monzo", "HSBC", "Barclays", "NatWest", "Revolut", "Lloyds", "Starling Bank",
  "Santander", "Nationwide", "Halifax", "TSB", "Bank of Scotland", "Royal Bank of Scotland",
  "First Direct", "Metro Bank", "Coutts", "Clydesdale Bank", "Yorkshire Bank", "Fire.com"
];

export function BankSelection({ onClose, connectedBanks }: { onClose: () => void, connectedBanks: typeof ConnectedBanksType }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBank, setSelectedBank] = useState<string | null>(null);
  const [isConnectFlowOpen, setIsConnectFlowOpen] = useState(false);

  const connectedBankNames = useMemo(() => connectedBanks.map(b => b.bankName.split(' ')[0]), [connectedBanks]);

  const handleConnectClick = (bankName: string) => {
    setSelectedBank(bankName);
    setIsConnectFlowOpen(true);
  };

  const handleFlowClose = () => {
    setIsConnectFlowOpen(false);
    setSelectedBank(null);
    onClose(); 
  }

  const filteredBanks = ukBanks.filter(bank =>
    bank.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const showSearchedBank = searchTerm && filteredBanks.length === 0;

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
             <Button variant="outline" size="icon" className="h-8 w-8" onClick={onClose}>
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Back</span>
            </Button>
            <div>
              <CardTitle>Connect Bank Feed</CardTitle>
              <CardDescription>Search for your bank to connect your account and automatically import transactions.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for your bank..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredBanks.map(bank => {
              const isConnected = connectedBankNames.includes(bank.split(' ')[0]);
              return (
              <Card 
                key={bank} 
                className={cn(
                    "flex flex-col", 
                    !isConnected && "cursor-pointer hover:border-primary"
                )} 
                onClick={!isConnected ? () => handleConnectClick(bank) : undefined}
              >
                <CardContent className="p-4 flex-grow flex flex-col items-center justify-center text-center">
                  <div className="p-3 bg-muted rounded-full mb-3">
                      <Landmark className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold">{bank}</h3>
                </CardContent>
                <div className="p-2 border-t bg-muted/50">
                    <Button 
                        className="w-full" 
                        disabled={isConnected}
                        variant={isConnected ? 'secondary' : 'default'}
                    >
                      {isConnected && <CheckCircle className="mr-2 h-4 w-4" />}
                      {isConnected ? 'Connected' : 'Connect'}
                    </Button>
                </div>
              </Card>
            )})}
            {showSearchedBank && (
              <Card key={searchTerm} className="flex flex-col border-primary border-2 cursor-pointer" onClick={() => handleConnectClick(searchTerm)}>
                <CardContent className="p-4 flex-grow flex flex-col items-center justify-center text-center">
                  <div className="p-3 bg-muted rounded-full mb-3">
                      <Landmark className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold">{searchTerm}</h3>
                  <p className="text-xs text-muted-foreground mt-1">Not in our list, but you can try to connect.</p>
                </CardContent>
                 <div className="p-2 border-t bg-muted/50">
                   <Button className="w-full">Connect</Button>
                </div>
              </Card>
            )}
            {filteredBanks.length === 0 && !showSearchedBank && (
              <p className="text-muted-foreground col-span-full text-center">No banks found matching your search.</p>
            )}
          </div>
        </CardContent>
      </Card>
      
      {selectedBank && (
        <ConnectBankFlow 
          bankName={selectedBank}
          open={isConnectFlowOpen}
          onClose={handleFlowClose}
        />
      )}
    </>
  );
}
