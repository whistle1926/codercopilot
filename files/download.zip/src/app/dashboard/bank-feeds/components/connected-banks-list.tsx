
"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PlayCircle, MoreHorizontal, RefreshCw, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { connectedBanks } from '@/lib/data';
import Link from 'next/link';

const getStatusBadgeVariant = (status: string) => {
  switch (status) {
    case 'Connected':
      return 'bg-green-500 text-white';
    case 'Expired':
      return 'bg-red-500 text-white';
    default:
      return 'bg-gray-500 text-white';
  }
};

const getExpiryBadgeVariant = (days: number) => {
  if (days <= 0) return 'bg-red-500 text-white';
  if (days <= 7) return 'bg-yellow-500 text-black';
  return 'bg-green-500 text-white';
};

export function ConnectedBanksList() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-[250px] border-r">Bank Name</TableHead>
          <TableHead className="border-r">Bank Feed Status</TableHead>
          <TableHead className="border-r">Date of Bank Feed Expiry</TableHead>
          <TableHead className="text-right border-r">Balance</TableHead>
          <TableHead className="border-r">Date of last Transaction Extracted</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {connectedBanks.map((bank) => (
          <TableRow key={bank.id}>
            <TableCell className="font-medium border-r">
              <div>{bank.bankName}</div>
              <Link href={`/dashboard/bank-feeds/${bank.id}`} className="text-sm text-muted-foreground hover:underline flex items-center gap-1 mt-1">
                <PlayCircle className="h-4 w-4" />
                View Account
              </Link>
            </TableCell>
            <TableCell className="border-r">
              <Badge className={cn(getStatusBadgeVariant(bank.status), 'hover:bg-none rounded-md')}>
                {bank.status}
              </Badge>
            </TableCell>
            <TableCell className="border-r">
              <Badge className={cn(getExpiryBadgeVariant(bank.expiryDays), 'hover:bg-none rounded-md')}>
                {bank.expiryDays > 0 ? `${bank.expiryDays} Days` : 'Expired'}
              </Badge>
            </TableCell>
            <TableCell className="text-right font-mono border-r">£{bank.balance.toFixed(2)}</TableCell>
            <TableCell className="border-r">
              {new Date(bank.lastTransaction).toLocaleDateString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
              })}
            </TableCell>
            <TableCell className="text-right flex items-center justify-end gap-2">
               {bank.status === 'Connected' ? (
                  <Button
                    variant="default"
                    className="bg-green-500 hover:bg-green-600 text-white"
                  >
                    <Check className="mr-2 h-4 w-4" />
                    Connected
                  </Button>
               ) : (
                <Button
                    variant={bank.status === 'Expired' ? 'destructive' : 'outline'}
                  >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Refresh/Reconnect
                  </Button>
               )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="text-destructive">Delete Bank Feed</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
