

"use client";

import { useState, useMemo, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowDown,
  ArrowUp,
  Search,
  MessageSquare,
  Briefcase,
  Bookmark,
  CheckCircle,
  Award,
  ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { initialStaff as initialStaffData, clients as initialClientsData } from '@/lib/data';
import type { StaffMember, Skill, Client } from '@/lib/types';
import { useActiveClient } from '@/hooks/use-active-client';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const availabilityColors = {
  'Available For Hire': 'bg-green-500',
  'Currently Hired': 'bg-red-500',
};

type SortKey = keyof StaffMember | 'rate';
type SortDirection = 'asc' | 'desc';

function SkillBar({ skill }: { skill: Skill }) {
    const levelValues = { 'Intermediate': 60, 'Advanced': 80, 'Expert': 100 };
    const isMtdCertified = skill.name === 'Coder Co-Pilot Certified';
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className={cn("text-sm font-medium", isMtdCertified && "text-primary")}>{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                    <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600', 
                            isMtdCertified && 'bg-primary',
                            skill.level === 'Advanced' && 'bg-blue-100 text-blue-800',
                            skill.level === 'Intermediate' && 'bg-blue-100 text-blue-800'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={levelValues[skill.level]} className={cn("h-2", isMtdCertified && "[&>div]:bg-primary")} />
        </div>
    )
}

function HireDialog({ staff, open, onOpenChange, onHire }: { staff: StaffMember, open: boolean, onOpenChange: (open: boolean) => void, onHire: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Hire {staff.name}</DialogTitle>
          <DialogDescription>
            You are about to hire {staff.name}. This will assign them to your company. Are you sure you want to proceed?
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onHire}>Confirm Hire</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


export default function StaffHubPage() {
  const router = useRouter();
  const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isHireDialogOpen, setIsHireDialogOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<{
    key: SortKey;
    direction: SortDirection;
  } | null>({ key: 'rate', direction: 'asc' });

  const { toast } = useToast();
  const { activeClient, isClientInitialised } = useActiveClient();
  const [savedStaffIds, setSavedStaffIds] = useState<string[]>([]);

  useEffect(() => {
    if (isClientInitialised && activeClient && !activeClient.questionnaireCompleted) {
      router.push('/dashboard/questionnaire');
    }
  }, [activeClient, isClientInitialised, router]);

  const loadData = useCallback(() => {
    const storedStaff = localStorage.getItem('hubStaff');
    let staffList: StaffMember[];
    if (storedStaff) {
      staffList = JSON.parse(storedStaff).filter((s: StaffMember) => s.isVisible);
    } else {
      staffList = initialStaffData.filter(s => s.isVisible);
      localStorage.setItem('hubStaff', JSON.stringify(initialStaffData));
    }
    setAllStaff(staffList);

    if(activeClient) {
        const savedIds = JSON.parse(localStorage.getItem(`saved_staff_${activeClient.id}`) || '[]');
        setSavedStaffIds(savedIds);
    }

  }, [activeClient]);

  useEffect(() => {
    loadData();
    window.addEventListener('storage', loadData);
    return () => window.removeEventListener('storage', loadData);
  }, [loadData]);


  useEffect(() => {
    if (!selectedStaff && allStaff.length > 0) {
      const firstStaff = allStaff.find(s => !s.hiredBy);
      if (firstStaff) setSelectedStaff(firstStaff);
    }
  }, [allStaff, selectedStaff]);

  const allRoles = useMemo(() => {
    const roles = new Set(allStaff.map(s => s.role));
    return Array.from(roles).sort();
  }, [allStaff]);

  const sortedStaff = useMemo(() => {
    let sortableItems = [...allStaff];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const valA = a[sortConfig.key as keyof StaffMember] || 0;
        const valB = b[sortConfig.key as keyof StaffMember] || 0;

        if (valA < valB) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (valA > valB) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [sortConfig, allStaff]);

  const staffToDisplay = useMemo(() => {
    if (!activeClient) return [];
    
    // Combine Team Lead and allocated staff, ensuring no duplicates.
    const teamIds = new Set(activeClient.allocatedStaffIds || []);
    if (activeClient.assignedTeamLeadId) {
        teamIds.add(activeClient.assignedTeamLeadId);
    }

    return sortedStaff.filter(staffMember => {
        const isOnTeam = teamIds.has(staffMember.id);
        if (!isOnTeam) return false;

        const matchesSearch =
            staffMember.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.skills.some((skill) =>
            skill.toLowerCase().includes(searchTerm.toLowerCase())
            );

        const matchesRole =
            roleFilter === 'all' ||
            staffMember.role.toLowerCase().includes(roleFilter.toLowerCase());

        return matchesSearch && matchesRole;
    });
  }, [activeClient, sortedStaff, searchTerm, roleFilter]);
  
  const hiredStaff = useMemo(() => {
      if (!activeClient) return [];
      return allStaff.filter(s => Array.isArray(s.hiredBy) && s.hiredBy.includes(activeClient.id));
  }, [activeClient, allStaff]);


  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortKey) => {
    if (!sortConfig || sortConfig.key !== key) {
      return null;
    }
    return sortConfig.direction === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  const handleHire = () => {
    if (!selectedStaff) return;
    if (!isClientInitialised || !activeClient) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'No active client selected to hire for.',
      });
      return;
    }
    
    const allStaffFromStorage: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
    const updatedAllStaff = allStaffFromStorage.map(s => {
      if (s.id === selectedStaff.id) {
        const currentHiredBy = Array.isArray(s.hiredBy) ? s.hiredBy : (s.hiredBy ? [s.hiredBy] : []);
        if (!currentHiredBy.includes(activeClient.id)) {
            currentHiredBy.push(activeClient.id);
        }
        return { ...s, hiredBy: currentHiredBy, availability: 'Currently Hired' as const };
      }
      return s;
    });

    localStorage.setItem('hubStaff', JSON.stringify(updatedAllStaff));
    
    window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff', newValue: JSON.stringify(updatedAllStaff)}));

    setIsHireDialogOpen(false);
    toast({
      title: 'Success!',
      description: `${selectedStaff.name} has been hired.`,
    });
  };

  const handleSaveForLater = (staffId: string) => {
      if (!activeClient) return;
      const currentSaved = [...savedStaffIds];
      const index = currentSaved.indexOf(staffId);
      
      if (index > -1) {
          currentSaved.splice(index, 1);
           toast({ title: 'Removed', description: 'Staff member removed from your saved list.'});
      } else {
          currentSaved.push(staffId);
          toast({ title: 'Saved!', description: 'Staff member added to your saved list.'});
      }
      setSavedStaffIds(currentSaved);
      localStorage.setItem(`saved_staff_${activeClient.id}`, JSON.stringify(currentSaved));
  }

  const isMtdCertified = selectedStaff?.technicalSkills.some(skill => skill.name === 'Coder Co-Pilot Certified');
  const canHire = activeClient && (activeClient.cashBalance || 0) >= 200;

  if (!isClientInitialised || (activeClient && !activeClient.questionnaireCompleted)) {
    return <div>Loading...</div>;
  }
  
  if (!activeClient) {
    return (
        <Card>
            <CardHeader><CardTitle>Coder Co-Pilot</CardTitle></CardHeader>
            <CardContent><p>Please log in as a company to view staff.</p></CardContent>
        </Card>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-2 space-y-6">
            <Card>
            <CardHeader>
                <div className="flex justify-between items-center">
                <div>
                    <CardTitle className="text-2xl flex items-center gap-2">
                    <Briefcase className="h-6 w-6"/>
                    Recommended Staff
                    </CardTitle>
                    <CardDescription>
                    Your Team Lead has recommended the following professionals for your project.
                    </CardDescription>
                </div>
                </div>
                <div className="mt-4 flex gap-4">
                <div className="relative flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                    placeholder="Search by name, role, or skill..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                    <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by role" />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {allRoles.map(role => (
                        <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                    </SelectContent>
                </Select>
                </div>
            </CardHeader>
            <CardContent className="p-0">
                {staffToDisplay.length > 0 ? (
                    <Table>
                    <TableHeader>
                        <TableRow>
                        <TableHead className="w-[50px]"></TableHead>
                        <TableHead>
                            <button className="flex items-center gap-1" onClick={() => requestSort('name')}>
                                Professional {getSortIcon('name')}
                            </button>
                        </TableHead>
                        <TableHead>
                            <button className="flex items-center gap-1" onClick={() => requestSort('rate')}>
                                Rate {getSortIcon('rate')}
                            </button>
                        </TableHead>
                        <TableHead>Availability</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {staffToDisplay.map((staffMember) => (
                        <TableRow 
                            key={staffMember.id} 
                            className={cn("cursor-pointer", selectedStaff?.id === staffMember.id && "bg-muted")}
                            onClick={() => setSelectedStaff(staffMember)}
                        >
                            <TableCell>
                            <Avatar className="h-10 w-10">
                                <AvatarImage src={staffMember.avatarUrl} alt={staffMember.name} />
                                <AvatarFallback>
                                {staffMember.name
                                    .split(' ')
                                    .map((n) => n[0])
                                    .join('')}
                                </AvatarFallback>
                            </Avatar>
                            </TableCell>
                            <TableCell>
                            <div className="flex items-center gap-2">
                                <div className="font-medium">{staffMember.name}</div>
                                {staffMember.isTeamLead && <Badge variant="outline" className="border-green-500 text-green-700">Your Team Lead</Badge>}
                                {staffMember.verified && <Badge variant="outline" className="border-primary text-primary">Co-Pilot Pro Verified</Badge>}
                            </div>
                            <div className="text-sm text-muted-foreground">
                                {staffMember.role}
                            </div>
                            </TableCell>
                            <TableCell>
                            <div className="font-semibold text-lg">
                                £{staffMember.rate.toFixed(2)}/hr
                            </div>
                            </TableCell>
                            <TableCell>
                            <div className="flex items-center gap-2">
                                <span
                                className={cn(
                                    'h-2.5 w-2.5 rounded-full',
                                    (Array.isArray(staffMember.hiredBy) && staffMember.hiredBy.length > 0) ? availabilityColors['Currently Hired'] : availabilityColors[staffMember.availability]
                                )}
                                />
                                <div>
                                <div>{(Array.isArray(staffMember.hiredBy) && staffMember.hiredBy.length > 0) ? 'Currently Hired' : staffMember.availability}</div>
                                </div>
                            </div>
                            </TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                    </Table>
                ) : (
                    <div className="p-8 text-center text-muted-foreground">
                        Your Team Lead has not allocated any staff for you yet. Please contact them to get started.
                    </div>
                )}
            </CardContent>
            </Card>

            {hiredStaff.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Current Projects & Hired Staff</CardTitle>
                        <CardDescription>An overview of the professionals actively working for your company.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                         <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Professional</TableHead>
                                    <TableHead>Role</TableHead>
                                    <TableHead className="text-right">Rate</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {hiredStaff.map((staffMember) => (
                                    <TableRow key={staffMember.id}>
                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                 <Avatar className="h-8 w-8">
                                                    <AvatarImage src={staffMember.avatarUrl} alt={staffMember.name} />
                                                    <AvatarFallback>
                                                    {staffMember.name
                                                        .split(' ')
                                                        .map((n) => n[0])
                                                        .join('')}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <span className="font-medium">{staffMember.name}</span>
                                            </div>
                                        </TableCell>
                                        <TableCell>{staffMember.role}</TableCell>
                                        <TableCell className="text-right font-mono">£{staffMember.rate.toFixed(2)}/hr</TableCell>
                                        <TableCell className="text-right">
                                            <Button asChild variant="outline" size="sm">
                                                <Link href="/dashboard/hired-staff">
                                                    Manage Tasks <ArrowRight className="ml-2 h-4 w-4" />
                                                </Link>
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                         </Table>
                    </CardContent>
                </Card>
            )}

        </div>
        {selectedStaff && (
          <Card className="lg:col-span-1 sticky top-6">
            <TooltipProvider>
              <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                        <Avatar className="h-20 w-20">
                            <AvatarImage src={selectedStaff.avatarUrl} alt={selectedStaff.name} />
                            <AvatarFallback className="text-3xl">
                                {selectedStaff.name.split(' ').map((n) => n[0]).join('')}
                            </AvatarFallback>
                        </Avatar>
                        <div className="space-y-1">
                            <h3 className="text-2xl font-bold">{selectedStaff.name}</h3>
                            <Badge variant="secondary" className="text-base">{selectedStaff.role}</Badge>
                            <p className="text-sm text-muted-foreground pt-1">{selectedStaff.location}</p>
                        </div>
                    </div>
                  </div>
                   <div className="mt-4 flex flex-col gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="w-full">
                            <Button
                              size="lg"
                              className="w-full"
                              onClick={() => setIsHireDialogOpen(true)}
                              disabled={!!(selectedStaff.hiredBy && selectedStaff.hiredBy.includes(activeClient?.id || '')) || !canHire}
                            >
                              {selectedStaff.hiredBy && selectedStaff.hiredBy.includes(activeClient?.id || '') ? 'Already Hired' : `Hire ${selectedStaff.name.split(' ')[0]}`}
                            </Button>
                          </div>
                        </TooltipTrigger>
                        {!canHire && (
                          <TooltipContent>
                            <p>A minimum balance of £200 is required to hire.</p>
                          </TooltipContent>
                        )}
                      </Tooltip>
                      <Button size="lg" className="w-full" variant="outline" asChild>
                        <Link href={`/dashboard/messages?staffId=${selectedStaff.id}`}>
                          <MessageSquare className="mr-2" /> Message
                        </Link>
                      </Button>
                      <Button 
                        size="lg" 
                        className="w-full" 
                        variant={savedStaffIds.includes(selectedStaff.id) ? "default" : "outline"}
                        onClick={() => handleSaveForLater(selectedStaff.id)}
                      >
                          <Bookmark className="mr-2" /> {savedStaffIds.includes(selectedStaff.id) ? 'Saved' : 'Save for Later'}
                      </Button>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
                      {selectedStaff.isTeamLead && <div className="flex items-center gap-1 font-semibold text-green-700"><CheckCircle className="h-4 w-4" /> Your Team Lead</div>}
                      {selectedStaff.verified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Co-Pilot Pro Verified</div>}
                      {isMtdCertified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Co-Pilot Approved</div>}
                      {selectedStaff.premium && <div className="flex items-center gap-1 font-semibold text-amber-500"><Award className="h-4 w-4" /> Top Rated By Employers</div>}
                  </div>
              </CardContent>
            </TooltipProvider>
              <CardContent className="space-y-4">
                  <div className="space-y-6 text-sm">
                      <div>
                          <h4 className="font-semibold mb-2 text-base">About</h4>
                          <p className="text-muted-foreground">{selectedStaff.about}</p>
                      </div>
                      
                      <div>
                          <h4 className="font-semibold mb-2 text-base">Skills & Expertise</h4>
                          <div className="grid grid-cols-1 gap-6">
                              <div className="space-y-3">
                                  <h5 className="font-medium">Technical Skills</h5>
                                  {selectedStaff.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                              <div className="space-y-3">
                                  <h5 className="font-medium">Soft Skills</h5>
                                  {selectedStaff.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                          </div>
                      </div>
                  </div>
              </CardContent>
          </Card>
        )}
      </div>
       {selectedStaff && <HireDialog staff={selectedStaff} open={isHireDialogOpen} onOpenChange={setIsHireDialogOpen} onHire={handleHire} />}
    </div>
  );
}
