

"use client";

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuPortal,
} from '@/components/ui/dropdown-menu';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useActiveClient } from '@/hooks/use-active-client';
import { useEffect, useState } from 'react';
import type { StaffMember, Client, UserStatus } from '@/lib/types';
import { Circle } from 'lucide-react';

const statusColors: Record<UserStatus, string> = {
    Online: 'bg-green-500',
    Offline: 'bg-gray-500',
    Busy: 'bg-yellow-500',
}

export function UserNav() {
  const pathname = usePathname();
  const router = useRouter();
  const { activeClient, setActiveClient, isClientInitialised } = useActiveClient();
  const [loggedInStaff, setLoggedInStaff] = useState<StaffMember | null>(null);

  const isSuperAdmin = pathname.includes('/super-admin') && !activeClient;
  const isStaffDashboard = pathname.startsWith('/staff-dashboard');
  const isTeamManagerDashboard = pathname.startsWith('/team-manager-dashboard');
  
  const [userStatus, setUserStatus] = useState<UserStatus>('Online');


  useEffect(() => {
    // Load staff or client data and set initial status
    if (isStaffDashboard || isTeamManagerDashboard) {
      const staffId = sessionStorage.getItem('loggedInStaffId');
      if (staffId) {
        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const member = allStaff.find(s => s.id === staffId);
        setLoggedInStaff(member || null);
        if (member?.status) setUserStatus(member.status);
      }
    } else if(activeClient) {
        // The client's `status` ('Active'/'Inactive') is different from the desired UI status ('Online'/'Offline').
        // We'll manage UI status separately for a better user experience.
        const storedStatus = localStorage.getItem(`client_status_${activeClient.id}`);
        if (storedStatus) {
            setUserStatus(storedStatus as UserStatus);
        } else {
            setUserStatus('Online'); // Default to online if no status is saved
        }
    } else if (isSuperAdmin) {
        setUserStatus('Online');
    }
  }, [isStaffDashboard, isTeamManagerDashboard, activeClient, isSuperAdmin]);
  
  const handleLogout = () => {
    if (isStaffDashboard || isTeamManagerDashboard) {
      sessionStorage.removeItem('loggedInStaffId');
      router.push(isTeamManagerDashboard ? '/team-manager-login' : '/staff-login');
    } else {
      setActiveClient(null);
      router.push('/');
    }
  };
  
  const handleStatusChange = (newStatus: UserStatus) => {
    setUserStatus(newStatus);
    if((isStaffDashboard || isTeamManagerDashboard) && loggedInStaff) {
        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const updatedStaff = allStaff.map(s => s.id === loggedInStaff.id ? {...s, status: newStatus} : s);
        localStorage.setItem('hubStaff', JSON.stringify(updatedStaff));
    } else if (activeClient) {
       localStorage.setItem(`client_status_${activeClient.id}`, newStatus);
    }
  }

  if (!isClientInitialised && !isStaffDashboard && !isTeamManagerDashboard) {
    return null;
  }

  let userName: string;
  let userEmail: string;
  let avatarFallback: string;
  let profileLink: string;

  if (isStaffDashboard) {
      userName = loggedInStaff?.name || 'Staff';
      userEmail = loggedInStaff?.email || 'staff@example.com';
      avatarFallback = loggedInStaff?.name.split(' ').map(n => n[0]).join('') || 'S';
      profileLink = '/staff-dashboard/profile';
  } else if (isTeamManagerDashboard) {
      userName = loggedInStaff?.name || 'Team Manager';
      userEmail = loggedInStaff?.email || 'manager@example.com';
      avatarFallback = loggedInStaff?.name.split(' ').map(n => n[0]).join('') || 'TM';
      profileLink = '/team-manager-dashboard/profile';
  } else if (isSuperAdmin) {
      userName = 'Super Admin';
      userEmail = 'super.admin@example.com';
      avatarFallback = 'SA';
      profileLink = '/dashboard/profile';
  } else {
      userName = activeClient?.mainContactPerson || 'Accountant';
      userEmail = activeClient?.email || 'accountant@example.com';
      avatarFallback = userName?.charAt(0) || 'A';
      profileLink = '/dashboard/profile';
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-8 w-8 rounded-full">
          <Avatar className="h-9 w-9">
            <AvatarImage src={`https://picsum.photos/seed/${userEmail}/40/40`} alt="@accountant" data-ai-hint="professional portrait" />
            <AvatarFallback>{avatarFallback}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{userName}</p>
            <p className="text-xs leading-none text-muted-foreground">
              {userEmail}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
           <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              <div className="flex items-center gap-2">
                <Circle className={`h-2.5 w-2.5 fill-current ${statusColors[userStatus]}`} />
                <span>{userStatus}</span>
              </div>
            </DropdownMenuSubTrigger>
            <DropdownMenuPortal>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => handleStatusChange('Online')}>
                    <Circle className={`mr-2 h-2.5 w-2.5 fill-current ${statusColors.Online}`} />
                    <span>Online</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange('Busy')}>
                    <Circle className={`mr-2 h-2.5 w-2.5 fill-current ${statusColors.Busy}`} />
                    <span>Busy</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange('Offline')}>
                    <Circle className={`mr-2 h-2.5 w-2.5 fill-current ${statusColors.Offline}`} />
                    <span>Offline</span>
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuPortal>
          </DropdownMenuSub>

          <DropdownMenuItem asChild>
            <Link href={profileLink}>Profile</Link>
          </DropdownMenuItem>
          {!isSuperAdmin && !isStaffDashboard && !isTeamManagerDashboard && (
            <DropdownMenuItem asChild>
              <Link href="/dashboard/billing">Billing</Link>
            </DropdownMenuItem>
          )}
          <DropdownMenuItem asChild>
             <Link href={isSuperAdmin ? "/dashboard/super-admin/company-settings" : "/dashboard/settings"}>Settings</Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleLogout}>
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
