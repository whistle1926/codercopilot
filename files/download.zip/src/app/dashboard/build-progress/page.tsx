

"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format, formatDistanceToNowStrict, setHours, setMinutes, setSeconds } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PlusCircle, Edit, Trash2, CalendarIcon, Timer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';


const initialProgressLog = [
  {
    id: 1,
    date: '2025-09-26T10:00:00',
    author: 'Admin',
    tags: ['UI/UX', 'Reporting'],
    title: 'Finalizing UI for New Reporting Module',
    content: 'We are putting the finishing touches on the new reporting module. The UI has been redesigned for a more intuitive user experience, and we are excited to get this into your hands.',
    expectedCompletionDate: '2025-10-15T00:00:00',
  },
  {
    id: 2,
    date: '2025-09-24T15:30:00',
    author: 'Admin',
    tags: ['API', 'Bank Feeds', 'Completed'],
    title: 'API Integration for Bank Feeds Complete',
    content: 'The final phase of API integration for our new open banking partner has been completed and tested. This will bring support for 5 new major banks.',
    expectedCompletionDate: null,
  },
  {
    id: 3,
    date: '2025-09-22T11:00:00',
    author: 'Admin',
    tags: ['Performance'],
    title: 'Performance Optimization Pass',
    content: 'This week we are focusing on performance across the app, with a particular focus on speeding up the dashboard loading time and invoice creation flow.',
    expectedCompletionDate: '2025-09-29T00:00:00',
  },
];

type ProgressLogItem = Omit<typeof initialProgressLog[0], 'expectedCompletionDate'> & {
    expectedCompletionDate: string | null;
};


const TimeDisplay = ({ time, label }: { time: string, label: string }) => (
    <div className="flex flex-col items-center justify-center bg-primary text-primary-foreground rounded-lg p-4 w-24 h-24">
        <span className="text-4xl font-bold">{time}</span>
        <span className="text-xs uppercase tracking-wider">{label}</span>
    </div>
);

function Countdown({ nextBuildDate }: { nextBuildDate: Date }) {
  const [timeLeft, setTimeLeft] = useState({
    days: "00",
    hours: "00",
    minutes: "00",
    seconds: "00",
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const distance = nextBuildDate.getTime() - now.getTime();

      if (distance < 0) {
        clearInterval(timer);
        setTimeLeft({ days: "00", hours: "00", minutes: "00", seconds: "00" });
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setTimeLeft({
        days: String(days).padStart(2, '0'),
        hours: String(hours).padStart(2, '0'),
        minutes: String(minutes).padStart(2, '0'),
        seconds: String(seconds).padStart(2, '0'),
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [nextBuildDate]);

  return (
    <div className="flex gap-4 sm:gap-8">
        <TimeDisplay time={timeLeft.days} label="Days" />
        <TimeDisplay time={timeLeft.hours} label="Hours" />
        <TimeDisplay time={timeLeft.minutes} label="Minutes" />
        <TimeDisplay time={timeLeft.seconds} label="Seconds" />
    </div>
  );
}


function LogForm({ logItem, onSave, onCancel }: { logItem?: ProgressLogItem | null, onSave: (item: Omit<ProgressLogItem, 'id' | 'author'>, setAsMainCountdown: boolean) => void, onCancel: () => void }) {
    const [title, setTitle] = useState(logItem?.title || '');
    const [content, setContent] = useState(logItem?.content || '');
    const [tags, setTags] = useState(logItem?.tags?.join(', ') || '');
    const [expectedDate, setExpectedDate] = useState<Date | undefined>(logItem?.expectedCompletionDate ? new Date(logItem.expectedCompletionDate) : undefined);
    
    const getInitialTime = () => {
        if (logItem?.expectedCompletionDate) {
            const d = new Date(logItem.expectedCompletionDate);
            const hour24 = d.getHours();
            const minute = d.getMinutes();
            const period = hour24 >= 12 ? 'PM' : 'AM';
            let hour12 = hour24 % 12;
            if (hour12 === 0) hour12 = 12;
            return { hour: hour12.toString(), minute: minute.toString().padStart(2, '0'), period };
        }
        return { hour: '9', minute: '00', period: 'AM' };
    };
    
    const [expectedTime, setExpectedTime] = useState(getInitialTime());
    
    const [postDate, setPostDate] = useState<Date | undefined>(logItem?.date ? new Date(logItem.date) : new Date());
    const [setAsMainCountdown, setSetAsMainCountdown] = useState(false);

    const handleSubmit = () => {
        let finalExpectedDate = null;
        if (expectedDate) {
            let hour = parseInt(expectedTime.hour, 10);
            if (isNaN(hour) || hour < 1 || hour > 12) hour = 12;
            let minute = parseInt(expectedTime.minute, 10);
            if (isNaN(minute) || minute < 0 || minute > 59) minute = 0;

            if (expectedTime.period === 'PM' && hour !== 12) {
                hour += 12;
            }
            if (expectedTime.period === 'AM' && hour === 12) {
                hour = 0;
            }
            
            const withTime = setSeconds(setMinutes(setHours(expectedDate, hour), minute), 0);
            finalExpectedDate = withTime.toISOString();
        }

        onSave({ title, content, tags: tags.split(',').map(t => t.trim()).filter(Boolean), expectedCompletionDate: finalExpectedDate, date: postDate ? postDate.toISOString() : new Date().toISOString() }, setAsMainCountdown);
    };

    return (
        <div className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="content">Content</Label>
                <Textarea id="content" value={content} onChange={(e) => setContent(e.target.value)} rows={5} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="tags">Tags (comma-separated)</Label>
                <Input id="tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="e.g., UI/UX, API, Performance" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div className="space-y-2">
                    <Label htmlFor="post-date">Post Date</Label>
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                id="post-date"
                                variant={"outline"}
                                className={cn(
                                    "w-full justify-start text-left font-normal",
                                    !postDate && "text-muted-foreground"
                                )}
                            >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {postDate ? format(postDate, "PPP") : <span>Pick a date</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                            <Calendar
                                mode="single"
                                selected={postDate}
                                onSelect={setPostDate}
                                initialFocus
                            />
                        </PopoverContent>
                    </Popover>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="expected-date">Expected Completion Date (Optional)</Label>
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                id="expected-date"
                                variant={"outline"}
                                className={cn(
                                    "w-full justify-start text-left font-normal",
                                    !expectedDate && "text-muted-foreground"
                                )}
                            >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {expectedDate ? format(expectedDate, "PPP") : <span>Pick a date</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                            <Calendar
                                mode="single"
                                selected={expectedDate}
                                onSelect={setExpectedDate}
                                initialFocus
                            />
                        </PopoverContent>
                    </Popover>
                    {expectedDate && (
                         <div className="flex items-center gap-2 pt-2">
                            <div className="grid w-full items-center gap-1.5">
                                <Label htmlFor="hour">Hour (UK)</Label>
                                <Input type="text" id="hour" value={expectedTime.hour} onChange={e => setExpectedTime(t => ({...t, hour: e.target.value}))} />
                            </div>
                             <div className="grid w-full items-center gap-1.5">
                                <Label htmlFor="minute">Minute</Label>
                                <Input type="text" id="minute" value={expectedTime.minute} onChange={e => setExpectedTime(t => ({...t, minute: e.target.value}))} />
                            </div>
                            <div className="grid w-auto items-end gap-1.5">
                                <Select value={expectedTime.period} onValueChange={(value) => setExpectedTime(t => ({...t, period: value}))}>
                                    <SelectTrigger className="w-full">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="AM">AM</SelectItem>
                                        <SelectItem value="PM">PM</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <div className="flex items-center space-x-2 pt-4">
                <Checkbox 
                    id="main-countdown-toggle" 
                    checked={setAsMainCountdown} 
                    onCheckedChange={(checked) => setSetAsMainCountdown(!!checked)}
                    disabled={!expectedDate}
                />
                <Label 
                    htmlFor="main-countdown-toggle" 
                    className={cn(!expectedDate && "text-muted-foreground cursor-not-allowed")}
                >
                    Set this as the main countdown timer
                </Label>
            </div>
             <DialogFooter>
                <Button variant="outline" onClick={onCancel}>Cancel</Button>
                <Button onClick={handleSubmit}>Save Update</Button>
            </DialogFooter>
        </div>
    )
}

export default function BuildProgressPage() {
    const { toast } = useToast();
    const [progressLog, setProgressLog] = useState<ProgressLogItem[]>([]);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingLog, setEditingLog] = useState<ProgressLogItem | null>(null);
    const [nextBuildDate, setNextBuildDate] = useState(new Date('2025-10-31T09:00:00'));


    useEffect(() => {
        const storedLog = localStorage.getItem('progressLog');
        if (storedLog) {
            setProgressLog(JSON.parse(storedLog));
        } else {
            setProgressLog(initialProgressLog);
        }

        const storedDate = localStorage.getItem('nextBuildDate');
        if (storedDate) {
            setNextBuildDate(new Date(storedDate));
        }
    }, []);

    const saveLog = (log: ProgressLogItem[]) => {
        const sortedLog = log.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setProgressLog(sortedLog);
        localStorage.setItem('progressLog', JSON.stringify(sortedLog));
    };

    const handleSave = (itemData: Omit<ProgressLogItem, 'id' | 'author'>, setAsMainCountdown: boolean) => {
        if (editingLog) {
            const updatedLog = progressLog.map(item => 
                item.id === editingLog.id ? { ...editingLog, ...itemData } : item
            );
            saveLog(updatedLog);
            toast({ title: 'Update Saved', description: `Changes to "${itemData.title}" have been saved.` });
        } else {
            const newItem: ProgressLogItem = {
                id: Date.now(),
                author: 'Admin',
                ...itemData,
            };
            saveLog([newItem, ...progressLog]);
            toast({ title: 'New Update Added', description: `"${itemData.title}" has been published.` });
        }

        if (setAsMainCountdown && itemData.expectedCompletionDate) {
            const newDate = new Date(itemData.expectedCompletionDate);
            setNextBuildDate(newDate);
            localStorage.setItem('nextBuildDate', newDate.toISOString());
            toast({ title: "Main Countdown Updated", description: `The countdown is now set to ${format(newDate, 'PPP HH:mm')}.`});
        }

        setIsFormOpen(false);
        setEditingLog(null);
    };
    
    const handleDelete = (id: number) => {
        const updatedLog = progressLog.filter(item => item.id !== id);
        saveLog(updatedLog);
        toast({ title: 'Update Deleted' });
    };

    const openForm = (logItem: ProgressLogItem | null = null) => {
        setEditingLog(logItem);
        setIsFormOpen(true);
    };

    return (
        <div className="space-y-8">
            <Card>
                <CardHeader className="text-center">
                    <CardTitle className="text-3xl">Next Build Deployment</CardTitle>
                    <CardDescription>
                        The next scheduled build is on {format(nextBuildDate, 'EEEE, dd MMMM yyyy \'at\' HH:mm')}. Here is the live countdown.
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex items-center justify-center py-8">
                    <Countdown nextBuildDate={nextBuildDate} />
                </CardContent>
            </Card>

            <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
                 <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{editingLog ? 'Edit' : 'Add New'} Progress Update</DialogTitle>
                        <DialogDescription>
                            Fill in the details below to inform users about development progress.
                        </DialogDescription>
                    </DialogHeader>
                    <LogForm 
                        logItem={editingLog} 
                        onSave={handleSave} 
                        onCancel={() => { setIsFormOpen(false); setEditingLog(null); }} 
                    />
                </DialogContent>
            </Dialog>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Progress Log</CardTitle>
                        <CardDescription>Updates and notes from the development team.</CardDescription>
                    </div>
                    <Button onClick={() => openForm()}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add New Update
                    </Button>
                </CardHeader>
                <CardContent className="space-y-6">
                    {progressLog.length > 0 ? progressLog.map((log, index) => (
                        <div key={log.id}>
                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                                <div>
                                    <h3 className="text-xl font-semibold">{log.title}</h3>
                                    <div className="text-sm text-muted-foreground mt-1">
                                        <span>{formatDistanceToNowStrict(new Date(log.date), { addSuffix: true })}</span> by <span className="font-medium text-foreground">{log.author}</span>
                                        {log.expectedCompletionDate && (
                                            <span className="ml-2 pl-2 border-l">Expected: {format(new Date(log.expectedCompletionDate), 'dd MMM yyyy, HH:mm')}</span>
                                        )}
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                     <Button variant="ghost" size="icon" onClick={() => openForm(log)}>
                                        <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => handleDelete(log.id)}>
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                </div>
                            </div>
                            <p className="text-muted-foreground mt-2">{log.content}</p>
                            <div className="flex gap-2 mt-3">
                                {log.tags.map(tag => (
                                    <Badge key={tag} variant={tag === 'Completed' ? 'default' : 'secondary'} className={tag === 'Completed' ? 'bg-green-500' : ''}>
                                        {tag}
                                    </Badge>
                                ))}
                            </div>
                            {index < progressLog.length - 1 && <Separator className="my-6" />}
                        </div>
                    )) : (
                        <div className="text-center text-muted-foreground py-8">
                            No progress updates have been posted yet.
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
