import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function BillingPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Billing</CardTitle>
        <CardDescription>Manage your billing and subscription.</CardDescription>
      </CardHeader>
      <CardContent>
        <p>Billing page content coming soon.</p>
      </CardContent>
    </Card>
  );
}
