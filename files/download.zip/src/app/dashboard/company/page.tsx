

"use client";

import { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowDown,
  ArrowUp,
  Search,
  MessageSquare,
  Briefcase,
  Upload,
  PlusCircle,
  Star,
  CheckCircle,
  Clock,
  Award,
  Edit,
  Trash2,
  Check,
  ChevronsUpDown,
  Bookmark,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { initialStaff as initialStaffData } from '@/lib/data';
import type { StaffMember, Skill, Task, Client } from '@/lib/types';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import { useActiveClient } from '@/hooks/use-active-client';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';


interface StaffTasks {
    [staffId: string]: Task[];
}


const availabilityColors = {
  'Available For Hire': 'bg-green-500',
  'Currently Hired': 'bg-red-500',
};

type SortKey = keyof StaffMember | 'rate';
type SortDirection = 'asc' | 'desc';

function SkillBar({ skill }: { skill: Skill }) {
    const levelValues = { 'Intermediate': 60, 'Advanced': 80, 'Expert': 100 };
    const isMtdCertified = skill.name === 'MTD Simple Certified';
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className={cn("text-sm font-medium", isMtdCertified && "text-primary")}>{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                    <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600', 
                            isMtdCertified && 'bg-primary',
                            skill.level === 'Advanced' && 'bg-blue-100 text-blue-800',
                            skill.level === 'Intermediate' && 'bg-blue-100 text-blue-800'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={levelValues[skill.level]} className={cn("h-2", isMtdCertified && "[&>div]:bg-primary")} />
        </div>
    )
}

function HireDialog({ staff, open, onOpenChange, onHire }: { staff: StaffMember, open: boolean, onOpenChange: (open: boolean) => void, onHire: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Hire {staff.name}</DialogTitle>
          <DialogDescription>
            You are about to hire {staff.name}. This will assign them to your company. Are you sure you want to proceed?
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onHire}>Confirm Hire</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


export default function StaffHubPage() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isHireDialogOpen, setIsHireDialogOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<{
    key: SortKey;
    direction: SortDirection;
  } | null>({ key: 'rate', direction: 'asc' });

  const { toast } = useToast();
  const { activeClient, isClientInitialised } = useActiveClient();

  const loadData = useCallback(() => {
    const storedStaff = localStorage.getItem('hubStaff');
    let staffList: StaffMember[];
    if (storedStaff) {
      staffList = JSON.parse(storedStaff).filter((s: StaffMember) => s.isVisible);
    } else {
      staffList = initialStaffData.filter(s => s.isVisible);
      localStorage.setItem('hubStaff', JSON.stringify(initialStaffData));
    }
    setStaff(staffList);

  }, []);

  useEffect(() => {
    loadData();
    window.addEventListener('storage', loadData);
    return () => window.removeEventListener('storage', loadData);
  }, [loadData]);


  useEffect(() => {
    if (!selectedStaff && staff.length > 0) {
      const firstStaff = staff.find(s => !s.hiredBy);
      if (firstStaff) setSelectedStaff(firstStaff);
    }
  }, [staff, selectedStaff]);

  const sortedStaff = useMemo(() => {
    let sortableItems = [...staff];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const valA = a[sortConfig.key] || 0;
        const valB = b[sortConfig.key] || 0;

        if (valA < valB) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (valA > valB) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [sortConfig, staff]);

  const filteredStaff = useMemo(() => {
    return sortedStaff.filter(
      (staffMember) => {
        const matchesSearch =
            staffMember.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.skills.some((skill) =>
            skill.toLowerCase().includes(searchTerm.toLowerCase())
            );

        const matchesRole =
            roleFilter === 'all' ||
            staffMember.role.toLowerCase().includes(roleFilter.toLowerCase());

        return matchesSearch && matchesRole;
      }
    );
  }, [searchTerm, sortedStaff, roleFilter]);

  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortKey) => {
    if (!sortConfig || sortConfig.key !== key) {
      return null;
    }
    return sortConfig.direction === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  const handleHire = () => {
    if (!selectedStaff) return;
    if (!isClientInitialised || !activeClient) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'No active client selected to hire for.',
      });
      return;
    }
    
    const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
    const updatedAllStaff = allStaff.map(s => 
      s.id === selectedStaff.id ? { ...s, hiredBy: activeClient.id, availability: 'Currently Hired' as const } : s
    );
    localStorage.setItem('hubStaff', JSON.stringify(updatedAllStaff));
    
    window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff', newValue: JSON.stringify(updatedAllStaff)}));

    setIsHireDialogOpen(false);
    toast({
      title: 'Success!',
      description: `${selectedStaff.name} has been hired.`,
    });
  };

  const isMtdCertified = selectedStaff?.technicalSkills.some(skill => skill.name === 'MTD Simple Certified');
  const canHire = activeClient && (activeClient.cashBalance || 0) >= 200;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Briefcase className="h-6 w-6"/>
                  Staff Hub
                </CardTitle>
                <CardDescription>
                  Find and hire from our pool of vetted professionals.
                </CardDescription>
              </div>
            </div>
            <div className="mt-4 flex gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name, role, or skill..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="Accountant">Accountant</SelectItem>
                  <SelectItem value="Bookkeeper">Bookkeeper</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('name')}>
                          Professional {getSortIcon('name')}
                      </button>
                  </TableHead>
                  <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('rate')}>
                          Rate {getSortIcon('rate')}
                      </button>
                  </TableHead>
                  <TableHead>Availability</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStaff.map((staffMember) => (
                  <TableRow 
                      key={staffMember.id} 
                      className={cn("cursor-pointer", selectedStaff?.id === staffMember.id && "bg-muted")}
                      onClick={() => setSelectedStaff(staffMember)}
                  >
                    <TableCell>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={staffMember.avatarUrl} alt={staffMember.name} />
                        <AvatarFallback>
                          {staffMember.name
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                          <div className="font-medium">{staffMember.name}</div>
                          {staffMember.verified && <Badge variant="outline" className="border-primary text-primary">Staff Hub Pro Verified</Badge>}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {staffMember.role}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-semibold text-lg">
                        £{staffMember.rate.toFixed(2)}/hr
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            'h-2.5 w-2.5 rounded-full',
                            staffMember.hiredBy ? 'bg-red-500' : availabilityColors[staffMember.availability]
                          )}
                        />
                        <div>
                          <div>{staffMember.hiredBy ? 'Currently Hired' : staffMember.availability}</div>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        {selectedStaff && (
          <Card className="lg:col-span-1 sticky top-6">
            <TooltipProvider>
              <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                        <Avatar className="h-20 w-20">
                            <AvatarImage src={selectedStaff.avatarUrl} alt={selectedStaff.name} />
                            <AvatarFallback className="text-3xl">
                                {selectedStaff.name.split(' ').map((n) => n[0]).join('')}
                            </AvatarFallback>
                        </Avatar>
                        <div className="space-y-1">
                            <h3 className="text-2xl font-bold">{selectedStaff.name}</h3>
                            <Badge variant="secondary" className="text-base">{selectedStaff.role}</Badge>
                            <p className="text-sm text-muted-foreground pt-1">{selectedStaff.location}</p>
                        </div>
                    </div>
                  </div>
                   <div className="mt-4 flex flex-col gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="w-full">
                            <Button
                              size="lg"
                              className="w-full"
                              onClick={() => setIsHireDialogOpen(true)}
                              disabled={!!selectedStaff.hiredBy || !canHire}
                            >
                              {selectedStaff.hiredBy ? 'Already Hired' : `Hire ${selectedStaff.name.split(' ')[0]}`}
                            </Button>
                          </div>
                        </TooltipTrigger>
                        {!canHire && (
                          <TooltipContent>
                            <p>A minimum balance of £200 is required to hire.</p>
                          </TooltipContent>
                        )}
                      </Tooltip>
                      <Button size="lg" className="w-full" variant="outline" asChild>
                        <Link href={`/dashboard/messages?staffId=${selectedStaff.id}`}>
                          <MessageSquare className="mr-2" /> Message
                        </Link>
                      </Button>
                      <Button size="lg" className="w-full" variant="outline">
                          <Bookmark className="mr-2" /> Save for Later
                      </Button>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
                      {selectedStaff.verified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Staff Hub Pro Verified</div>}
                      {isMtdCertified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> MTD Simple Approved</div>}
                      {selectedStaff.premium && <div className="flex items-center gap-1 font-semibold text-amber-500"><Award className="h-4 w-4" /> Top Rated By Employers</div>}
                  </div>
              </CardContent>
            </TooltipProvider>
              <CardContent className="space-y-4">
                  <div className="space-y-6 text-sm">
                      <div>
                          <h4 className="font-semibold mb-2 text-base">About</h4>
                          <p className="text-muted-foreground">{selectedStaff.about}</p>
                      </div>
                      
                      <div>
                          <h4 className="font-semibold mb-2 text-base">Skills & Expertise</h4>
                          <div className="grid grid-cols-1 gap-6">
                              <div className="space-y-3">
                                  <h5 className="font-medium">Technical Skills</h5>
                                  {selectedStaff.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                              <div className="space-y-3">
                                  <h5 className="font-medium">Soft Skills</h5>
                                  {selectedStaff.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                          </div>
                      </div>
                  </div>
              </CardContent>
          </Card>
        )}
      </div>
       {selectedStaff && <HireDialog staff={selectedStaff} open={isHireDialogOpen} onOpenChange={setIsHireDialogOpen} onHire={handleHire} />}
    </div>
  );
}
