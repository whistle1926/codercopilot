

"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle, ShieldCheck } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { DialogHeader, DialogTitle, DialogDescription, DialogContent, DialogFooter } from '@/components/ui/dialog';

type Step = 'consent' | 'connecting' | 'success';

interface PaymentFlowProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export function PaymentFlow({ onSuccess, onCancel }: PaymentFlowProps) {
  const [step, setStep] = useState<Step>('consent');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'connecting' && progress < 100) {
      timer = setTimeout(() => {
        setProgress(prev => {
          const newProgress = prev + Math.random() * 20;
          if (newProgress >= 100) {
            setStep('success');
            return 100;
          }
          return newProgress;
        });
      }, 500);
    }
    return () => clearTimeout(timer);
  }, [step, progress]);
  
  useEffect(() => {
    if (step === 'success') {
        // Wait a bit before calling success to show the success message
        const timer = setTimeout(() => {
            onSuccess();
        }, 1500);
        return () => clearTimeout(timer);
    }
  }, [step, onSuccess]);


  const handleConsent = () => {
    setStep('connecting');
  };

  switch (step) {
    case 'consent':
      return (
        <>
          <DialogHeader className="text-center">
            <DialogTitle>Pay with Open Banking</DialogTitle>
            <DialogDescription>You will be redirected to your bank to authorise the payment.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
              <div className="flex items-start gap-4 rounded-lg border bg-muted/50 p-4">
                  <ShieldCheck className="h-8 w-8 text-primary flex-shrink-0" />
                  <div>
                      <h4 className="font-semibold">Safe and Secure</h4>
                      <p className="text-sm text-muted-foreground">We use Yapily to securely connect to your bank. We will not see or store your bank credentials.</p>
                  </div>
              </div>
              <div className="flex items-center justify-center gap-2 rounded-lg border bg-muted/50 p-4">
                  <p className="text-sm text-muted-foreground">Securely powered by</p>
                  <span className="font-bold text-lg">Yapily</span>
              </div>
              <p className="text-sm text-muted-foreground">
                  By continuing, you agree to make a one-time payment.
              </p>
          </div>
          <DialogFooter className="justify-between">
            <Button variant="outline" onClick={onCancel}>Cancel</Button>
            <Button onClick={handleConsent}>Continue to Payment</Button>
          </DialogFooter>
        </>
      );
    case 'connecting':
      return (
          <>
              <DialogHeader>
                  <DialogTitle>Connecting to your bank...</DialogTitle>
                  <DialogDescription>Please wait while we securely redirect you. Do not close this window.</DialogDescription>
              </DialogHeader>
              <div className="py-8 flex flex-col items-center justify-center space-y-4">
                  <Loader2 className="h-12 w-12 animate-spin text-primary" />
                  <p className="text-muted-foreground">Redirecting... authorising payment... confirming...</p>
                  <Progress value={progress} className="w-[60%]" />
              </div>
        </>
      );
    case 'success':
      return (
          <>
              <DialogHeader className="text-center">
                  <DialogTitle>Payment Successful!</DialogTitle>
              </DialogHeader>
              <DialogContent className="py-8 flex flex-col items-center justify-center space-y-4">
                  <CheckCircle className="h-16 w-16 text-green-500" />
                  <p className="text-muted-foreground text-center">
                      The professional has been hired and notified.
                  </p>
              </DialogContent>
          </>
      );
  }
}
