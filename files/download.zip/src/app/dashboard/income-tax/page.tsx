
"use client";

import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Briefcase, Home, ArrowLeft, Landmark, Banknote } from 'lucide-react';
import { LandlordReturnForm } from './components/landlord-return-form';
import { SelfEmployedReturnForm } from './components/self-employed-return-form';
import { IncomeTaxSubmission } from './components/income-tax-submission';
import { useActiveClient } from '@/hooks/use-active-client';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

type SubmissionType = 'self-employed' | 'landlord' | null;
type SelfEmployedSubmissionMethod = 'detailed' | 'transactions' | null;

export default function IncomeTaxPage() {
    const [submissionType, setSubmissionType] = useState<SubmissionType>(null);
    const [selfEmployedMethod, setSelfEmployedMethod] = useState<SelfEmployedSubmissionMethod>(null);
    const { activeClient } = useActiveClient();

    const handleBack = () => {
        if (selfEmployedMethod) {
            setSelfEmployedMethod(null);
        } else if (submissionType) {
            setSubmissionType(null);
        }
    };
    
    if (submissionType === 'self-employed') {
        if (selfEmployedMethod === 'detailed') {
            return <SelfEmployedReturnForm onBack={handleBack} />;
        }
        if (selfEmployedMethod === 'transactions') {
            return <IncomeTaxSubmission onBack={handleBack} />;
        }
        return (
            <Card>
                <CardHeader>
                     <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>File for Self-Employment Income</CardTitle>
                            <CardDescription>Choose how you want to prepare your self-employed tax submission.</CardDescription>
                        </div>
                        <button onClick={() => setSubmissionType(null)} className="flex items-center text-sm text-muted-foreground hover:text-foreground">
                            <ArrowLeft className="mr-2 h-4 w-4" />
                            Back
                        </button>
                    </div>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="hover:border-primary cursor-pointer" onClick={() => setSelfEmployedMethod('detailed')}>
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Briefcase className="h-8 w-8 text-primary" />
                            <CardTitle>File Detailed Return</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground">Manually enter all income, expenses, and allowances in a comprehensive form.</p>
                        </CardContent>
                    </Card>
                    <Card className="hover:border-primary cursor-pointer" onClick={() => setSelfEmployedMethod('transactions')}>
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Banknote className="h-8 w-8 text-primary" />
                            <CardTitle>Submit Using MTD Simple Data</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground">Summarize and submit based on categorized bank feed transactions.</p>
                        </CardContent>
                    </Card>
                </CardContent>
            </Card>
        );
    }
    
    if (submissionType === 'landlord') {
        return <LandlordReturnForm onBack={handleBack} />;
    }

    return (
        <Card>
            <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                        <CardTitle>MTD Income Tax (ITSA)</CardTitle>
                        <CardDescription>What type of income would you like to file for?</CardDescription>
                    </div>
                     {activeClient && (
                        <Button asChild variant="outline">
                            <Link href={`/dashboard/client/${activeClient.id}`}>
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to Client View
                            </Link>
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="hover:border-primary cursor-pointer" onClick={() => setSubmissionType('self-employed')}>
                    <CardHeader className="flex flex-row items-center gap-4">
                        <Briefcase className="h-8 w-8 text-primary" />
                        <CardTitle>File Self Employed</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground">For sole traders and partners to report income from business activities.</p>
                    </CardContent>
                </Card>
                <Card className="hover:border-primary cursor-pointer" onClick={() => setSubmissionType('landlord')}>
                    <CardHeader className="flex flex-row items-center gap-4">
                        <Home className="h-8 w-8 text-primary" />
                        <CardTitle>File as Landlord</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground">For individuals to report income earned from property rentals.</p>
                    </CardContent>
                </Card>
            </CardContent>
        </Card>
    );
}
