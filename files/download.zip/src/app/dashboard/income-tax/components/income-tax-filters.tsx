
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarIcon, X, ArrowRight, Filter } from 'lucide-react';
import { format } from 'date-fns';
import type { DateRange } from 'react-day-picker';
import { cn } from '@/lib/utils';
import type { IncomeSource, NominalCode } from '@/lib/types';
import {
    Collapsible,
    CollapsibleContent,
    CollapsibleTrigger,
} from "@/components/ui/collapsible"

export interface Filters {
    date: DateRange | undefined;
    description: string;
    nominalCode: string;
    incomeSource: string;
}

interface IncomeTaxFiltersProps {
  filters: Filters;
  setFilters: React.Dispatch<React.SetStateAction<Filters>>;
  incomeSources: IncomeSource[];
  nominalCodes: NominalCode[];
}

export function IncomeTaxFilters({ 
    filters, 
    setFilters, 
    incomeSources, 
    nominalCodes, 
}: IncomeTaxFiltersProps) {
  
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);

  const handleInputChange = (field: keyof Filters, value: string | DateRange | undefined) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const clearFilters = () => {
    setFilters({
      date: undefined,
      description: '',
      nominalCode: 'all',
      incomeSource: 'all',
    });
  };

  return (
    <Collapsible className="border-b">
        <div className="p-4 flex justify-end">
            <CollapsibleTrigger asChild>
                <Button variant="outline">
                    <Filter className="mr-2 h-4 w-4" />
                    Filter Transactions
                </Button>
            </CollapsibleTrigger>
        </div>
        <CollapsibleContent>
            <div className="flex flex-col sm:flex-row gap-2 items-center p-4 pt-0">
                <div className="flex-1 w-full sm:w-auto">
                    <Popover open={isDatePopoverOpen} onOpenChange={setIsDatePopoverOpen}>
                        <PopoverTrigger asChild>
                        <Button
                            id="date"
                            variant={"outline"}
                            className={cn(
                            "w-full sm:w-[300px] justify-start text-left font-normal",
                            !filters.date && "text-muted-foreground"
                            )}
                        >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {filters.date?.from ? (
                            filters.date.to ? (
                                <>
                                {format(filters.date.from, "LLL dd, y")} -{" "}
                                {format(filters.date.to, "LLL dd, y")}
                                </>
                            ) : (
                                format(filters.date.from, "LLL dd, y")
                            )
                            ) : (
                            <span>Pick a date range</span>
                            )}
                        </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                            initialFocus
                            mode="range"
                            defaultMonth={filters.date?.from}
                            selected={filters.date}
                            onSelect={(date) => handleInputChange('date', date)}
                            numberOfMonths={2}
                        />
                        <div className="p-2 border-t flex justify-end">
                            <Button onClick={() => setIsDatePopoverOpen(false)}>
                                Next <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                        </PopoverContent>
                    </Popover>
                </div>
                <div className="flex-1 w-full sm:w-auto">
                    <Input 
                        placeholder="Filter by description..."
                        value={filters.description}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                    />
                </div>
                <div className="flex-1 w-full sm:w-auto">
                    <Select value={filters.nominalCode} onValueChange={(v) => handleInputChange('nominalCode', v)}>
                        <SelectTrigger className="w-full sm:w-[180px]">
                            <SelectValue placeholder="Select Nominal Code" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Nominal Codes</SelectItem>
                            {nominalCodes.map(c => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div className="flex-1 w-full sm:w-auto">
                    <Select value={filters.incomeSource} onValueChange={(v) => handleInputChange('incomeSource', v)}>
                        <SelectTrigger className="w-full sm:w-[180px]">
                            <SelectValue placeholder="Select Income Source" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Income Sources</SelectItem>
                            {incomeSources.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <Button variant="ghost" onClick={clearFilters} className="flex-shrink-0">
                    <X className="mr-2" />
                    Reset
                </Button>
            </div>
        </CollapsibleContent>
    </Collapsible>
  );
}
