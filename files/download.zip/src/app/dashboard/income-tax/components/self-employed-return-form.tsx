

"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Send, Loader2, Save, Eye, Info } from 'lucide-react';
import type { SelfEmployedTaxReturn, SelfEmployedSubmissionHistory } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { DatePicker } from './date-picker';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Switch } from '@/components/ui/switch';

const initialFormState: SelfEmployedTaxReturn = {
    id: `se-${Date.now()}`,
    status: 'Draft',
    taxpayerName: '',
    utr: '',
    niNumber: '',
    businessName: '',
    accountingPeriodStartDate: '',
    accountingPeriodEndDate: '',
    grossTurnover: '',
    otherBusinessIncome: '',
    costOfGoods: '',
    wagesAndStaffCosts: '',
    rentRatesPowerInsurance: '',
    repairsAndMaintenance: '',
    phoneInternetOfficeCosts: '',
    travelAndSubsistence: '',
    professionalFees: '',
    advertisingAndMarketing: '',
    otherAllowableExpenses: '',
    consolidatedExpenses: '',
    disallowableExpenses: '',
    capitalAllowances: '',
    privateUseAdjustments: '',
    balancingCharges: '',
    lossBroughtForward: '',
    employmentIncome: '',
    propertyIncome: '',
    dividends: '',
    interest: '',
    personalAllowance: 12570, // Default for current tax year
    tradingAllowance: 0,
    otherReliefs: '',
    paymentsOnAccount: '',
    totalBusinessIncome: 0,
    totalExpenses: 0,
    netProfitBeforeTax: 0,
    adjustedTaxableProfit: 0,
    incomeTaxDue: 0,
    class2Nics: 0,
    class4Nics: 0,
};

const tooltipContent: { [key in keyof Omit<SelfEmployedTaxReturn, 'id' | 'status' | 'totalBusinessIncome' | 'totalExpenses' | 'netProfitBeforeTax' | 'adjustedTaxableProfit' | 'incomeTaxDue' | 'class2Nics' | 'class4Nics' | 'consolidatedExpenses'>]: string } = {
    taxpayerName: "Full name of the individual taxpayer.",
    utr: "Your 10-digit Unique Taxpayer Reference number provided by HMRC.",
    niNumber: "Your National Insurance Number.",
    businessName: "The name under which you trade or do business.",
    accountingPeriodStartDate: "The start date of the financial period for this return.",
    accountingPeriodEndDate: "The end date of the financial period for this return.",
    grossTurnover: "Total income from sales and services before any expenses are deducted.",
    otherBusinessIncome: "Any other income related to your business not included in turnover.",
    costOfGoods: "The cost of raw materials and direct labor to produce goods for sale.",
    wagesAndStaffCosts: "Salaries, NICs, and pension contributions for your employees.",
    rentRatesPowerInsurance: "Costs for business premises, business rates, utilities, and insurance.",
    repairsAndMaintenance: "Costs for repairing and maintaining business equipment and premises.",
    phoneInternetOfficeCosts: "Expenses for office stationery, phone bills, and internet services.",
    travelAndSubsistence: "Costs for business travel, including transport, accommodation, and meals.",
    professionalFees: "Fees for services from accountants, lawyers, or other professionals.",
    advertisingAndMarketing: "Costs for promoting your business.",
    otherAllowableExpenses: "Any other expenses incurred wholly and exclusively for your business.",
    disallowableExpenses: "Expenses that cannot be claimed for tax purposes, such as personal use.",
    capitalAllowances: "Claim for the value of assets you own and use in your business (e.g., equipment, vehicles).",
    privateUseAdjustments: "A reduction in expenses to account for personal use of business assets.",
    balancingCharges: "An adjustment made when you sell a business asset for more than its tax written-down value.",
    lossBroughtForward: "Business losses from previous years that can be offset against this year's profit.",
    employmentIncome: "Income from any employment outside of your self-employment.",
    propertyIncome: "Income received from renting out property.",
    dividends: "Income received as dividends from shares.",
    interest: "Interest received from bank accounts or other investments.",
    personalAllowance: "The amount of income you can earn before you start paying tax.",
    tradingAllowance: "A tax exemption of up to £1,000 a year for small or casual self-employment income.",
    otherReliefs: "Any other tax reliefs you are eligible for.",
    paymentsOnAccount: "Advance payments towards your tax bill if your previous bill was over £1,000.",
};

const InfoLabel = ({ field, children }: { field: keyof typeof tooltipContent, children: React.ReactNode }) => (
    <Tooltip>
        <TooltipTrigger asChild>
            <div className="flex items-center gap-2 cursor-help">
                <Label>{children}</Label>
                <Info className="h-4 w-4 text-muted-foreground" />
            </div>
        </TooltipTrigger>
        <TooltipContent>
            <p className="max-w-xs">{tooltipContent[field]}</p>
        </TooltipContent>
    </Tooltip>
);

function Section({ title, children, headerContent }: { title: string, children: React.ReactNode, headerContent?: React.ReactNode }) {
    return (
        <Card>
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle className="text-xl">{title}</CardTitle>
                    {headerContent}
                </div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4">
                {children}
            </CardContent>
        </Card>
    )
}

function FormField({ label, children, className, fieldName }: { label: string, children: React.ReactNode, className?: string, fieldName?: keyof typeof tooltipContent }) {
    return (
        <div className={`space-y-2 ${className}`}>
            {fieldName ? <InfoLabel field={fieldName}>{label}</InfoLabel> : <Label>{label}</Label>}
            {children}
        </div>
    )
}

function CalculatedField({ label, value, className }: { label: string, value: number | '', className?: string }) {
     return (
        <div className={`space-y-2 p-3 bg-muted rounded-md ${className}`}>
            <Label>{label}</Label>
            <div className="font-bold text-lg">£{Number(value).toFixed(2)}</div>
        </div>
    )
}

function SummaryDetailRow({ label, value, isCurrency = true }: { label: string, value: string | number, isCurrency?: boolean }) {
    return (
        <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">{label}</span>
            <span className={isCurrency ? "font-mono" : "font-medium"}>
                {isCurrency ? `£${Number(value).toFixed(2)}` : value}
            </span>
        </div>
    )
}

export function SelfEmployedReturnForm({ onBack }: { onBack: () => void }) {
    const { toast } = useToast();
    const [formState, setFormState] = useState<SelfEmployedTaxReturn>(initialFormState);
    const [isConsolidatedExpenses, setIsConsolidatedExpenses] = useState(false);
    const [isConfirming, setIsConfirming] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDeclared, setIsDeclared] = useState(false);
    const [submissionHistory, setSubmissionHistory] = useState<SelfEmployedSubmissionHistory[]>([]);
    const [viewingHistory, setViewingHistory] = useState<SelfEmployedSubmissionHistory | null>(null);

    useEffect(() => {
        const storedDraft = localStorage.getItem('selfEmployedDraft');
        if (storedDraft) {
            setFormState(JSON.parse(storedDraft));
        }

        const storedHistory = localStorage.getItem('selfEmployedSubmissionHistory');
        if (storedHistory) {
            setSubmissionHistory(JSON.parse(storedHistory));
        }
    }, []);

    const calculateTotals = useCallback((state: SelfEmployedTaxReturn, consolidated: boolean) => {
        const getNum = (val: number | string) => typeof val === 'string' ? (parseFloat(val) || 0) : (val || 0);

        const totalBusinessIncome = getNum(state.grossTurnover) + getNum(state.otherBusinessIncome);

        let totalExpenses: number;

        if (consolidated) {
            totalExpenses = getNum(state.consolidatedExpenses);
        } else {
            totalExpenses = [
                getNum(state.costOfGoods),
                getNum(state.wagesAndStaffCosts),
                getNum(state.rentRatesPowerInsurance),
                getNum(state.repairsAndMaintenance),
                getNum(state.phoneInternetOfficeCosts),
                getNum(state.travelAndSubsistence),
                getNum(state.professionalFees),
                getNum(state.advertisingAndMarketing),
                getNum(state.otherAllowableExpenses)
            ].reduce((acc, val) => acc + val, 0);
        }


        const netProfitBeforeTax = totalBusinessIncome - totalExpenses;
        
        const adjustedTaxableProfit = netProfitBeforeTax
            + getNum(state.disallowableExpenses)
            - getNum(state.capitalAllowances)
            - getNum(state.privateUseAdjustments)
            + getNum(state.balancingCharges)
            - getNum(state.lossBroughtForward)
            - getNum(state.tradingAllowance);

        const otherIncome = [
            getNum(state.employmentIncome),
            getNum(state.propertyIncome),
            getNum(state.dividends),
            getNum(state.interest),
        ].reduce((a,b) => a+b, 0);

        const totalTaxable = adjustedTaxableProfit + otherIncome - getNum(state.personalAllowance) - getNum(state.otherReliefs);
        
        let incomeTaxDue = 0;
        if (totalTaxable > 0) {
            if (totalTaxable <= 37700) {
                incomeTaxDue = totalTaxable * 0.20;
            } else if (totalTaxable <= 125140) {
                incomeTaxDue = (37700 * 0.20) + ((totalTaxable - 37700) * 0.40);
            } else {
                incomeTaxDue = (37700 * 0.20) + ((125140 - 37700) * 0.40) + ((totalTaxable - 125140) * 0.45);
            }
        }
        
        // Simplified NICs calculation
        const class2Nics = netProfitBeforeTax > 6725 ? 3.45 * 52 : 0;
        let class4Nics = 0;
        if (netProfitBeforeTax > 12570) {
            if (netProfitBeforeTax <= 50270) {
                class4Nics = (netProfitBeforeTax - 12570) * 0.09;
            } else {
                class4Nics = ((50270 - 12570) * 0.09) + ((netProfitBeforeTax - 50270) * 0.02);
            }
        }

        return { 
            ...state,
            totalBusinessIncome,
            totalExpenses,
            netProfitBeforeTax,
            adjustedTaxableProfit,
            incomeTaxDue,
            class2Nics,
            class4Nics
        };

    }, []);

    const handleUpdate = (field: keyof SelfEmployedTaxReturn, value: string) => {
         setFormState(prevState => {
            const newState = { ...prevState, [field]: value };
            return calculateTotals(newState, isConsolidatedExpenses);
        });
    };
    
    useEffect(() => {
        setFormState(prevState => calculateTotals(prevState, isConsolidatedExpenses));
    }, [isConsolidatedExpenses, calculateTotals]);


    const handleSaveDraft = () => {
        localStorage.setItem('selfEmployedDraft', JSON.stringify(formState));
        toast({
            title: "Draft Saved",
            description: "Your self-employed tax return draft has been saved.",
        });
    };
    
     const handleSubmissionClick = () => {
        setIsConfirming(true);
    };

    const handleHMRCSubmit = () => {
        if (!formState) return;
        setIsSubmitting(true);
        
        setTimeout(() => {
            const submittedState = {...formState, status: 'Submitted' as const };
            
            const newHistoryItem: SelfEmployedSubmissionHistory = {
                id: Date.now().toString(),
                submissionDate: new Date().toISOString(),
                businessName: submittedState.businessName,
                taxableProfit: Number(submittedState.adjustedTaxableProfit),
                taxDue: Number(submittedState.incomeTaxDue) + Number(submittedState.class2Nics) + Number(submittedState.class4Nics),
                hmrcReference: `HMRC-ITSA-SE-${Date.now()}`,
                submittedReturn: submittedState,
            };
            const updatedHistory = [newHistoryItem, ...submissionHistory];
            setSubmissionHistory(updatedHistory);
            localStorage.setItem('selfEmployedSubmissionHistory', JSON.stringify(updatedHistory));
            
            toast({
                title: "Submitting to HMRC...",
                description: `Submitting return for ${formState.businessName}. This is a placeholder for the actual HMRC submission.`,
            });

            // Reset form and clear draft
            localStorage.removeItem('selfEmployedDraft');
            setFormState(initialFormState);

            setIsSubmitting(false);
            setIsConfirming(false);
        }, 2000);
    }
    
    return (
        <TooltipProvider>
            <Card>
                <CardHeader className="flex flex-row justify-between items-start">
                    <div>
                        <CardTitle>MTD Income Tax (ITSA): Self-Employed Return</CardTitle>
                        <CardDescription>Enter the details for your self-employed income tax return.</CardDescription>
                    </div>
                     <Button variant="outline" onClick={onBack}><ArrowLeft className="mr-2 h-4 w-4" />Back to Selection</Button>
                </CardHeader>
                <CardContent className="space-y-6">
                    <Section title="Taxpayer Details">
                        <FormField fieldName="taxpayerName" label="Taxpayer Name"><Input value={formState.taxpayerName} onChange={e => handleUpdate('taxpayerName', e.target.value)} /></FormField>
                        <FormField fieldName="utr" label="Unique Taxpayer Reference (UTR)"><Input value={formState.utr} onChange={e => handleUpdate('utr', e.target.value)} /></FormField>
                        <FormField fieldName="niNumber" label="National Insurance Number (NINO)"><Input value={formState.niNumber} onChange={e => handleUpdate('niNumber', e.target.value)} /></FormField>
                        <FormField fieldName="businessName" label="Business Name / Trade Description"><Input value={formState.businessName} onChange={e => handleUpdate('businessName', e.target.value)} /></FormField>
                        <FormField fieldName="accountingPeriodStartDate" label="Accounting Period Start Date"><DatePicker date={formState.accountingPeriodStartDate ? new Date(formState.accountingPeriodStartDate) : undefined} setDate={(date) => handleUpdate('accountingPeriodStartDate', date ? format(date, 'yyyy-MM-dd') : '')} /></FormField>
                        <FormField fieldName="accountingPeriodEndDate" label="Accounting Period End Date"><DatePicker date={formState.accountingPeriodEndDate ? new Date(formState.accountingPeriodEndDate) : undefined} setDate={(date) => handleUpdate('accountingPeriodEndDate', date ? format(date, 'yyyy-MM-dd') : '')} /></FormField>
                    </Section>

                    <Section title="Income (Self-Employment / Business)">
                        <FormField fieldName="grossTurnover" label="Gross Turnover (Sales/Income)"><Input type="number" value={formState.grossTurnover} onChange={e => handleUpdate('grossTurnover', e.target.value)} /></FormField>
                        <FormField fieldName="otherBusinessIncome" label="Other Business Income"><Input type="number" value={formState.otherBusinessIncome} onChange={e => handleUpdate('otherBusinessIncome', e.target.value)} /></FormField>
                        <CalculatedField label="Total Business Income" value={formState.totalBusinessIncome} />
                    </Section>

                    <Section 
                        title="Allowable Expenses"
                        headerContent={
                            <div className="flex items-center space-x-2">
                                <Label htmlFor="consolidate-expenses">Show Consolidated Figures</Label>
                                <Switch id="consolidate-expenses" checked={isConsolidatedExpenses} onCheckedChange={setIsConsolidatedExpenses} />
                            </div>
                        }
                    >
                        {isConsolidatedExpenses ? (
                            <>
                                <FormField label="Total Allowable Expenses" className="lg:col-span-2">
                                    <Input type="number" value={formState.consolidatedExpenses} onChange={e => handleUpdate('consolidatedExpenses', e.target.value)} />
                                </FormField>
                                <div className="lg:col-span-2 flex items-center">
                                    <p className="text-sm text-muted-foreground">Enter the single, consolidated figure for all your allowable business expenses for the period.</p>
                                </div>
                            </>
                        ) : (
                            <>
                                <FormField fieldName="costOfGoods" label="Cost of Goods Bought for Resale"><Input type="number" value={formState.costOfGoods} onChange={e => handleUpdate('costOfGoods', e.target.value)} /></FormField>
                                <FormField fieldName="wagesAndStaffCosts" label="Wages and Staff Costs"><Input type="number" value={formState.wagesAndStaffCosts} onChange={e => handleUpdate('wagesAndStaffCosts', e.target.value)} /></FormField>
                                <FormField fieldName="rentRatesPowerInsurance" label="Rent, Rates, Power, Insurance"><Input type="number" value={formState.rentRatesPowerInsurance} onChange={e => handleUpdate('rentRatesPowerInsurance', e.target.value)} /></FormField>
                                <FormField fieldName="repairsAndMaintenance" label="Repairs and Maintenance"><Input type="number" value={formState.repairsAndMaintenance} onChange={e => handleUpdate('repairsAndMaintenance', e.target.value)} /></FormField>
                                <FormField fieldName="phoneInternetOfficeCosts" label="Phone, Internet, Office Costs"><Input type="number" value={formState.phoneInternetOfficeCosts} onChange={e => handleUpdate('phoneInternetOfficeCosts', e.target.value)} /></FormField>
                                <FormField fieldName="travelAndSubsistence" label="Travel and Subsistence"><Input type="number" value={formState.travelAndSubsistence} onChange={e => handleUpdate('travelAndSubsistence', e.target.value)} /></FormField>
                                <FormField fieldName="professionalFees" label="Professional Fees"><Input type="number" value={formState.professionalFees} onChange={e => handleUpdate('professionalFees', e.target.value)} /></FormField>
                                <FormField fieldName="advertisingAndMarketing" label="Advertising & Marketing"><Input type="number" value={formState.advertisingAndMarketing} onChange={e => handleUpdate('advertisingAndMarketing', e.target.value)} /></FormField>
                                <FormField fieldName="otherAllowableExpenses" label="Other Allowable Expenses"><Input type="number" value={formState.otherAllowableExpenses} onChange={e => handleUpdate('otherAllowableExpenses', e.target.value)} /></FormField>
                            </>
                        )}
                         <CalculatedField label="Total Expenses" value={formState.totalExpenses} className="lg:col-start-4" />
                    </Section>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <Section title="Adjustments">
                            <FormField fieldName="disallowableExpenses" label="Disallowable Expenses"><Input type="number" value={formState.disallowableExpenses} onChange={e => handleUpdate('disallowableExpenses', e.target.value)} /></FormField>
                            <FormField fieldName="capitalAllowances" label="Capital Allowances"><Input type="number" value={formState.capitalAllowances} onChange={e => handleUpdate('capitalAllowances', e.target.value)} /></FormField>
                            <FormField fieldName="privateUseAdjustments" label="Private Use Adjustments"><Input type="number" value={formState.privateUseAdjustments} onChange={e => handleUpdate('privateUseAdjustments', e.target.value)} /></FormField>
                            <FormField fieldName="balancingCharges" label="Balancing Charges"><Input type="number" value={formState.balancingCharges} onChange={e => handleUpdate('balancingCharges', e.target.value)} /></FormField>
                        </Section>
                        <Section title="Tax Reliefs & Allowances">
                            <FormField fieldName="personalAllowance" label="Personal Allowance"><Input type="number" value={formState.personalAllowance} onChange={e => handleUpdate('personalAllowance', e.target.value)} /></FormField>
                            <FormField fieldName="tradingAllowance" label="Trading Allowance"><Input type="number" value={formState.tradingAllowance} onChange={e => handleUpdate('tradingAllowance', e.target.value)} /></FormField>
                            <FormField fieldName="otherReliefs" label="Other Reliefs"><Input type="number" value={formState.otherReliefs} onChange={e => handleUpdate('otherReliefs', e.target.value)} /></FormField>
                            <FormField fieldName="lossBroughtForward" label="Loss Brought Forward"><Input type="number" value={formState.lossBroughtForward} onChange={e => handleUpdate('lossBroughtForward', e.target.value)} /></FormField>
                        </Section>
                    </div>

                    <Section title="Profit Calculations & Tax Due">
                        <CalculatedField label="Net Profit Before Tax" value={formState.netProfitBeforeTax} />
                        <CalculatedField label="Adjusted Taxable Profit" value={formState.adjustedTaxableProfit} />
                        <CalculatedField label="Income Tax Due" value={formState.incomeTaxDue} />
                        <CalculatedField label="Class 2 NICs Due" value={formState.class2Nics} />
                        <CalculatedField label="Class 4 NICs Due" value={formState.class4Nics} />
                         <FormField fieldName="paymentsOnAccount" label="Payments on Account" className="lg:col-span-2"><Input type="number" value={formState.paymentsOnAccount} onChange={e => handleUpdate('paymentsOnAccount', e.target.value)} /></FormField>
                    </Section>
                </CardContent>
                <CardFooter className="flex justify-end gap-2 border-t pt-6">
                    <Button variant="outline" onClick={handleSaveDraft}><Save className="mr-2 h-4 w-4" /> Save Draft</Button>
                    <Button onClick={handleSubmissionClick}><Send className="mr-2 h-4 w-4" /> Approve and Submit to HMRC</Button>
                </CardFooter>
            </Card>

             {submissionHistory.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Past Self-Employed Submissions</CardTitle>
                        <CardDescription>A log of your previously submitted self-employed returns.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Submission Date</TableHead>
                                    <TableHead>Business Name</TableHead>
                                    <TableHead>HMRC Reference</TableHead>
                                    <TableHead className="text-right">Taxable Profit</TableHead>
                                    <TableHead className="text-right">Total Tax Due</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {submissionHistory.map(item => (
                                    <TableRow key={item.id}>
                                        <TableCell>{format(new Date(item.submissionDate), 'dd MMM yyyy, HH:mm')}</TableCell>
                                        <TableCell>{item.businessName}</TableCell>
                                        <TableCell className="font-mono">{item.hmrcReference}</TableCell>
                                        <TableCell className="text-right font-mono">£{item.taxableProfit.toFixed(2)}</TableCell>
                                        <TableCell className="text-right font-mono">£{item.taxDue.toFixed(2)}</TableCell>
                                        <TableCell className="text-right">
                                            <Button variant="ghost" size="sm" onClick={() => setViewingHistory(item)}>
                                                <Eye className="mr-2 h-4 w-4" />
                                                View
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            <Dialog open={isConfirming} onOpenChange={setIsConfirming}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Self-Employed ITSA Submission</DialogTitle>
                        <DialogDescription>
                            You are making a legal declaration that this information is true and complete. A false declaration can result in prosecution.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-2">
                        <div className="flex justify-between p-2"><span className="text-muted-foreground">Adjusted Taxable Profit</span><span className="font-mono font-bold">£{Number(formState.adjustedTaxableProfit).toFixed(2)}</span></div>
                        <Separator />
                        <div className="flex justify-between p-2"><span className="text-muted-foreground">Income Tax Due</span><span className="font-mono font-bold">£{Number(formState.incomeTaxDue).toFixed(2)}</span></div>
                        <div className="flex justify-between p-2"><span className="text-muted-foreground">Class 2 NICs</span><span className="font-mono font-bold">£{Number(formState.class2Nics).toFixed(2)}</span></div>
                        <div className="flex justify-between p-2"><span className="text-muted-foreground">Class 4 NICs</span><span className="font-mono font-bold">£{Number(formState.class4Nics).toFixed(2)}</span></div>
                         <Separator />
                        <div className="flex justify-between p-2 font-bold text-lg"><span >Total Tax Due</span><span className="font-mono">£{(Number(formState.incomeTaxDue) + Number(formState.class2Nics) + Number(formState.class4Nics)).toFixed(2)}</span></div>
                    </div>
                    <div className="flex items-center space-x-2 pt-4">
                        <Checkbox id="declaration-se" checked={isDeclared} onCheckedChange={(checked) => setIsDeclared(checked as boolean)} />
                        <Label htmlFor="declaration-se" className="text-sm">I confirm I have read the legal declaration and have authority to submit this information.</Label>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsConfirming(false)} disabled={isSubmitting}>Cancel</Button>
                        <Button onClick={handleHMRCSubmit} disabled={isSubmitting || !isDeclared}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Confirm & Submit
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

             <Dialog open={!!viewingHistory} onOpenChange={() => setViewingHistory(null)}>
                <DialogContent className="max-w-4xl">
                     <DialogHeader>
                        <DialogTitle>Past Submission Details</DialogTitle>
                        <DialogDescription>
                            Details for submission {viewingHistory?.hmrcReference} for business {viewingHistory?.businessName}.
                        </DialogDescription>
                    </DialogHeader>
                     {viewingHistory && viewingHistory.submittedReturn ? (
                         <div className="py-4 space-y-4 max-h-[70vh] overflow-y-auto pr-4">
                            <div className="grid grid-cols-2 gap-4">
                                <CalculatedField label="Total Taxable Profit" value={viewingHistory.taxableProfit} />
                                <CalculatedField label="Total Tax Due" value={viewingHistory.taxDue} />
                            </div>

                            <Card>
                                <CardHeader><CardTitle className="text-base">Taxpayer & Business</CardTitle></CardHeader>
                                <CardContent className="space-y-1">
                                    <SummaryDetailRow label="Taxpayer" value={viewingHistory.submittedReturn.taxpayerName} isCurrency={false} />
                                    <SummaryDetailRow label="Business Name" value={viewingHistory.submittedReturn.businessName} isCurrency={false} />
                                    <SummaryDetailRow label="UTR" value={viewingHistory.submittedReturn.utr} isCurrency={false} />
                                    <SummaryDetailRow label="NINO" value={viewingHistory.submittedReturn.niNumber} isCurrency={false} />
                                    <SummaryDetailRow label="Accounting Period" value={`${format(new Date(viewingHistory.submittedReturn.accountingPeriodStartDate), 'dd/MM/yy')} - ${format(new Date(viewingHistory.submittedReturn.accountingPeriodEndDate), 'dd/MM/yy')}`} isCurrency={false} />
                                </CardContent>
                            </Card>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                <Card>
                                    <CardHeader><CardTitle className="text-base">Income & Expenses</CardTitle></CardHeader>
                                    <CardContent className="space-y-1">
                                        <SummaryDetailRow label="Gross Turnover" value={viewingHistory.submittedReturn.grossTurnover} />
                                        <SummaryDetailRow label="Other Business Income" value={viewingHistory.submittedReturn.otherBusinessIncome} />
                                        <Separator className="my-2" />
                                        <SummaryDetailRow label="Total Allowable Expenses" value={viewingHistory.submittedReturn.totalExpenses} />
                                        <Separator className="my-2" />
                                        <SummaryDetailRow label="Net Profit Before Tax" value={viewingHistory.submittedReturn.netProfitBeforeTax} />
                                    </CardContent>
                                </Card>
                                <Card>
                                    <CardHeader><CardTitle className="text-base">Tax Calculation</CardTitle></CardHeader>
                                    <CardContent className="space-y-1">
                                        <SummaryDetailRow label="Adjusted Taxable Profit" value={viewingHistory.submittedReturn.adjustedTaxableProfit} />
                                        <SummaryDetailRow label="Income Tax Due" value={viewingHistory.submittedReturn.incomeTaxDue} />
                                        <SummaryDetailRow label="Class 2 NICs" value={viewingHistory.submittedReturn.class2Nics} />
                                        <SummaryDetailRow label="Class 4 NICs" value={viewingHistory.submittedReturn.class4Nics} />
                                        <Separator className="my-2" />
                                        <div className="flex justify-between font-bold"><span className="text-foreground">Total Tax Due</span><span className="font-mono">£{viewingHistory.taxDue.toFixed(2)}</span></div>
                                    </CardContent>
                                </Card>
                            </div>
                         </div>
                    ) : <p>Full summary of past Self-Employed returns will be displayed here.</p>}
                </DialogContent>
             </Dialog>
        </TooltipProvider>
    );
}

    