

"use client";

import { useState, useEffect, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Banknote, FileText, Download, Send, ArrowLeft, Landmark, Pencil, PlusCircle, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { bankTransactions as initialBankTransactions, incomeSources as initialIncomeSources, nominalCodes as initialNominalCodes } from '@/lib/data';
import type { BankTransaction, IncomeSource, NominalCode } from '@/lib/types';
import { IncomeTaxFilters, type Filters } from './income-tax-filters';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';


function EditableTransactionRow({ 
    transaction, 
    onUpdate, 
    onDelete, 
    nominalCodes, 
    incomeSources 
}: { 
    transaction: BankTransaction, 
    onUpdate: (id: string, field: keyof BankTransaction, value: any) => void,
    onDelete: (id: string) => void,
    nominalCodes: NominalCode[],
    incomeSources: IncomeSource[]
}) {
    return (
        <TableRow className="bg-muted/50">
            <TableCell className="border-r">
                <Input
                    type="date"
                    value={transaction.date}
                    onChange={(e) => onUpdate(transaction.id, 'date', e.target.value)}
                />
            </TableCell>
            <TableCell className="border-r">
                <Input
                    placeholder="Enter description..."
                    value={transaction.description}
                    onChange={(e) => onUpdate(transaction.id, 'description', e.target.value)}
                />
            </TableCell>
            <TableCell className="border-r">
                <Select value={transaction.nominalCode} onValueChange={(v) => onUpdate(transaction.id, 'nominalCode', v)}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                        {nominalCodes.map(c => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </TableCell>
            <TableCell className="border-r">
                <Select value={transaction.incomeSource} onValueChange={(v) => onUpdate(transaction.id, 'incomeSource', v)}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                        {incomeSources.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </TableCell>
            <TableCell className="border-r">
                <div className="flex items-center gap-2">
                    <Pencil className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Manual Entry / Invoice</span>
                </div>
            </TableCell>
            <TableCell className="border-r">
                 <Input 
                    type="number" 
                    value={transaction.credit ?? ''} 
                    onChange={(e) => onUpdate(transaction.id, 'credit', e.target.value ? parseFloat(e.target.value) : null)} 
                    placeholder="0.00"
                    className="text-right"
                />
            </TableCell>
            <TableCell className="border-r">
                <Input 
                    type="number" 
                    value={transaction.debit ?? ''} 
                    onChange={(e) => onUpdate(transaction.id, 'debit', e.target.value ? parseFloat(e.target.value) : null)} 
                    placeholder="0.00"
                    className="text-right"
                />
            </TableCell>
            <TableCell>
                <Button variant="ghost" size="icon" onClick={() => onDelete(transaction.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
            </TableCell>
        </TableRow>
    );
}

export function IncomeTaxSubmission({ onBack }: { onBack: () => void }) {
    const [transactions, setTransactions] = useState<BankTransaction[]>([]);
    const [incomeSources, setIncomeSources] = useState<IncomeSource[]>([]);
    const [nominalCodes, setNominalCodes] = useState<NominalCode[]>([]);

    const [filters, setFilters] = useState<Filters>({
        date: undefined,
        description: '',
        nominalCode: 'all',
        incomeSource: 'all',
    });

    useEffect(() => {
        const allTransactions: BankTransaction[] = JSON.parse(localStorage.getItem('bankTransactions') || '[]');
        const selfEmployedTransactions = allTransactions.filter(t => t.includeInMtd && t.incomeSource === 'Self employment');
        setTransactions(selfEmployedTransactions);
        
        const storedIncomeSources: IncomeSource[] = JSON.parse(localStorage.getItem('incomeSources') || '[]');
        setIncomeSources(storedIncomeSources.length > 0 ? storedIncomeSources : initialIncomeSources);

        const storedNominalCodes: NominalCode[] = JSON.parse(localStorage.getItem('nominalCodes') || '[]');
        setNominalCodes(storedNominalCodes.length > 0 ? storedNominalCodes : initialNominalCodes);

    }, []);

    const filteredTransactions = useMemo(() => {
        return transactions.filter(t => {
            const date = new Date(t.date);
            if (filters.date?.from && date < filters.date.from) return false;
            if (filters.date?.to && date > filters.date.to) return false;
            if (filters.description && !t.description.toLowerCase().includes(filters.description.toLowerCase())) return false;
            if (filters.nominalCode !== 'all' && t.nominalCode !== filters.nominalCode) return false;
            if (filters.incomeSource !== 'all' && t.incomeSource !== filters.incomeSource) return false;
            return true;
        });
    }, [transactions, filters]);

    const summary = useMemo(() => {
        const totalIncome = filteredTransactions.reduce((acc, t) => acc + (t.credit || 0), 0);
        const totalExpenses = filteredTransactions.reduce((acc, t) => acc + (t.debit || 0), 0);
        const totalTransactions = filteredTransactions.length;
        return { totalIncome, totalExpenses, totalTransactions };
    }, [filteredTransactions]);

    const handleAddTransaction = () => {
        const newTransaction: BankTransaction = {
            id: `manual-${Date.now()}`,
            bankId: '',
            date: format(new Date(), 'yyyy-MM-dd'),
            description: '',
            debit: null,
            credit: null,
            balance: 0,
            additionalDescription: 'Manual Entry',
            nominalCode: '',
            incomeSource: 'Self employment',
            includeInMtd: true,
            isApproved: true,
        };
        setTransactions([newTransaction, ...transactions]);
    };

    const handleUpdateTransaction = (id: string, field: keyof BankTransaction, value: any) => {
        setTransactions(prev => prev.map(t => t.id === id ? { ...t, [field]: value } : t));
    };

    const handleDeleteTransaction = (id: string) => {
        setTransactions(prev => prev.filter(t => t.id !== id));
    };


    return (
         <div className="space-y-6">
             <div className="flex justify-between items-center">
                 <h1 className="text-2xl font-bold">MTD Income Tax (Self-Employed)</h1>
                <Button variant="outline" onClick={onBack}>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Selection
                </Button>
            </div>
            
            <div className="grid gap-4 md:grid-cols-3">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Income</CardTitle>
                        <Banknote className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">£{summary.totalIncome.toFixed(2)}</div>
                        <p className="text-xs text-muted-foreground">from {filteredTransactions.filter(t => t.credit).length} transactions</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                        <Banknote className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">£{summary.totalExpenses.toFixed(2)}</div>
                        <p className="text-xs text-muted-foreground">from {filteredTransactions.filter(t => t.debit).length} transactions</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
                        <FileText className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{summary.totalTransactions}</div>
                        <p className="text-xs text-muted-foreground">included in this period</p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>Income & Expense Transactions</CardTitle>
                            <CardDescription>Review the transactions to be included in your MTD submission.</CardDescription>
                        </div>
                        <Button onClick={handleAddTransaction}>
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Add Transaction
                        </Button>
                    </div>
                </CardHeader>
                 <IncomeTaxFilters
                    filters={filters}
                    setFilters={setFilters}
                    incomeSources={incomeSources}
                    nominalCodes={nominalCodes}
                />
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="border-r">Date</TableHead>
                                <TableHead className="border-r">Description</TableHead>
                                <TableHead className="border-r">Nominal Code</TableHead>
                                <TableHead className="border-r">Income Source</TableHead>
                                <TableHead className="border-r">Source</TableHead>
                                <TableHead className="text-right border-r">Income</TableHead>
                                <TableHead className="text-right border-r">Expense</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredTransactions.map(t => (
                                t.id.startsWith('manual-') ? (
                                    <EditableTransactionRow 
                                        key={t.id}
                                        transaction={t}
                                        onUpdate={handleUpdateTransaction}
                                        onDelete={handleDeleteTransaction}
                                        nominalCodes={nominalCodes}
                                        incomeSources={incomeSources}
                                    />
                                ) : (
                                    <TableRow key={t.id}>
                                        <TableCell className="border-r">{format(new Date(t.date), 'dd MMM yyyy')}</TableCell>
                                        <TableCell className="border-r">{t.description}</TableCell>
                                        <TableCell className="border-r"><Badge variant="outline">{t.nominalCode}</Badge></TableCell>
                                        <TableCell className="border-r"><Badge variant="outline" className={cn(t.incomeSource === "Self employment" ? "border-blue-500/40 bg-blue-500/20 text-blue-700" : "")}>{t.incomeSource}</Badge></TableCell>
                                        <TableCell className="border-r">
                                            <div className="flex items-center gap-2">
                                                {t.bankId ? <Landmark className="h-5 w-5 text-muted-foreground" /> : <Pencil className="h-5 w-5 text-muted-foreground" />}
                                                <span className="text-sm text-muted-foreground">{t.bankId ? 'From Bank Feed' : 'Manual Entry / Invoice'}</span>
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right font-mono border-r">{t.credit ? `£${t.credit.toFixed(2)}` : '-'}</TableCell>
                                        <TableCell className="text-right font-mono border-r">{t.debit ? `£${t.debit.toFixed(2)}` : '-'}</TableCell>
                                        <TableCell></TableCell>
                                    </TableRow>
                                )
                            ))}
                        </TableBody>
                    </Table>
                     {filteredTransactions.length === 0 && (
                        <div className="text-center p-8 text-muted-foreground">
                            No transactions found for the selected filters.
                        </div>
                    )}
                </CardContent>
                <CardFooter className="border-t p-4 flex gap-2">
                     <Button variant="outline"><Download className="mr-2 h-4 w-4" /> Download as CSV</Button>
                     <Button variant="outline"><Send className="mr-2 h-4 w-4" /> Email Report</Button>
                     <Button><Send className="mr-2 h-4 w-4" /> Submit to HMRC</Button>
                </CardFooter>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Submission History</CardTitle>
                     <CardDescription>A log of your past MTD Income Tax submissions for self-employment.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <div className="flex h-48 items-center justify-center rounded-lg border-2 border-dashed">
                        <p className="text-muted-foreground">
                            Submission history will be displayed here.
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
