

"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, PlusCircle, Trash2, Info, Send, Loader2, ChevronsUpDown, Eye, Save } from 'lucide-react';
import type { LandlordTaxReturn, LandlordSubmissionHistory } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const initialRow: Omit<LandlordTaxReturn, 'id'> = {
  taxYear: '2024/25',
  taxpayerName: 'John Smith',
  utr: '123456789',
  niNumber: 'AB123456C',
  address: '',
  propertyType: 'Residential',
  rentalIncome: '',
  reversePremiums: '',
  propertyRepairs: '',
  maintenance: '',
  utilities: '',
  insurance: '',
  managementFees: '',
  loanInterest: '',
  allowableExpenses: '',
  capitalAllowance: '',
  privateUseAdjustment: '',
  totalExpenses: '',
  netProfitOrLoss: '',
  adjustment: '',
  taxableProfit: '',
  taxDue: '',
  paymentDeadline: '31 January',
  status: 'Draft',
};

const tooltipContent: Record<keyof Omit<LandlordTaxReturn, 'id' | 'totalExpenses' | 'netProfitOrLoss' | 'taxableProfit' | 'status'>, string> = {
    taxYear: "The tax year to which this return applies (e.g., 2024/25).",
    taxpayerName: "The full name of the property owner or landlord.",
    utr: "Your 10-digit Unique Taxpayer Reference (UTR) number.",
    niNumber: "Your National Insurance number.",
    address: "The full address of the rental property.",
    propertyType: "The type of property being let (e.g., Residential, Commercial).",
    rentalIncome: "Total rent and any other payments received from tenants.",
    reversePremiums: "A 'Reverse Premium' is when a landlord pays a tenant as an incentive to take on a lease. HMRC treats this as income for the landlord, so it must be declared.",
    propertyRepairs: "Costs for repairs and maintenance of the property structure and fixtures.",
    maintenance: "General upkeep costs, like cleaning and gardening.",
    utilities: "Costs for services like electricity, gas, and water paid by the landlord.",
    insurance: "Premiums for building and contents insurance.",
    managementFees: "Fees paid to a letting agent or property manager.",
    loanInterest: "Interest paid on loans used to purchase or improve the property.",
    allowableExpenses: "Other miscellaneous expenses that are wholly and exclusively for the purpose of the rental business.",
    capitalAllowance: "Claim for the wear and tear of items you own and use in your property, like furniture or appliances.",
    privateUseAdjustment: "A reduction in expenses to account for any personal, non-business use of the property or items.",
    adjustment: "Any other adjustments to your profit, such as reliefs or losses brought forward.",
    taxDue: "The amount of tax calculated as due on your taxable profit. This may be an estimate.",
    paymentDeadline: "The official deadline by which the tax due must be paid to HMRC.",
};

const InfoLabel = ({ field, children }: { field: keyof typeof tooltipContent, children: React.ReactNode }) => (
    <TooltipProvider>
        <Tooltip>
            <TooltipTrigger asChild>
                <div className="flex items-center gap-2">
                    <Label htmlFor={`${field}`}>{children}</Label>
                    <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                </div>
            </TooltipTrigger>
            <TooltipContent>
                <p>{tooltipContent[field]}</p>
            </TooltipContent>
        </Tooltip>
    </TooltipProvider>
)


function PropertyCard({ property, onUpdate, onDelete, onSubmission, index, onSave }: { property: LandlordTaxReturn, onUpdate: (id: string, field: keyof LandlordTaxReturn, value: string | number) => void, onDelete: (id: string) => void, onSubmission: (property: LandlordTaxReturn) => void, index: number, onSave: () => void }) {
    const [isOpen, setIsOpen] = useState(false);
    
    const handleInputChange = (field: keyof LandlordTaxReturn, value: string | number) => {
        onUpdate(property.id, field, value);
    };

    return (
        <Card className="border-2 overflow-hidden">
            <Collapsible open={isOpen} onOpenChange={setIsOpen}>
            <div className="p-4 flex justify-between items-center bg-card">
                <div className="flex items-center gap-4">
                    <h2 className="text-2xl font-semibold flex items-baseline gap-2">
                        <span>Property {index + 1}:</span>
                        <span className="text-lg text-muted-foreground font-normal">{property.address}</span>
                    </h2>
                </div>
                <div className="flex items-center gap-4">
                    {property.status === 'Draft' && <span className="text-muted-foreground font-medium">In Draft</span>}
                     <CollapsibleTrigger asChild>
                         <Button variant="outline">
                             <Eye className="mr-2 h-4 w-4" />
                             View / Edit
                         </Button>
                    </CollapsibleTrigger>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(property.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                </div>
            </div>
                 <CollapsibleContent className="space-y-6 p-6 pt-6 border-t">
                    <Card>
                        <CardHeader><CardTitle className="text-lg">Taxpayer & Property Details</CardTitle></CardHeader>
                        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div className="space-y-1">
                                <InfoLabel field="taxYear">Tax Year</InfoLabel>
                                <Input id={`taxYear-${property.id}`} value={property.taxYear} onChange={e => handleInputChange('taxYear', e.target.value)} />
                            </div>
                             <div className="space-y-1">
                                <InfoLabel field="taxpayerName">Taxpayer Name</InfoLabel>
                                <Input id={`taxpayerName-${property.id}`} value={property.taxpayerName} onChange={e => handleInputChange('taxpayerName', e.target.value)} />
                            </div>
                            <div className="space-y-1">
                                <InfoLabel field="utr">UTR</InfoLabel>
                                <Input id={`utr-${property.id}`} value={property.utr} onChange={e => handleInputChange('utr', e.target.value)} />
                            </div>
                             <div className="space-y-1">
                                <InfoLabel field="niNumber">NI Number</InfoLabel>
                                <Input id={`niNumber-${property.id}`} value={property.niNumber} onChange={e => handleInputChange('niNumber', e.target.value)} />
                            </div>
                            <div className="space-y-1 lg:col-span-2">
                                 <InfoLabel field="address">Full Address for Records</InfoLabel>
                                <Input id={`address-full-${property.id}`} value={property.address} onChange={e => handleInputChange('address', e.target.value)} />
                            </div>
                             <div className="space-y-1 lg:col-span-2">
                                 <InfoLabel field="propertyType">Property Type</InfoLabel>
                                <Select value={property.propertyType} onValueChange={(value) => handleInputChange('propertyType', value)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Residential">Residential</SelectItem>
                                        <SelectItem value="FHL">FHL</SelectItem>
                                        <SelectItem value="Commercial">Commercial</SelectItem>
                                        <SelectItem value="Mixed">Mixed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <Card>
                             <CardHeader><CardTitle className="text-lg">Income</CardTitle></CardHeader>
                             <CardContent className="space-y-4">
                                 <div className="space-y-1">
                                    <InfoLabel field="rentalIncome">Rental Income</InfoLabel>
                                    <Input id={`rentalIncome-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.rentalIncome} onChange={e => handleInputChange('rentalIncome', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                     <InfoLabel field="reversePremiums">Reverse Premiums</InfoLabel>
                                    <Input id={`reversePremiums-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.reversePremiums} onChange={e => handleInputChange('reversePremiums', e.target.value)} />
                                </div>
                             </CardContent>
                        </Card>
                         <Card className="lg:col-span-2">
                            <CardHeader><CardTitle className="text-lg">Expenses & Allowances</CardTitle></CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                <div className="space-y-1">
                                    <InfoLabel field="propertyRepairs">Property Repairs & Maintenance</InfoLabel>
                                    <Input id={`propertyRepairs-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.propertyRepairs} onChange={e => handleInputChange('propertyRepairs', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                    <InfoLabel field="maintenance">Maintenance</InfoLabel>
                                    <Input id={`maintenance-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.maintenance} onChange={e => handleInputChange('maintenance', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                    <InfoLabel field="utilities">Utilities</InfoLabel>
                                    <Input id={`utilities-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.utilities} onChange={e => handleInputChange('utilities', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                    <InfoLabel field="insurance">Insurance</InfoLabel>
                                    <Input id={`insurance-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.insurance} onChange={e => handleInputChange('insurance', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                     <InfoLabel field="managementFees">Management Fees</InfoLabel>
                                    <Input id={`managementFees-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.managementFees} onChange={e => handleInputChange('managementFees', e.target.value)} />
                                </div>
                                <div className="space-y-1">
                                    <InfoLabel field="loanInterest">Loan Interest</InfoLabel>
                                    <Input id={`loanInterest-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.loanInterest} onChange={e => handleInputChange('loanInterest', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                    <InfoLabel field="allowableExpenses">Allowable Expenses</InfoLabel>
                                    <Input id={`allowableExpenses-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.allowableExpenses} onChange={e => handleInputChange('allowableExpenses', e.target.value)} />
                                </div>
                                <div className="space-y-1">
                                    <InfoLabel field="capitalAllowance">Capital Allowance</InfoLabel>
                                    <Input id={`capitalAllowance-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.capitalAllowance} onChange={e => handleInputChange('capitalAllowance', e.target.value)} />
                                </div>
                                 <div className="space-y-1">
                                    <InfoLabel field="privateUseAdjustment">Private Use Adjustment</InfoLabel>
                                    <Input id={`privateUseAdjustment-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.privateUseAdjustment} onChange={e => handleInputChange('privateUseAdjustment', e.target.value)} />
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                     <Card>
                        <CardHeader><CardTitle className="text-lg">Summary & Tax Calculation</CardTitle></CardHeader>
                        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                             <div className="space-y-1 p-2 bg-muted rounded-md">
                                <Label>Total Expenses</Label>
                                <div className="font-bold text-lg">£{Number(property.totalExpenses).toFixed(2)}</div>
                            </div>
                             <div className="space-y-1 p-2 bg-muted rounded-md">
                                <Label>Net Profit/Loss</Label>
                                 <div className="font-bold text-lg">£{Number(property.netProfitOrLoss).toFixed(2)}</div>
                            </div>
                             <div className="space-y-1">
                                <InfoLabel field="adjustment">Adjustment</InfoLabel>
                                <Input id={`adjustment-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.adjustment} onChange={e => handleInputChange('adjustment', e.target.value)} />
                            </div>
                            <div className="space-y-1 p-2 bg-muted rounded-md">
                                <Label>Taxable Profit</Label>
                                <div className="font-bold text-lg">£{Number(property.taxableProfit).toFixed(2)}</div>
                            </div>
                            <div className="space-y-1">
                                <InfoLabel field="taxDue">Tax Due</InfoLabel>
                                <Input id={`taxDue-${property.id}`} type="number" onFocus={e => e.target.select()} value={property.taxDue} onChange={e => handleInputChange('taxDue', e.target.value)} />
                            </div>
                             <div className="space-y-1">
                                <InfoLabel field="paymentDeadline">Payment Deadline</InfoLabel>
                                <Input id={`paymentDeadline-${property.id}`} value={property.paymentDeadline} onChange={e => handleInputChange('paymentDeadline', e.target.value)} />
                            </div>
                        </CardContent>
                    </Card>
                    <div className="flex justify-end pt-4 gap-2">
                        <Button onClick={onSave} variant="outline">
                            <Save className="mr-2 h-4 w-4" />
                            Save Draft
                        </Button>
                        <Button onClick={() => onSubmission(property)}>
                            <Send className="mr-2 h-4 w-4" />
                            Approve and Submit Return to HMRC
                        </Button>
                    </div>
                 </CollapsibleContent>
             </Collapsible>
        </Card>
    );
}


export function LandlordReturnForm({ onBack }: { onBack: () => void }) {
    const { toast } = useToast();
    const [properties, setProperties] = useState<LandlordTaxReturn[]>([]);
    
    const [isConfirming, setIsConfirming] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isDeclared, setIsDeclared] = useState(false);
    const [submittingProperty, setSubmittingProperty] = useState<LandlordTaxReturn | null>(null);
    const [submissionHistory, setSubmissionHistory] = useState<LandlordSubmissionHistory[]>([]);
    const [viewingHistory, setViewingHistory] = useState<LandlordSubmissionHistory | null>(null);

    useEffect(() => {
        const storedData = localStorage.getItem('landlordTaxReturns');
        if (storedData) {
            setProperties(JSON.parse(storedData));
        } else {
            setProperties([{ ...initialRow, id: Date.now().toString() }]);
        }

        const storedHistory = localStorage.getItem('landlordSubmissionHistory');
        if(storedHistory) {
            setSubmissionHistory(JSON.parse(storedHistory));
        }

    }, []);

    useEffect(() => {
        if (!isConfirming) {
            // Reset declaration when dialog is closed
            setIsDeclared(false);
        }
    }, [isConfirming]);


    const saveData = () => {
        localStorage.setItem('landlordTaxReturns', JSON.stringify(properties));
        toast({
            title: "Data Saved",
            description: "Your landlord tax return data has been saved as a draft.",
        });
    }

    const handleUpdateProperty = (id: string, field: keyof LandlordTaxReturn, value: string | number) => {
        setProperties(prevProps => {
            const newProps = prevProps.map(prop => {
                if (prop.id === id) {
                    const newProp = { ...prop, [field]: value };
                    return newProp;
                }
                return prop;
            });
            // Auto-calculate derived fields
            return newProps.map(prop => {
                 if (prop.id === id) {
                    const getNum = (val: string | number | undefined) => typeof val === 'string' ? (parseFloat(val) || 0) : (val || 0);

                    const expenses = [
                        'propertyRepairs', 'maintenance', 'utilities', 'insurance', 
                        'managementFees', 'loanInterest', 'allowableExpenses'
                    ].reduce((acc, key) => acc + getNum(prop[key as keyof LandlordTaxReturn]), 0);
                    
                    const totalExpenses = expenses - getNum(prop.privateUseAdjustment) + getNum(prop.capitalAllowance);
                    const netProfit = getNum(prop.rentalIncome) + getNum(prop.reversePremiums) - totalExpenses;
                    const taxableProfit = netProfit + getNum(prop.adjustment);

                    // A simple tax calculation, e.g., 20% basic rate.
                    const taxDue = taxableProfit > 0 ? taxableProfit * 0.20 : 0;

                    return {
                        ...prop,
                        totalExpenses: totalExpenses.toFixed(2),
                        netProfitOrLoss: netProfit.toFixed(2),
                        taxableProfit: taxableProfit.toFixed(2),
                        taxDue: taxDue.toFixed(2),
                    };
                 }
                 return prop;
            });
        });
    };

    const addProperty = () => {
        const lastProperty = properties[properties.length - 1] || initialRow;
        setProperties([...properties, { ...initialRow, id: Date.now().toString(), taxpayerName: lastProperty.taxpayerName, utr: lastProperty.utr, niNumber: lastProperty.niNumber, address: '' }]);
    };

    const deleteProperty = (id: string) => {
        if (properties.length > 1) {
            setProperties(properties.filter(prop => prop.id !== id));
        } else {
            toast({
                variant: 'destructive',
                title: "Cannot Delete",
                description: "You must have at least one property.",
            });
        }
    };
    
    const handleSubmissionClick = (property: LandlordTaxReturn) => {
        setSubmittingProperty(property);
        setIsConfirming(true);
    };


    const handleHMRCSubmit = () => {
        if (!submittingProperty) return;
        setIsSubmitting(true);
        
        setTimeout(() => {
            const updatedProperties = properties.map(p => p.id === submittingProperty.id ? {...p, status: 'Submitted'} : p);
            setProperties(updatedProperties);
            localStorage.setItem('landlordTaxReturns', JSON.stringify(updatedProperties));

            const newHistoryItem: LandlordSubmissionHistory = {
                id: Date.now().toString(),
                submissionDate: new Date().toISOString(),
                propertyAddress: submittingProperty.address,
                taxableProfit: Number(submittingProperty.taxableProfit),
                taxDue: Number(submittingProperty.taxDue),
                hmrcReference: `HMRC-ITSA-${Date.now()}`,
                submittedReturn: submittingProperty,
            };
            const updatedHistory = [newHistoryItem, ...submissionHistory];
            setSubmissionHistory(updatedHistory);
            localStorage.setItem('landlordSubmissionHistory', JSON.stringify(updatedHistory));
            
            toast({
                title: "Submitting to HMRC...",
                description: `Submitting return for property at ${submittingProperty.address}. This is a placeholder for the actual HMRC submission.`,
            });
            console.log("Submitting the following data to HMRC:", submittingProperty);

            setIsSubmitting(false);
            setIsConfirming(false);
            setSubmittingProperty(null);
        }, 2000);
    }
    
    return (
        <>
         <Card>
            <CardHeader className="flex flex-row justify-between items-start">
                <div>
                    <CardTitle>MTD Income Tax (ITSA): Landlord Return</CardTitle>
                    <CardDescription>
                        Enter the details for your property income tax return below. Click "Save Draft" within a property to save your progress.
                    </CardDescription>
                </div>
                 <Button variant="outline" onClick={onBack}>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Selection
                </Button>
            </CardHeader>
            <CardContent className="space-y-6">
                {properties.map((prop, index) => (
                    <div key={prop.id}>
                        <PropertyCard index={index} property={prop} onUpdate={handleUpdateProperty} onDelete={deleteProperty} onSubmission={handleSubmissionClick} onSave={saveData} />
                        {index < properties.length - 1 && (
                            <Separator className="my-8 h-1 bg-cyan-400" />
                        )}
                    </div>
                ))}
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-6">
                <div>
                    <Button onClick={addProperty} variant="outline">
                        <PlusCircle className="mr-2 h-4 w-4" /> Add Property
                    </Button>
                </div>
            </CardFooter>
        </Card>

        {submissionHistory.length > 0 && (
            <Card>
                <CardHeader>
                    <CardTitle>Past Submissions</CardTitle>
                    <CardDescription>A log of your previously submitted landlord returns.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Submission Date</TableHead>
                                <TableHead>Property Address</TableHead>
                                <TableHead>HMRC Reference</TableHead>
                                <TableHead className="text-right">Taxable Profit</TableHead>
                                <TableHead className="text-right">Tax Due</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {submissionHistory.map(item => (
                                <TableRow key={item.id}>
                                    <TableCell>{format(new Date(item.submissionDate), 'dd MMM yyyy, HH:mm')}</TableCell>
                                    <TableCell>{item.propertyAddress}</TableCell>
                                    <TableCell className="font-mono">{item.hmrcReference}</TableCell>
                                    <TableCell className="text-right font-mono">£{item.taxableProfit.toFixed(2)}</TableCell>
                                    <TableCell className="text-right font-mono">£{item.taxDue.toFixed(2)}</TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="sm" onClick={() => setViewingHistory(item)}>
                                            <Eye className="mr-2 h-4 w-4" />
                                            View
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        )}
        
         <Dialog open={isConfirming} onOpenChange={setIsConfirming}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Confirm ITSA Submission to HMRC</DialogTitle>
                    <DialogDescription asChild>
                       <div className="space-y-2">
                         <div className="font-bold">When you submit this tax information you are making a legal declaration that the information is true and complete. A false declaration can result in prosecution.</div>
                         <div>You are about to submit the return for property at <span className="font-bold">{submittingProperty?.address}</span>.</div>
                       </div>
                    </DialogDescription>
                </DialogHeader>
                {submittingProperty && (
                    <div className="py-4 space-y-2">
                        <div className="flex justify-between items-center p-2 rounded-lg bg-muted">
                            <span className="text-muted-foreground">Total Income</span>
                            <span className="font-mono font-bold">£{((Number(submittingProperty.rentalIncome) || 0) + (Number(submittingProperty.reversePremiums) || 0)).toFixed(2)}</span>
                        </div>
                         <div className="flex justify-between items-center p-2">
                            <span className="text-muted-foreground">Total Expenses</span>
                            <span className="font-mono font-bold">£{(Number(submittingProperty.totalExpenses) || 0).toFixed(2)}</span>
                        </div>
                        <Separator/>
                        <div className="flex justify-between items-center p-2">
                            <span className="font-bold">Taxable Profit</span>
                            <span className="font-mono font-bold">£{(Number(submittingProperty.taxableProfit) || 0).toFixed(2)}</span>
                        </div>
                    </div>
                )}
                 <div className="flex items-center space-x-2 pt-4">
                    <Checkbox id="declaration" checked={isDeclared} onCheckedChange={(checked) => setIsDeclared(checked as boolean)} />
                    <Label htmlFor="declaration" className="text-sm">
                       I confirm that I have read the above legal declaration and have authority to submit this tax information.
                    </Label>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsConfirming(false)} disabled={isSubmitting}>Cancel</Button>
                    <Button onClick={handleHMRCSubmit} disabled={isSubmitting || !isDeclared}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Confirm & Submit to HMRC
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>

         <Dialog open={!!viewingHistory} onOpenChange={() => setViewingHistory(null)}>
            <DialogContent className="max-w-4xl">
                <DialogHeader>
                    <DialogTitle>Past Submission Details</DialogTitle>
                     <DialogDescription>
                       Details for submission <span className="font-mono">{viewingHistory?.hmrcReference}</span> for property at <span className="font-semibold">{viewingHistory?.propertyAddress}</span>.
                    </DialogDescription>
                </DialogHeader>
                {viewingHistory && viewingHistory.submittedReturn && (
                    <div className="py-4 space-y-6 max-h-[70vh] overflow-y-auto pr-4">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1 p-4 bg-muted rounded-md">
                                <Label>Taxable Profit</Label>
                                <div className="font-bold text-2xl">£{viewingHistory.taxableProfit.toFixed(2)}</div>
                            </div>
                            <div className="space-y-1 p-4 bg-muted rounded-md">
                                <Label>Tax Due</Label>
                                <div className="font-bold text-2xl">£{viewingHistory.taxDue.toFixed(2)}</div>
                            </div>
                        </div>

                        <Card>
                            <CardHeader><CardTitle className="text-base">Taxpayer & Property Details</CardTitle></CardHeader>
                            <CardContent className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                                <div className="flex justify-between"><span className="text-muted-foreground">Tax Year:</span> <span className="font-medium">{viewingHistory.submittedReturn.taxYear}</span></div>
                                <div className="flex justify-between"><span className="text-muted-foreground">Taxpayer:</span> <span className="font-medium">{viewingHistory.submittedReturn.taxpayerName}</span></div>
                                <div className="flex justify-between"><span className="text-muted-foreground">UTR:</span> <span className="font-medium">{viewingHistory.submittedReturn.utr}</span></div>
                                <div className="flex justify-between"><span className="text-muted-foreground">NI Number:</span> <span className="font-medium">{viewingHistory.submittedReturn.niNumber}</span></div>
                                <div className="flex justify-between col-span-2"><span className="text-muted-foreground">Property Address:</span> <span className="font-medium">{viewingHistory.submittedReturn.address}</span></div>
                                <div className="flex justify-between col-span-2"><span className="text-muted-foreground">Property Type:</span> <span className="font-medium">{viewingHistory.submittedReturn.propertyType}</span></div>
                            </CardContent>
                        </Card>

                        <div className="grid grid-cols-2 gap-6">
                            <Card>
                                <CardHeader><CardTitle className="text-base">Income</CardTitle></CardHeader>
                                <CardContent className="space-y-1 text-sm">
                                    <div className="flex justify-between"><span className="text-muted-foreground">Rental Income:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.rentalIncome).toFixed(2)}</span></div>
                                    <div className="flex justify-between"><span className="text-muted-foreground">Reverse Premiums:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.reversePremiums).toFixed(2)}</span></div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader><CardTitle className="text-base">Summary</CardTitle></CardHeader>
                                <CardContent className="space-y-1 text-sm">
                                    <div className="flex justify-between"><span className="text-muted-foreground">Total Expenses:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.totalExpenses).toFixed(2)}</span></div>
                                    <div className="flex justify-between"><span className="text-muted-foreground">Net Profit/Loss:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.netProfitOrLoss).toFixed(2)}</span></div>
                                    <div className="flex justify-between"><span className="text-muted-foreground">Adjustments:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.adjustment).toFixed(2)}</span></div>
                                    <Separator className="my-2"/>
                                    <div className="flex justify-between font-bold"><span className="text-foreground">Taxable Profit:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.taxableProfit).toFixed(2)}</span></div>
                                </CardContent>
                            </Card>
                        </div>
                        
                         <Card>
                            <CardHeader><CardTitle className="text-base">Expenses & Allowances</CardTitle></CardHeader>
                            <CardContent className="grid grid-cols-2 gap-x-8 gap-y-1 text-sm">
                               <div className="flex justify-between"><span className="text-muted-foreground">Repairs:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.propertyRepairs).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Maintenance:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.maintenance).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Utilities:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.utilities).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Insurance:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.insurance).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Management Fees:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.managementFees).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Loan Interest:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.loanInterest).toFixed(2)}</span></div>
                               <div className="flex justify-between"><span className="text-muted-foreground">Other Expenses:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.allowableExpenses).toFixed(2)}</span></div>
                               <Separator className="col-span-2 my-2"/>
                               <div className="flex justify-between"><span className="text-muted-foreground">Capital Allowance:</span> <span className="font-mono">£{Number(viewingHistory.submittedReturn.capitalAllowance).toFixed(2)}</span></div>
                               <div className="flex justify-between text-destructive"><span className="text-destructive">Private Use Adj.:</span> <span className="font-mono">-£{Number(viewingHistory.submittedReturn.privateUseAdjustment).toFixed(2)}</span></div>
                            </CardContent>
                        </Card>
                        
                    </div>
                )}
            </DialogContent>
        </Dialog>
        </>
    )

}
