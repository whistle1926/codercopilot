

"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useActiveClient } from '@/hooks/use-active-client';
import type { QuestionnaireSubmission, StaffMember, Client } from '@/lib/types';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Check, Loader2 } from 'lucide-react';
import { format } from 'date-fns';

export default function QuestionnairePage() {
    const router = useRouter();
    const { toast } = useToast();
    const { activeClient, setActiveClient } = useActiveClient();
    const [isLoading, setIsLoading] = useState(false);

    const [projectName, setProjectName] = useState('');
    const [projectDescription, setProjectDescription] = useState('');
    const [workload, setWorkload] = useState('');
    const [otherInfo, setOtherInfo] = useState('');


    const handleSubmit = () => {
        if (!activeClient) {
             toast({
                variant: "destructive",
                title: "No Active Client",
                description: "Please log in as a company to submit a questionnaire.",
            });
            return;
        }

        setIsLoading(true);

        const newSubmission: QuestionnaireSubmission = {
            companyId: activeClient.id,
            projectName,
            projectDescription,
            professionalType: [], // No longer asking for this
            tasks: [], // No longer asking for this
            workload,
            technologies: '', // No longer asking for this
            skills: otherInfo,
            submissionDate: new Date().toISOString(),
        };

        const allSubmissions: QuestionnaireSubmission[] = JSON.parse(localStorage.getItem('questionnaireSubmissions') || '[]');
        localStorage.setItem('questionnaireSubmissions', JSON.stringify([...allSubmissions, newSubmission]));

        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const teamLead = allStaff.find(s => s.isTeamLead && s.availability === 'Available For Hire');
        
        let updatedClient: Client = { ...activeClient, questionnaireCompleted: true };

        if (teamLead) {
            updatedClient.assignedTeamLeadId = teamLead.id;
        } else {
             toast({
                variant: 'destructive',
                title: 'No Team Leads Available',
                description: 'We will assign a contact person for you shortly.',
            });
        }
        
        const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
        const updatedClients = allClients.map((c: any) => c.id === activeClient.id ? updatedClient : c);
        localStorage.setItem('clients', JSON.stringify(updatedClients));
        setActiveClient(updatedClient);

        setTimeout(() => {
            toast({
                title: "Questionnaire Submitted",
                description: "Thank you! You are being redirected to your point of contact.",
            });
            if (teamLead) {
                router.push(`/dashboard/team-lead?leadId=${teamLead.id}`);
            } else {
                router.push('/dashboard/staff-hub'); // Fallback if no lead found
            }
            setIsLoading(false);
        }, 1500);
    };

    return (
        <Card className="max-w-4xl mx-auto">
            <CardHeader>
                <CardTitle className="text-2xl">Tell Us About Your Project</CardTitle>
                <CardDescription>
                    This information will help our Project Managers understand your needs and recommend the best professionals for the job. Please be as detailed as possible.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                 <div className="space-y-4">
                    <Label className="text-lg font-semibold" htmlFor="project-name">1. What is the name of your project?</Label>
                    <Input id="project-name" placeholder="e.g., 'New Customer Onboarding Flow'" value={projectName} onChange={(e) => setProjectName(e.target.value)} />
                </div>

                <div className="space-y-4">
                    <Label className="text-lg font-semibold" htmlFor="project-description">2. Please describe your project in detail. *</Label>
                     <p className="text-sm text-muted-foreground">What problem are you trying to solve? What are the goals and expected outcomes? Who is the end user? The more detail, the better. Don't worry about the technical specifics; that's what we're here for!</p>
                    <Textarea 
                        id="project-description" 
                        value={projectDescription} 
                        onChange={(e) => setProjectDescription(e.target.value)}
                        rows={8}
                        placeholder="e.g., We need to build a new customer dashboard from scratch that allows our users to see their order history, track shipments, and manage their subscription. It needs to be user-friendly and integrate with our existing order management system..."
                    />
                </div>

                <div className="space-y-4">
                    <Label className="text-lg font-semibold">3. What is the expected duration or workload? *</Label>
                    <RadioGroup value={workload} onValueChange={setWorkload} className="flex flex-col sm:flex-row gap-4">
                        <Label className="flex-1 flex items-center gap-2 p-4 border rounded-lg cursor-pointer has-[:checked]:bg-primary has-[:checked]:text-primary-foreground has-[:checked]:border-primary transition-colors">
                            <RadioGroupItem value="Short-term" id="short-term" className="sr-only" />
                            {workload === "Short-term" && <Check className="h-5 w-5" />}
                            <span>Short-term Project (e.g., 2-4 weeks)</span>
                        </Label>
                         <Label className="flex-1 flex items-center gap-2 p-4 border rounded-lg cursor-pointer has-[:checked]:bg-primary has-[:checked]:text-primary-foreground has-[:checked]:border-primary transition-colors">
                            <RadioGroupItem value="Long-term" id="long-term" className="sr-only" />
                             {workload === "Long-term" && <Check className="h-5 w-5" />}
                            <span>Long-term Engagement (Months)</span>
                        </Label>
                         <Label className="flex-1 flex items-center gap-2 p-4 border rounded-lg cursor-pointer has-[:checked]:bg-primary has-[:checked]:text-primary-foreground has-[:checked]:border-primary transition-colors">
                            <RadioGroupItem value="Ongoing" id="ongoing" className="sr-only" />
                             {workload === "Ongoing" && <Check className="h-5 w-5" />}
                            <span>Ongoing / Part-time</span>
                        </Label>
                    </RadioGroup>
                </div>
                
                <div className="space-y-4">
                    <Label htmlFor="otherInfo" className="text-lg font-semibold">4. Is there anything else we should know?</Label>
                    <Textarea id="otherInfo" value={otherInfo} onChange={(e) => setOtherInfo(e.target.value)} placeholder="e.g., 'We have a strict deadline', 'The project involves sensitive data', 'This integrates with an old system', etc." />
                </div>

            </CardContent>
            <CardFooter>
                 <Button onClick={handleSubmit} disabled={isLoading || !projectDescription || !workload} className="w-full md:w-auto ml-auto">
                    {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Submit & Find My Team Lead
                </Button>
            </CardFooter>
        </Card>
    );
}
