

"use client";

import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { CheckCircle, Star } from 'lucide-react';
import { useActiveClient } from '@/hooks/use-active-client';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import type { CreditPackage } from '@/lib/types';
import Link from 'next/link';


export default function CreditsPage() {
    const { activeClient } = useActiveClient();
    
    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Cash Balance</CardTitle>
                    <CardDescription>Purchase a cash balance to hire professionals from the Staff Hub.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <div className="p-4 rounded-lg bg-muted flex items-center justify-between">
                        <div className="space-y-1">
                            <p className="text-sm font-medium text-muted-foreground">Your Current Balance</p>
                            <p className="text-3xl font-bold">£{activeClient?.cashBalance?.toFixed(2) || '0.00'}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
            
            <Card>
                <CardHeader>
                    <CardTitle>Top Up Your Balance</CardTitle>
                    <CardDescription>Choose a package that suits your needs. Your balance never expires.</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card 
                        className="flex flex-col text-center"
                    >
                        <CardHeader>
                            <CardTitle className="text-2xl">£500</CardTitle>
                            <CardDescription>Top up your account balance</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow flex flex-col justify-center items-center">
                            <p className="text-4xl font-bold">£500</p>
                            <p className="text-muted-foreground">one-time payment</p>
                        </CardContent>
                        <CardFooter>
                            <Button className="w-full" asChild>
                                <Link href="https://buy.stripe.com/test_5kQ4gBgmSfgybF91rjeQM01" target="_blank">
                                    Purchase
                                </Link>
                            </Button>
                        </CardFooter>
                    </Card>
                </CardContent>
            </Card>

        </div>
    );
}
