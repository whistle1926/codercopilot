
"use client";

import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Upload, File, Trash2, Download } from 'lucide-react';
import { format } from 'date-fns';
import type { UploadedDocument } from '@/lib/types';
import { cn } from '@/lib/utils';

function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}


export default function DocumentsPage() {
    const [file, setFile] = useState<File | null>(null);
    const [referenceName, setReferenceName] = useState('');
    const [documents, setDocuments] = useState<UploadedDocument[]>([]);
    const { toast } = useToast();

    useEffect(() => {
        const storedDocs = localStorage.getItem('documents');
        if (storedDocs) {
            setDocuments(JSON.parse(storedDocs));
        }
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            setFile(e.target.files[0]);
        }
    };

    const handleUpload = () => {
        if (!file || !referenceName) {
            toast({
                variant: 'destructive',
                title: 'Missing Information',
                description: 'Please select a file and provide a reference name.',
            });
            return;
        }

        const newDocument: UploadedDocument = {
            id: Date.now().toString(),
            referenceName,
            fileName: file.name,
            uploadDate: new Date().toISOString(),
            fileType: file.type,
            fileSize: file.size,
        };
        
        // In a real app, you would upload the file to a storage service.
        // For this prototype, we'll just add it to our local state and local storage.
        const updatedDocuments = [...documents, newDocument];
        setDocuments(updatedDocuments);
        localStorage.setItem('documents', JSON.stringify(updatedDocuments));
        
        // This part is a mock of storing the file itself.
        // We'll use FileReader to store it as a data URL in local storage.
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            localStorage.setItem(`doc_${newDocument.id}`, reader.result as string);
        }

        toast({
            title: 'Upload Successful',
            description: `Document "${referenceName}" has been uploaded.`,
        });

        // Reset form
        setFile(null);
        setReferenceName('');
        // Clear file input
        const fileInput = document.getElementById('file-upload') as HTMLInputElement;
        if(fileInput) fileInput.value = '';

    };

    const handleDelete = (docId: string) => {
        const updatedDocuments = documents.filter(doc => doc.id !== docId);
        setDocuments(updatedDocuments);
        localStorage.setItem('documents', JSON.stringify(updatedDocuments));
        localStorage.removeItem(`doc_${docId}`); // Remove the mock file data
        toast({
            title: 'Document Deleted',
            description: 'The selected document has been removed.',
        });
    }

    const handleDownload = (docId: string) => {
        const dataUrl = localStorage.getItem(`doc_${docId}`);
        const doc = documents.find(d => d.id === docId);
        if (dataUrl && doc) {
            const link = document.createElement('a');
            link.href = dataUrl;
            link.download = doc.fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
             toast({
                variant: 'destructive',
                title: 'Download Failed',
                description: 'Could not find the file data to download.',
            });
        }
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Document Upload</CardTitle>
                    <CardDescription>Upload and manage your documents for reference.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="ref-name">Reference Name</Label>
                        <Input 
                            id="ref-name" 
                            value={referenceName}
                            onChange={(e) => setReferenceName(e.target.value)}
                            placeholder="e.g., Q1 2024 P&L Statement"
                        />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="file-upload">File</Label>
                        <Input id="file-upload" type="file" onChange={handleFileChange} />
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleUpload} disabled={!file || !referenceName}>
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Document
                    </Button>
                </CardFooter>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Uploaded Documents</CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-10 border-r"><File className="h-5 w-5" /></TableHead>
                                <TableHead className="border-r">Reference Name</TableHead>
                                <TableHead className="border-r">Original Filename</TableHead>
                                <TableHead className="border-r">Upload Date</TableHead>
                                <TableHead className="border-r">File Size</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {documents.map(doc => (
                                <TableRow key={doc.id}>
                                    <TableCell className="border-r">{/* You could show a file type icon here */}</TableCell>
                                    <TableCell className="font-medium border-r">{doc.referenceName}</TableCell>
                                    <TableCell className="text-muted-foreground border-r">{doc.fileName}</TableCell>
                                    <TableCell className="border-r">{format(new Date(doc.uploadDate), 'dd MMM yyyy, HH:mm')}</TableCell>
                                    <TableCell className="border-r">{formatBytes(doc.fileSize)}</TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="icon" onClick={() => handleDownload(doc.id)}>
                                            <Download className="h-4 w-4" />
                                        </Button>
                                        <Button variant="ghost" size="icon" onClick={() => handleDelete(doc.id)}>
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {documents.length === 0 && (
                        <div className="text-center p-8 text-muted-foreground">
                            No documents have been uploaded yet.
                        </div>
                    )}
                </CardContent>
            </Card>

        </div>
    )
}
