

"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useActiveClient } from "@/hooks/use-active-client";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

export default function ProfilePage() {
    const pathname = usePathname();
    const { activeClient } = useActiveClient();
    const isSuperAdmin = pathname.includes('/super-admin') && !activeClient;
    
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');

    useEffect(() => {
        if (isSuperAdmin) {
            setName('Super Admin');
            setEmail('super.admin@example.com');
        } else if (activeClient) {
            setName(activeClient.mainContactPerson || '');
            setEmail(activeClient.email || '');
        }
    }, [isSuperAdmin, activeClient]);


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>Manage your profile settings and personal information.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="font-medium">Personal Information</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
             </div>
          </div>
        </CardContent>
        <CardFooter className="border-t pt-6">
             <Button>Save Changes</Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Change Password</CardTitle>
            <CardDescription>Update your password. Make sure it's a strong one.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input id="new-password" type="password" />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input id="confirm-password" type="password" />
                </div>
            </div>
        </CardContent>
        <CardFooter className="border-t pt-6">
             <Button>Update Password</Button>
        </CardFooter>
      </Card>

      <Card>
          <CardHeader>
              <CardTitle>Profile Picture</CardTitle>
              <CardDescription>Update your avatar. It will be shown in the navigation bar.</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center gap-6">
              <Avatar className="h-20 w-20">
                <AvatarImage src="https://picsum.photos/seed/user-avatar/80/80" alt="@accountant" data-ai-hint="professional portrait" />
                <AvatarFallback>AC</AvatarFallback>
              </Avatar>
              <div className="flex-grow">
                <Input id="picture" type="file" />
                <p className="text-xs text-muted-foreground mt-2">Recommended size: 200x200px. PNG or JPG.</p>
              </div>
          </CardContent>
           <CardFooter className="border-t pt-6">
             <Button>Update Avatar</Button>
        </CardFooter>
      </Card>

    </div>
  );
}
