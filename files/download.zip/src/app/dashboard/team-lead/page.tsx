

"use client";

import { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import type { StaffMember, Skill } from '@/lib/types';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Award, MessageSquare, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import Link from 'next/link';

function SkillBar({ skill }: { skill: Skill }) {
    const levelValues = { 'Intermediate': 60, 'Advanced': 80, 'Expert': 100 };
    const isMtdCertified = skill.name === 'Coder Co-Pilot Certified';
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className={cn("text-sm font-medium", isMtdCertified && "text-primary")}>{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                    <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600', 
                            isMtdCertified && 'bg-primary',
                            skill.level === 'Advanced' && 'bg-blue-100 text-blue-800',
                            skill.level === 'Intermediate' && 'bg-blue-100 text-blue-800'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={levelValues[skill.level]} className={cn("h-2", isMtdCertified && "[&>div]:bg-primary")} />
        </div>
    )
}

export default function TeamLeadPage() {
    const searchParams = useSearchParams();
    const router = useRouter();
    const leadId = searchParams.get('leadId');
    const [teamLead, setTeamLead] = useState<StaffMember | null>(null);

    useEffect(() => {
        if (!leadId) {
            router.push('/dashboard/staff-hub'); // Redirect if no lead ID
            return;
        }

        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const lead = allStaff.find(s => s.id === leadId);
        
        if (lead) {
            setTeamLead(lead);
        } else {
            // Handle case where lead is not found
            console.error("Team Lead not found");
            router.push('/dashboard/staff-hub');
        }

    }, [leadId, router]);

    if (!teamLead) {
        return <div>Loading Team Lead information...</div>;
    }
    
    const isMtdCertified = teamLead.technicalSkills.some(skill => skill.name === 'Coder Co-Pilot Certified');

    return (
        <div className="max-w-4xl mx-auto">
            <Card>
                <CardHeader className="text-center">
                    <CardTitle className="text-3xl">You've Been Matched!</CardTitle>
                    <CardDescription className="text-lg">Meet your new point of contact for project management and team allocation.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                     <div className="flex flex-col sm:flex-row items-center gap-6 p-6 rounded-lg border bg-muted">
                        <Avatar className="h-32 w-32 border-4 border-primary">
                            <AvatarImage src={teamLead.avatarUrl} alt={teamLead.name} />
                            <AvatarFallback className="text-4xl">
                                {teamLead.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 text-center sm:text-left">
                            <h2 className="text-3xl font-bold">{teamLead.name}</h2>
                            <Badge variant="secondary" className="text-lg mt-1">{teamLead.role}</Badge>
                            <p className="text-muted-foreground mt-2">{teamLead.location}</p>
                            <div className="mt-4 flex flex-wrap justify-center sm:justify-start gap-x-4 gap-y-2 text-sm text-muted-foreground">
                                {teamLead.verified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Co-Pilot Pro Verified</div>}
                                {isMtdCertified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Co-Pilot Approved</div>}
                                {teamLead.premium && <div className="flex items-center gap-1 font-semibold text-amber-500"><Award className="h-4 w-4" /> Top Rated By Employers</div>}
                            </div>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                             <h3 className="font-semibold text-xl border-b pb-2">About</h3>
                             <p className="text-muted-foreground">{teamLead.about}</p>
                        </div>
                        <div className="space-y-4">
                             <h3 className="font-semibold text-xl border-b pb-2">Next Steps</h3>
                             <p className="text-muted-foreground">
                                {teamLead.name.split(' ')[0]} will be in touch shortly to discuss your requirements. In the meantime, you can schedule a call or start a conversation.
                             </p>
                             <div className="space-y-2">
                                 <Button asChild className="w-full">
                                    <Link href={`/dashboard/messages?staffId=${teamLead.id}`}>
                                        <MessageSquare className="mr-2 h-4 w-4" /> Start Conversation
                                    </Link>
                                 </Button>
                                  <Button asChild variant="outline" className="w-full">
                                    <Link href="/signup/schedule">
                                        <Calendar className="mr-2 h-4 w-4" /> Schedule a Call
                                    </Link>
                                </Button>
                             </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold text-xl border-b pb-2 mb-4">Skills & Expertise</h3>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                              <div className="space-y-4">
                                  <h4 className="font-medium">Technical Skills</h4>
                                  {teamLead.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                              <div className="space-y-4">
                                  <h4 className="font-medium">Soft Skills</h4>
                                  {teamLead.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                              </div>
                          </div>
                    </div>

                </CardContent>
            </Card>
        </div>
    )
}
