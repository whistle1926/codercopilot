

"use client";

import { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { clients as initialClients, incomeSources as initialIncomeSources } from '@/lib/data';
import type { Client, Invoice, IncomeSource, VatTransaction, BankTransaction } from '@/lib/types';
import { Check, PlusCircle, ArrowLeft, ArrowRight, Trash2, Save, Send, Search, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useSearchParams } from 'next/navigation';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { addClient } from '@/app/actions/client';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import dynamic from 'next/dynamic';
import { Checkbox } from '@/components/ui/checkbox';

interface LineItem {
    id: number;
    description: string;
    quantity: number;
    unitPrice: number;
    vatRate: string;
}

interface MtdDetails {
    includeInMtd: boolean;
    incomeSource: string;
    allowYapilyPayment: boolean;
}

function AddClientDialog({ open, onOpenChange, onClientAdded, toast }: { open: boolean, onOpenChange: (open: boolean) => void, onClientAdded: (client: Client) => void, toast: (options: any) => void }) {
    const [name, setName] = useState('');
    const [tradingName, setTradingName] = useState('');
    const [email, setEmail] = useState('');
    const [contact, setContact] = useState('');
    const [phone, setPhone] = useState('');
    const [address, setAddress] = useState('');
    const [zipcode, setZipcode] = useState('');
    const [refNo, setRefNo] = useState('');
    const [vatNo, setVatNo] = useState('');
    

    const handleSubmit = async () => {
        const newClientData = {
            name,
            tradingName,
            mainContactPerson: contact,
            email,
            phoneNumber: phone,
            address,
            zipcode,
            referenceNo: refNo,
            vatNumber: vatNo,
        };
        try {
            const newClient = await addClient(newClientData);
            toast({
                title: "Client Added",
                description: `${name} has been added to your client list.`,
            });
            onClientAdded(newClient);
            onOpenChange(false);
        } catch (e) {
             toast({
                variant: "destructive",
                title: "Error adding client",
                description: e instanceof Error ? e.message : "An unknown error occurred.",
            });
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>Add New Client</DialogTitle>
                    <DialogDescription>
                        Enter the details for your new client below.
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Client Name</Label>
                        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="tradingName">Trading Business Name (Optional)</Label>
                        <Input id="tradingName" value={tradingName} onChange={(e) => setTradingName(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="contact">Main Contact Person</Label>
                        <Input id="contact" value={contact} onChange={(e) => setContact(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
                    </div>
                    <div className="space-y-2 col-span-2">
                        <Label htmlFor="address">Address</Label>
                        <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="zipcode">Zip/Postcode</Label>
                        <Input id="zipcode" value={zipcode} onChange={(e) => setZipcode(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="refNo">Reference No.</Label>
                        <Input id="refNo" value={refNo} onChange={(e) => setRefNo(e.target.value)} />
                    </div>
                    <div className="space-y-2 col-span-2">
                        <Label htmlFor="vatNo">VAT Number</Label>
                        <Input id="vatNo" value={vatNo} onChange={(e) => setVatNo(e.target.value)} />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSubmit}>Save Client</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}


function ClientSelectionStep({ onClientSelect, goToNextStep, toast }: { onClientSelect: (client: Client) => void, goToNextStep: () => void, toast: (options: any) => void }) {
    const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isAddClientOpen, setIsAddClientOpen] = useState(false);
    const [clientList, setClientList] = useState<Client[]>([]);

    useEffect(() => {
        const storedClients = localStorage.getItem('clients');
        const clients = storedClients ? JSON.parse(storedClients) : initialClients;
        setClientList(clients);
    }, []);

    const handleSelect = (client: Client) => {
        setSelectedClientId(client.id);
        onClientSelect(client);
    }
    
    const handleClientAdded = (newClient: Client) => {
        const newClientList = [...clientList, newClient];
        setClientList(newClientList);
        
        const allClients = JSON.parse(localStorage.getItem('clients') || JSON.stringify(initialClients));
        localStorage.setItem('clients', JSON.stringify([...allClients, newClient]));
    }

    const filteredClients = useMemo(() => {
        return clientList.filter(client =>
            client.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, clientList]);
    
  return (
    <>
    <Card>
      <CardHeader>
        <CardTitle>Create New Invoice (Step 1 of 4)</CardTitle>
        <CardDescription>First, select a client for this invoice.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
                type="text"
                placeholder="Search for a client..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
            />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClients.map((client) => (
            <Card 
              key={client.id} 
              className={cn(
                "cursor-pointer hover:border-primary transition-all relative flex flex-col",
                selectedClientId === client.id && "border-2 border-primary"
              )}
              onClick={() => handleSelect(client)}
            >
              <CardContent className="p-4 flex-grow">
                <div className="font-semibold">{client.name}</div>
                <div className="text-sm text-muted-foreground">{client.email}</div>
                {selectedClientId === client.id && (
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                        <Check className="h-4 w-4" />
                    </div>
                )}
              </CardContent>
              {selectedClientId === client.id && (
                <CardFooter className="p-2 border-t">
                    <Button onClick={goToNextStep} className="w-full">
                        Next: Add Details
                        <ArrowRight className="ml-2" />
                    </Button>
                </CardFooter>
              )}
            </Card>
          ))}
          {filteredClients.length === 0 && (
             <div className="text-muted-foreground col-span-full text-center py-8">
                No clients found matching your search.
             </div>
          )}
            <Card className="cursor-pointer hover:border-primary transition-all flex items-center justify-center border-2 border-dashed" onClick={() => setIsAddClientOpen(true)}>
                <CardContent className="p-4 text-center">
                    <PlusCircle className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <div className="font-semibold">Add New Client</div>
                </CardContent>
            </Card>
        </div>
      </CardContent>
    </Card>
    <AddClientDialog open={isAddClientOpen} onOpenChange={setIsAddClientOpen} onClientAdded={handleClientAdded} toast={toast} />
    </>
  );
}

function InvoiceDetailsStep({ 
    client,
    invoiceNumber,
    setInvoiceNumber,
    invoiceDate,
    setInvoiceDate,
    dueDate,
    setDueDate,
    isEditing,
}: { 
    client: Client,
    invoiceNumber: string,
    setInvoiceNumber: (val: string) => void,
    invoiceDate: Date | undefined,
    setInvoiceDate: (date: Date | undefined) => void,
    dueDate: Date | undefined,
    setDueDate: (date: Date | undefined) => void,
    isEditing: boolean,
}) {
    useEffect(() => {
        if (invoiceDate && dueDate && dueDate < invoiceDate) {
            setDueDate(undefined);
        }
    }, [invoiceDate, dueDate, setDueDate]);

    return (
        <Card>
            <CardHeader className="grid grid-cols-2">
                 <div>
                    <CardTitle>{isEditing ? 'Edit Invoice' : 'Create New Invoice (Step 2 of 4)'}</CardTitle>
                    <CardDescription>Enter the invoice details for {client.name}.</CardDescription>
                 </div>
                <div className="text-right">
                    <p className="font-semibold">Client - {client.name}</p>
                    <p className="text-sm text-muted-foreground">Invoice No. {invoiceNumber}</p>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {!isEditing && (
                    <div className="bg-muted p-4 rounded-lg mb-6 text-center">
                        <p className="font-bold text-lg text-foreground">You have 2 actions to take on this page:</p>
                        <p className="text-muted-foreground">1. Select Invoice Date and 2. Select a Due Date</p>
                    </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="invoiceNumber">Invoice Number</Label>
                        <Input id="invoiceNumber" value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                         <div className="flex items-center gap-2">
                            <Label>Invoice Date</Label>
                             {invoiceDate && <span className="text-sm text-muted-foreground">{format(invoiceDate, 'PPP')}</span>}
                        </div>
                        <Calendar
                            mode="single"
                            selected={invoiceDate}
                            onSelect={setInvoiceDate}
                            className="rounded-md border"
                        />
                    </div>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <Label>Due Date</Label>
                            {dueDate && <span className="text-sm text-muted-foreground">{format(dueDate, 'PPP')}</span>}
                        </div>
                        <Calendar
                            mode="single"
                            selected={dueDate}
                            onSelect={setDueDate}
                            className="rounded-md border"
                            disabled={{ before: invoiceDate || new Date(0) }}
                        />
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function LineItemsStep({ 
    client, 
    invoiceNumber, 
    lineItems, 
    setLineItems, 
    mtdDetails, 
    setMtdDetails,
    discount,
    setDiscount,
    isEditing,
}: { 
    client: Client, 
    invoiceNumber: string, 
    lineItems: LineItem[], 
    setLineItems: React.Dispatch<React.SetStateAction<LineItem[]>>,
    mtdDetails: MtdDetails,
    setMtdDetails: React.Dispatch<React.SetStateAction<MtdDetails>>,
    discount: number | '',
    setDiscount: (val: number | '') => void,
    isEditing: boolean,
}) {
    const [incomeSources, setIncomeSources] = useState<IncomeSource[]>([]);

    useEffect(() => {
        const storedSources = localStorage.getItem('incomeSources');
        setIncomeSources(storedSources ? JSON.parse(storedSources) : initialIncomeSources);
    }, []);

    useEffect(() => {
        if (incomeSources.length > 0 && !mtdDetails.incomeSource) {
            setMtdDetails(prev => ({...prev, incomeSource: incomeSources[0].name}));
        }
    }, [incomeSources, mtdDetails.incomeSource, setMtdDetails]);
    
    const addNewLineItem = () => {
        const newLine: LineItem = {
            id: Date.now(),
            description: '',
            quantity: 1,
            unitPrice: 0,
            vatRate: '20',
        };
        setLineItems([...lineItems, newLine]);
    };

    const updateLineItem = (id: number, field: keyof Omit<LineItem, 'id'>, value: string | number | boolean) => {
        setLineItems(lineItems.map(item => item.id === id ? { ...item, [field]: value } : item));
    };

    const removeLineItem = (id: number) => {
        setLineItems(lineItems.filter(item => item.id !== id));
    };

    const calculateTotals = useMemo(() => {
        let subtotal = 0;
        let vat = 0;
        
        lineItems.forEach(item => {
            const itemTotal = item.quantity * item.unitPrice;
            const itemVat = itemTotal * (parseFloat(item.vatRate) / 100);
            subtotal += itemTotal;
            vat += itemVat;
        });

        const numDiscount = typeof discount === 'string' ? 0 : discount;
        const net = subtotal - numDiscount;
        const gross = net + vat;

        return { subtotal, net, vat, gross };
    }, [lineItems, discount]);
    
    return (
        <Card>
            <CardHeader className="grid grid-cols-2">
                 <div>
                    <CardTitle>{isEditing ? 'Edit Invoice' : 'Create New Invoice (Step 3 of 4)'}</CardTitle>
                    <CardDescription>Add line items for {client.name}.</CardDescription>
                 </div>
                <div className="text-right">
                    <p className="font-semibold">Client - {client.name}</p>
                    <p className="text-sm text-muted-foreground">Invoice No. {invoiceNumber}</p>
                </div>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[40%] border-r">Description</TableHead>
                                <TableHead className="border-r">Qty</TableHead>
                                <TableHead className="border-r">Unit Price</TableHead>
                                <TableHead className="border-r">VAT</TableHead>
                                <TableHead className="text-right border-r">Total</TableHead>
                                <TableHead></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {lineItems.map((item) => (
                                <TableRow key={item.id}>
                                    <TableCell className="border-r">
                                        <Input 
                                            type="text" 
                                            placeholder={`Item description`}
                                            value={item.description} 
                                            onChange={(e) => updateLineItem(item.id, 'description', e.target.value)} 
                                        />
                                    </TableCell>
                                    <TableCell className="border-r">
                                        <Input 
                                            type="number" 
                                            value={item.quantity} 
                                            onChange={(e) => updateLineItem(item.id, 'quantity', parseInt(e.target.value, 10) || 0)} 
                                            className="w-20"
                                        />
                                    </TableCell>
                                    <TableCell className="border-r">
                                        <div className="relative">
                                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">£</span>
                                            <Input 
                                                type="number" 
                                                value={item.unitPrice} 
                                                onChange={(e) => updateLineItem(item.id, 'unitPrice', e.target.value === '' ? '' : parseFloat(e.target.value))}
                                                className="w-28 pl-6"
                                                placeholder="0.00"
                                            />
                                        </div>
                                    </TableCell>
                                    <TableCell className="border-r">
                                        <Select value={item.vatRate} onValueChange={(value) => updateLineItem(item.id, 'vatRate', value)}>
                                            <SelectTrigger className="w-24">
                                                <SelectValue placeholder="VAT Rate" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="20">20%</SelectItem>
                                                <SelectItem value="5">5%</SelectItem>
                                                <SelectItem value="0">0%</SelectItem>
                                                <SelectItem value="exempt">Exempt</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </TableCell>
                                    <TableCell className="text-right font-mono border-r">
                                        £{((item.quantity * item.unitPrice) * (1 + parseFloat(item.vatRate)/100) || 0).toFixed(2)}
                                    </TableCell>
                                    <TableCell>
                                        <Button variant="ghost" size="icon" onClick={() => removeLineItem(item.id)}>
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <Button onClick={addNewLineItem} variant="outline">
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Add New Line
                    </Button>

                    <Separator className="my-6" />

                    <div className="space-y-4 rounded-lg border bg-muted/50 p-4">
                        <h4 className="font-semibold text-foreground">MTD Reporting Details (Internal Use Only)</h4>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <Label>Income Source</Label>
                                <RadioGroup 
                                    value={mtdDetails.incomeSource} 
                                    onValueChange={(value) => setMtdDetails(prev => ({...prev, incomeSource: value}))}
                                    className="flex items-center gap-4"
                                >
                                    {incomeSources.map(source => (
                                        <div className="flex items-center space-x-2" key={source.id}>
                                            <RadioGroupItem value={source.name} id={source.id} />
                                            <Label htmlFor={source.id}>{source.name}</Label>
                                        </div>
                                    ))}
                                </RadioGroup>
                            </div>
                             <div className="space-y-2">
                                <Label>Include this invoice in MTD Return?</Label>
                                <div className="flex gap-2">
                                    <Button
                                        onClick={() => setMtdDetails(prev => ({...prev, includeInMtd: true}))}
                                        variant={mtdDetails.includeInMtd ? 'default' : 'outline'}
                                        className={cn('w-full', mtdDetails.includeInMtd && 'bg-green-500 hover:bg-green-600')}
                                    >
                                        Include in Return
                                    </Button>
                                    <Button
                                        onClick={() => setMtdDetails(prev => ({...prev, includeInMtd: false}))}
                                        variant={!mtdDetails.includeInMtd ? 'destructive' : 'outline'}
                                        className='w-full'
                                    >
                                        Do Not Include
                                    </Button>
                                </div>
                            </div>
                            <div className="flex items-center space-x-2 col-span-2">
                                <Checkbox
                                    id="yapily-payment"
                                    checked={mtdDetails.allowYapilyPayment}
                                    onCheckedChange={(checked) => setMtdDetails(prev => ({ ...prev, allowYapilyPayment: !!checked }))}
                                />
                                <Label htmlFor="yapily-payment">Allow recipient to pay this invoice using Yapily Open Banking</Label>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
            <CardFooter className="flex justify-end bg-muted/50 p-4 rounded-b-lg">
                <div className="grid w-full max-w-sm gap-2">
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">Subtotal:</span>
                        <span className="font-mono">£{calculateTotals.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Discount:</span>
                         <div className="w-40 space-y-2">
                            <div className="relative">
                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">£</span>
                                <Input 
                                    type="number" 
                                    value={discount} 
                                    onChange={(e) => setDiscount(e.target.value === '' ? '' : parseFloat(e.target.value))} 
                                    className="pl-6 text-right"
                                    placeholder="0.00"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-between font-bold border-t pt-2">
                        <span>Net Total:</span>
                        <span className="font-mono">£{calculateTotals.net.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">VAT Total:</span>
                        <span className="font-mono">£{calculateTotals.vat.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold border-t pt-2">
                        <span>Gross Total:</span>
                        <span className="font-mono">£{calculateTotals.gross.toFixed(2)}</span>
                    </div>
                </div>
            </CardFooter>
        </Card>
    );
}

function ReviewStep({
  client,
  invoiceNumber,
  invoiceDate,
  dueDate,
  lineItems,
  totals,
  discount,
  mtdDetails,
  onSaveDraft,
  onApprove,
  isEditing,
  onUpdate,
}: {
  client: Client;
  invoiceNumber: string;
  invoiceDate?: Date;
  dueDate?: Date;
  lineItems: LineItem[];
  totals: { subtotal: number; net: number; vat: number; gross: number };
  discount: number | '';
  mtdDetails: MtdDetails;
  onSaveDraft: () => void;
  onApprove: () => void;
  isEditing: boolean;
  onUpdate: () => void;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{isEditing ? 'Review Changes' : 'Create New Invoice (Step 4 of 4)'}</CardTitle>
        <CardDescription>
          Review and {isEditing ? 'save changes to the' : 'send the'} invoice to {client.name}.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6">
          <div className="grid grid-cols-1 gap-4 rounded-lg border p-4 sm:grid-cols-3">
            <div>
              <h3 className="font-semibold">Billed To</h3>
              <p>{client.name}</p>
              <p>{client.address}</p>
              <p>{client.zipcode}</p>
            </div>
            <div>
              <h3 className="font-semibold">Invoice Details</h3>
              <p>
                <span className="text-muted-foreground">Invoice #:</span>{' '}
                {invoiceNumber}
              </p>
              <p>
                <span className="text-muted-foreground">Invoice Date:</span>{' '}
                {invoiceDate ? format(invoiceDate, 'PPP') : 'N/A'}
              </p>
              <p>
                <span className="text-muted-foreground">Due Date:</span>{' '}
                {dueDate ? format(dueDate, 'PPP') : 'N/A'}
              </p>
            </div>
             <div>
                <h3 className="font-semibold">MTD Details (Internal)</h3>
                 <p>
                    <span className="text-muted-foreground">Income Source:</span>{' '}
                    {mtdDetails.incomeSource}
                </p>
                <div>
                    <span className="text-muted-foreground">Include in MTD:</span>{' '}
                    <Badge variant={mtdDetails.includeInMtd ? 'default' : 'outline'} className={cn(mtdDetails.includeInMtd && 'bg-green-500')}>{mtdDetails.includeInMtd ? 'Yes' : 'No'}</Badge>
                </div>
                 <div>
                    <span className="text-muted-foreground">Pay by Yapily:</span>{' '}
                    <Badge variant={mtdDetails.allowYapilyPayment ? 'default' : 'outline'} className={cn(mtdDetails.allowYapilyPayment && 'bg-green-500')}>{mtdDetails.allowYapilyPayment ? 'Yes' : 'No'}</Badge>
                </div>
            </div>
          </div>
          <div>
            <h3 className="mb-2 font-semibold">Invoice Items</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50%] border-r">Description</TableHead>
                  <TableHead className="text-center border-r">Qty</TableHead>
                  <TableHead className="text-right border-r">Unit Price</TableHead>
                  <TableHead className="text-right border-r">VAT</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lineItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="border-r">{item.description}</TableCell>
                    <TableCell className="text-center border-r">
                      {item.quantity}
                    </TableCell>
                    <TableCell className="text-right font-mono border-r">
                      £{item.unitPrice.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right border-r">
                      {item.vatRate}%
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      £
                      {(
                        (item.quantity * item.unitPrice) *
                        (1 + parseFloat(item.vatRate) / 100)
                      ).toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex justify-end">
            <div className="grid w-full max-w-sm gap-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal:</span>
                <span className="font-mono">£{totals.subtotal.toFixed(2)}</span>
              </div>
               <div className="flex justify-between">
                <span className="text-muted-foreground">Discount:</span>
                <span className="font-mono text-destructive">- £{(typeof discount === 'string' ? 0 : discount).toFixed(2)}</span>
              </div>
               <div className="flex justify-between font-bold border-t pt-2">
                <span>Net Total:</span>
                <span className="font-mono">£{totals.net.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">VAT Total:</span>
                <span className="font-mono">£{totals.vat.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold border-t pt-2">
                <span>Gross Total:</span>
                <span className="font-mono">£{totals.gross.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
       <CardFooter className="flex justify-end gap-2">
        {isEditing ? (
            <Button onClick={onUpdate}>
                <Save className="mr-2" />
                Save Changes
            </Button>
        ) : (
            <>
                <Button variant="outline" onClick={onSaveDraft}>
                <Save className="mr-2" />
                Save as Draft
                </Button>
                <Button onClick={onApprove}>
                <Send className="mr-2" />
                Approve
                </Button>
            </>
        )}
      </CardFooter>
    </Card>
  );
}

function CreateInvoicePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editInvoiceId = searchParams.get('edit');

  const [step, setStep] = useState(1);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [invoiceDate, setInvoiceDate] = useState<Date | undefined>(new Date());
  const [dueDate, setDueDate] = useState<Date | undefined>();
  const [lineItems, setLineItems] = useState<LineItem[]>([]);
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const { toast } = useToast();
  const [incomeSources, setIncomeSources] = useState<IncomeSource[]>([]);
  const [mtdDetails, setMtdDetails] = useState<MtdDetails>({
    includeInMtd: true,
    incomeSource: '',
    allowYapilyPayment: true,
  });
  const [discount, setDiscount] = useState<number | ''>(0);
  const [enableSendInvoiceScreen, setEnableSendInvoiceScreen] = useState(true);

  const isEditing = !!editInvoiceId;


  const resetForm = useCallback(() => {
    setStep(1);
    setSelectedClient(null);
    setInvoiceDate(new Date());
    setDueDate(undefined);
    setLineItems([]);
    setInvoiceNumber('');
    setDiscount(0);
    setMtdDetails({ includeInMtd: true, incomeSource: incomeSources.length > 0 ? incomeSources[0].name : '', allowYapilyPayment: true });
    router.replace('/dashboard/invoices/create');
  }, [incomeSources, router]);

  useEffect(() => {
    if (isEditing) {
        const allInvoices = JSON.parse(localStorage.getItem('invoices') || '[]') as Invoice[];
        const invoiceToEdit = allInvoices.find(inv => inv.id === editInvoiceId);
        if (invoiceToEdit) {
            setSelectedClient(invoiceToEdit.client);
            setInvoiceNumber(invoiceToEdit.invoiceNumber);
            setInvoiceDate(new Date(invoiceToEdit.date));
            setDueDate(invoiceToEdit.dueDate ? new Date(invoiceToEdit.dueDate) : undefined);
            setLineItems(invoiceToEdit.lineItems.map(item => ({...item, id: typeof item.id === 'string' ? parseInt(item.id, 10) : item.id})));
            setDiscount(invoiceToEdit.discount);
            setMtdDetails(invoiceToEdit.mtdDetails);
            setStep(2); // Start at step 2 for editing
        } else {
            toast({ variant: 'destructive', title: 'Invoice not found' });
            router.push('/dashboard/invoices');
        }
    }
  }, [editInvoiceId, router, toast]);

  useEffect(() => {
    const sendScreenSetting = localStorage.getItem('enableSendInvoiceScreen');
    if (sendScreenSetting !== null) {
        setEnableSendInvoiceScreen(JSON.parse(sendScreenSetting));
    }
  }, []);

  useEffect(() => {
    const storedSources = localStorage.getItem('incomeSources');
    if (storedSources) {
        const sources = JSON.parse(storedSources);
        setIncomeSources(sources);
        if (sources.length > 0 && !mtdDetails.incomeSource) {
            setMtdDetails(prev => ({...prev, incomeSource: sources[0].name}));
        }
    } else {
        setIncomeSources(initialIncomeSources);
        if (initialIncomeSources.length > 0 && !mtdDetails.incomeSource) {
            setMtdDetails(prev => ({...prev, incomeSource: initialIncomeSources[0].name}));
        }
    }
  }, [mtdDetails.incomeSource]);

  useEffect(() => {
    if (selectedClient && !invoiceNumber && !isEditing) {
        const existingInvoices = JSON.parse(localStorage.getItem('invoices') || '[]') as Invoice[];
        const clientInvoices = existingInvoices.filter(inv => inv.client.id === selectedClient.id);
        const nextInvoiceNum = (clientInvoices.length || 0) + (selectedClient.unpaidInvoices?.length || 0) + 1;
        const paddedInvoiceNum = String(nextInvoiceNum).padStart(3, '0');
        setInvoiceNumber(`${selectedClient.referenceNo}-${paddedInvoiceNum}`);
    }
  }, [selectedClient, invoiceNumber, isEditing]);

  useEffect(() => {
    if (step === 3 && lineItems.length === 0) {
       setLineItems([{ 
           id: Date.now(), 
           description: '', 
           quantity: 1, 
           unitPrice: 0,
           vatRate: '20', 
        }]);
    }
  }, [step, lineItems.length, incomeSources]);


  const handleClientSelect = (client: Client) => {
    setSelectedClient(client);
  };
  
  const goToNextStep = () => setStep(prev => Math.min(prev + 1, 4));
  const goToPrevStep = () => {
      if (isEditing) {
          router.push('/dashboard/invoices');
      } else {
          setStep(prev => Math.max(prev - 1, 1))
      }
  };

  const isStep2Valid = invoiceDate && dueDate;
  const isStep3Valid = lineItems.length > 0 && lineItems.every(item => item.description && item.quantity > 0 && item.unitPrice >= 0);
  
  const calculateTotals = useCallback(() => {
    let subtotal = 0;
    let vat = 0;

    lineItems.forEach((item) => {
      const itemTotal = item.quantity * item.unitPrice;
      const vatRate = parseFloat(item.vatRate);
      const itemVat = isNaN(vatRate) ? 0 : itemTotal * (vatRate / 100);
      subtotal += itemTotal;
      vat += itemVat;
    });

    const numDiscount = typeof discount === 'string' ? 0 : discount;
    const net = subtotal - numDiscount;
    const gross = net + vat;
    return { subtotal, net, vat, gross };
  }, [lineItems, discount]);
  
  const saveInvoice = (status: Invoice['status']): string => {
    if (!selectedClient || !invoiceDate) throw new Error("Client and invoice date are required.");
    
    const numDiscount = typeof discount === 'string' ? 0 : discount;
    const invoiceId = isEditing && editInvoiceId ? editInvoiceId : Date.now().toString();
    const totals = calculateTotals();
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      client: selectedClient,
      date: format(invoiceDate, 'yyyy-MM-dd'),
      dueDate: dueDate ? format(dueDate, 'yyyy-MM-dd') : '',
      lineItems: lineItems.map(li => ({ ...li, vatRate: li.vatRate.toString() })),
      discount: numDiscount,
      totals: {
          net: totals.net,
          vat: totals.vat,
          gross: totals.gross,
      },
      status: status,
      mtdDetails: mtdDetails
    };

    const existingInvoices = JSON.parse(localStorage.getItem('invoices') || '[]') as Invoice[];
    
    let updatedInvoices;
    if (isEditing) {
        updatedInvoices = existingInvoices.map(inv => inv.id === editInvoiceId ? newInvoice : inv);
    } else {
        updatedInvoices = [...existingInvoices, newInvoice];
    }
    localStorage.setItem('invoices', JSON.stringify(updatedInvoices));

    // This logic might need to be more sophisticated for edits
    if (!isEditing) {
        const existingVatUnsubmitted = JSON.parse(localStorage.getItem('vat_unsubmitted_invoices') || '[]') as VatTransaction[];
        const newVatTransaction: VatTransaction = {
        id: `inv-${invoiceId}`,
        transactionType: 'Sale',
        customer: selectedClient.name,
        date: newInvoice.date,
        nominalCode: 'Sales', 
        dept: '',
        details: `Invoice ${invoiceNumber}`,
        documentReference: invoiceNumber,
        additionalReference: selectedClient.referenceNo,
        netAmount: newInvoice.totals.net,
        vatAmount: newInvoice.totals.vat,
        vatPercentage: lineItems[0]?.vatRate || '20', 
        subjectToCIS: 'N',
        includeInMtd: true,
        };
        localStorage.setItem('vat_unsubmitted_invoices', JSON.stringify([...existingVatUnsubmitted, newVatTransaction]));


        if (mtdDetails.includeInMtd) {
            const existingBankTransactions = JSON.parse(localStorage.getItem('bankTransactions') || '[]') as BankTransaction[];
            const newBankTransaction: BankTransaction = {
                id: `inv-bt-${invoiceId}`,
                bankId: '', 
                date: newInvoice.date,
                description: `Invoice ${invoiceNumber} to ${selectedClient.name}`,
                debit: null,
                credit: newInvoice.totals.gross,
                balance: 0, 
                additionalDescription: 'Sales Invoice',
                nominalCode: 'Sales',
                incomeSource: mtdDetails.incomeSource,
                includeInMtd: true,
                isApproved: true,
            };
            localStorage.setItem('bankTransactions', JSON.stringify([...existingBankTransactions, newBankTransaction]));
        }
    }


    return invoiceId;
  };

  const handleUpdate = () => {
      try {
        saveInvoice('Draft'); // Or original status if you store it
        toast({
            title: "Invoice Updated",
            description: `Invoice ${invoiceNumber} has been updated.`,
        });
        resetForm();
        router.push('/dashboard/invoices');
    } catch(e) {
       toast({
          variant: "destructive",
          title: "Error updating invoice",
          description: e instanceof Error ? e.message : "An unknown error occurred",
      });
    }
  }


  const handleSaveDraft = () => {
    try {
      saveInvoice('Draft');
      toast({
          title: "Draft Saved",
          description: `Invoice ${invoiceNumber} has been saved as a draft.`,
      });
      resetForm();
      router.push('/dashboard/invoices');
    } catch(e) {
       toast({
          variant: "destructive",
          title: "Error saving draft",
          description: e instanceof Error ? e.message : "An unknown error occurred",
      });
    }
  }
  
  const handleApprove = () => {
    try {
      const invoiceId = saveInvoice('Draft');
      
      if (enableSendInvoiceScreen) {
        toast({
            title: "Invoice Approved",
            description: `Invoice ${invoiceNumber} has been saved. Now, let's send it.`,
        });
        router.push(`/dashboard/invoices/send/${invoiceId}`);
      } else {
        toast({
            title: "Invoice Approved & Saved",
            description: `Invoice ${invoiceNumber} has been saved.`,
        });
        router.push('/dashboard/invoices');
      }

    } catch (e) {
      toast({
          variant: "destructive",
          title: "Error approving invoice",
          description: e instanceof Error ? e.message : "An unknown error occurred",
      });
    }
  }


  return (
    <div className="space-y-6">

        {step === 1 && !isEditing && <ClientSelectionStep onClientSelect={handleClientSelect} goToNextStep={goToNextStep} toast={toast} />}
        
        {step === 2 && selectedClient && (
            <InvoiceDetailsStep 
                client={selectedClient} 
                invoiceNumber={invoiceNumber}
                setInvoiceNumber={setInvoiceNumber}
                invoiceDate={invoiceDate}
                setInvoiceDate={setInvoiceDate}
                dueDate={dueDate}
                setDueDate={setDueDate}
                isEditing={isEditing}
            />
        )}

        {step === 3 && selectedClient && (
            <LineItemsStep 
                client={selectedClient} 
                invoiceNumber={invoiceNumber} 
                lineItems={lineItems} 
                setLineItems={setLineItems}
                mtdDetails={mtdDetails}
                setMtdDetails={setMtdDetails}
                discount={discount}
                setDiscount={setDiscount}
                isEditing={isEditing}
            />
        )}
        
        {step === 4 && selectedClient && (
          <ReviewStep
            client={selectedClient}
            invoiceNumber={invoiceNumber}
            invoiceDate={invoiceDate}
            dueDate={dueDate}
            lineItems={lineItems}
            totals={calculateTotals()}
            discount={discount}
            mtdDetails={mtdDetails}
            onSaveDraft={handleSaveDraft}
            onApprove={handleApprove}
            isEditing={isEditing}
            onUpdate={handleUpdate}
          />
        )}


        <div className="flex justify-between">
            {step > 1 && (
                <Button variant="outline" onClick={goToPrevStep}>
                    <ArrowLeft className="mr-2" />
                    Back
                </Button>
            )}
            {step < 4 && (
                <Button 
                    onClick={goToNextStep} 
                    className="ml-auto"
                    disabled={
                        (step === 1 && !selectedClient && !isEditing) ||
                        (step === 2 && !isStep2Valid) ||
                        (step === 3 && !isStep3Valid)
                    }
                >
                    {step === 1 && !isEditing && 'Next: Add Details'}
                    {step === 2 && 'Next: Add Line Items'}
                    {step === 3 && 'Next: Review Invoice'}
                    <ArrowRight className="ml-2" />
                </Button>
            )}
        </div>
    </div>
  );
}


const CreateInvoicePageBrowser = dynamic(() => Promise.resolve(CreateInvoicePage), { ssr: false });

export default CreateInvoicePageBrowser;
