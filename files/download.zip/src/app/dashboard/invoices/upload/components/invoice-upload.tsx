"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { handleParseInvoice } from '@/app/actions/invoice';
import type { ParseUploadedInvoiceOutput } from '@/ai/flows/parse-uploaded-invoices';
import { Loader2, Upload } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export function InvoiceUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ParseUploadedInvoiceOutput | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setFile(event.target.files[0]);
    }
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!file) {
      toast({
        variant: 'destructive',
        title: 'No file selected',
        description: 'Please select an invoice file to upload.',
      });
      return;
    }

    setIsLoading(true);

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const dataUri = reader.result as string;
      try {
        const parsedData = await handleParseInvoice(dataUri);
        setResult(parsedData);
        setIsDialogOpen(true);
      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Error parsing invoice',
          description: error instanceof Error ? error.message : 'An unknown error occurred.',
        });
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = (error) => {
        toast({
          variant: 'destructive',
          title: 'Error reading file',
          description: 'Could not read the selected file.',
        });
        setIsLoading(false);
    };
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input type="file" onChange={handleFileChange} accept="application/pdf,image/*" />
        <Button type="submit" disabled={isLoading || !file} className="w-full">
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Upload className="mr-2 h-4 w-4" />
          )}
          Parse Invoice
        </Button>
      </form>

      {result && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Invoice Details Extracted</DialogTitle>
              <DialogDescription>
                AI has extracted the following details from your invoice.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                    <div><strong>Customer:</strong> {result.customer}</div>
                    <div><strong>Invoice #:</strong> {result.invoiceNumber}</div>
                    <div><strong>Date:</strong> {result.date}</div>
                    <div><strong>Due Date:</strong> {result.dueDate}</div>
                </div>

              <h4 className="mt-4 font-semibold">Line Items</h4>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Unit Price</TableHead>
                    <TableHead className="text-right">Discount</TableHead>
                    <TableHead className="text-right">VAT Rate</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {result.lineItems.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{item.description}</TableCell>
                      <TableCell className="text-right">{item.quantity}</TableCell>
                      <TableCell className="text-right">{item.unitPrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{item.discount.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{item.vatRate}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="grid grid-cols-3 gap-4 mt-4 text-right font-medium">
                  <div></div>
                  <div>Net Total:</div>
                  <div>{result.totals.net.toFixed(2)}</div>
                  <div></div>
                  <div>VAT Total:</div>
                  <div>{result.totals.vat.toFixed(2)}</div>
                  <div></div>
                  <div>Gross Total:</div>
                  <div>{result.totals.gross.toFixed(2)}</div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
