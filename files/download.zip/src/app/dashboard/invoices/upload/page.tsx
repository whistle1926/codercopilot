import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { InvoiceUpload } from "./components/invoice-upload";

export default function InvoiceUploadPage() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Parse Invoice</CardTitle>
          <CardDescription>Upload an invoice to automatically extract its details using AI.</CardDescription>
        </CardHeader>
        <CardContent>
          <InvoiceUpload />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Recent Invoices</CardTitle>
          <CardDescription>View and manage your recent invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex h-48 items-center justify-center rounded-lg border-2 border-dashed">
            <p className="text-muted-foreground">Recent invoices list coming soon.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
