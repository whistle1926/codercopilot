
"use client";

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import type { Client, Invoice, LineItem, MtdDetails } from '@/lib/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, ArrowRight, Check, ChevronsUpDown, Save, Search, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import { format } from 'date-fns';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

function SelectInvoiceStep({ onSelect, goToNextStep }: { onSelect: (invoice: Invoice) => void, goToNextStep: () => void }) {
    const [invoices, setInvoices] = useState<Invoice[]>([]);
    const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
    const [open, setOpen] = useState(false);

    useEffect(() => {
        const storedInvoices: Invoice[] = JSON.parse(localStorage.getItem('invoices') || '[]');
        // Filter for invoices that can be credited
        const creditableInvoices = storedInvoices.filter(inv => 
            inv.status === 'Sent' || inv.status === 'Paid' || inv.status === 'Overdue'
        );
        setInvoices(creditableInvoices);
    }, []);

    const handleSelect = (invoiceId: string) => {
        const invoice = invoices.find(inv => inv.id === invoiceId);
        if (invoice) {
            setSelectedInvoiceId(invoiceId);
            onSelect(invoice);
            setOpen(false);
        }
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Create Credit Note (Step 1 of 3)</CardTitle>
                <CardDescription>Select the invoice you want to create a credit note for.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                 <Popover open={open} onOpenChange={setOpen}>
                    <PopoverTrigger asChild>
                        <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={open}
                        className="w-full justify-between"
                        >
                        {selectedInvoiceId
                            ? invoices.find((inv) => inv.id === selectedInvoiceId)?.invoiceNumber
                            : "Select invoice..."}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                        <Command>
                        <CommandInput placeholder="Search by Invoice # or Client..." />
                        <CommandEmpty>No invoice found.</CommandEmpty>
                        <CommandGroup>
                            {invoices.map((invoice) => (
                            <CommandItem
                                key={invoice.id}
                                value={`${invoice.invoiceNumber} ${invoice.client.name}`}
                                onSelect={() => handleSelect(invoice.id)}
                            >
                                <Check
                                    className={cn(
                                    "mr-2 h-4 w-4",
                                    selectedInvoiceId === invoice.id ? "opacity-100" : "opacity-0"
                                    )}
                                />
                                <div>
                                    <span className="font-medium">{invoice.invoiceNumber}</span> - <span className="text-muted-foreground">{invoice.client.name}</span>
                                    <span className="ml-4 font-mono">£{invoice.totals.gross.toFixed(2)}</span>
                                </div>
                            </CommandItem>
                            ))}
                        </CommandGroup>
                        </Command>
                    </PopoverContent>
                </Popover>

            </CardContent>
             <CardFooter>
                <Button onClick={goToNextStep} disabled={!selectedInvoiceId}>
                    Next: Edit Credit Note <ArrowRight className="ml-2 h-4 w-4"/>
                </Button>
            </CardFooter>
        </Card>
    );
}

function EditCreditNoteStep({ originalInvoice, lineItems, setLineItems }: { originalInvoice: Invoice, lineItems: LineItem[], setLineItems: React.Dispatch<React.SetStateAction<LineItem[]>> }) {
    
    const updateLineItem = (id: number, field: keyof Omit<LineItem, 'id'>, value: string | number) => {
        setLineItems(lineItems.map(item => item.id === id ? { ...item, [field]: value } : item));
    };

    const removeLineItem = (id: number) => {
        setLineItems(lineItems.filter(item => item.id !== id));
    };

    const calculateTotals = useMemo(() => {
        let subtotal = 0;
        let vat = 0;
        
        lineItems.forEach(item => {
            const itemTotal = item.quantity * item.unitPrice;
            const itemVat = itemTotal * (parseFloat(item.vatRate) / 100);
            subtotal += itemTotal;
            vat += isNaN(itemVat) ? 0 : itemVat;
        });

        const gross = subtotal + vat;
        return { subtotal, vat, gross };
    }, [lineItems]);
    
    return (
        <Card>
            <CardHeader>
                 <CardTitle>Create Credit Note (Step 2 of 3)</CardTitle>
                <CardDescription>Adjust quantities or prices for the credit note against Invoice <span className="font-medium text-foreground">{originalInvoice.invoiceNumber}</span>.</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[50%] border-r">Description</TableHead>
                            <TableHead className="border-r">Qty</TableHead>
                            <TableHead className="border-r">Unit Price</TableHead>
                            <TableHead className="border-r">VAT</TableHead>
                            <TableHead className="text-right border-r">Total</TableHead>
                            <TableHead></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {lineItems.map((item) => (
                            <TableRow key={item.id}>
                                <TableCell className="border-r">
                                    <Input 
                                        type="text" 
                                        value={item.description} 
                                        onChange={(e) => updateLineItem(item.id, 'description', e.target.value)} 
                                        readOnly
                                    />
                                </TableCell>
                                <TableCell className="border-r">
                                    <Input 
                                        type="number" 
                                        value={item.quantity} 
                                        max={originalInvoice.lineItems.find(li => li.id === item.id)?.quantity || 0}
                                        onChange={(e) => updateLineItem(item.id, 'quantity', parseInt(e.target.value, 10) || 0)} 
                                        className="w-20"
                                    />
                                </TableCell>
                                <TableCell className="border-r">
                                     <div className="relative">
                                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">£</span>
                                        <Input 
                                            type="number" 
                                            value={item.unitPrice} 
                                            onChange={(e) => updateLineItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                                            className="w-28 pl-6"
                                        />
                                    </div>
                                </TableCell>
                                <TableCell className="border-r">
                                    <Select value={item.vatRate} onValueChange={(value) => updateLineItem(item.id, 'vatRate', value)}>
                                        <SelectTrigger className="w-24">
                                            <SelectValue placeholder="VAT Rate" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="20">20%</SelectItem>
                                            <SelectItem value="5">5%</SelectItem>
                                            <SelectItem value="0">0%</SelectItem>
                                            <SelectItem value="exempt">Exempt</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </TableCell>
                                <TableCell className="text-right font-mono border-r">
                                    £{((item.quantity * item.unitPrice) * (1 + parseFloat(item.vatRate)/100) || 0).toFixed(2)}
                                </TableCell>
                                <TableCell>
                                    <Button variant="ghost" size="icon" onClick={() => removeLineItem(item.id)}>
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
             <CardFooter className="flex justify-end bg-muted/50 p-4 rounded-b-lg">
                <div className="grid w-full max-w-sm gap-2">
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">Net Credit:</span>
                        <span className="font-mono">£{calculateTotals.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">VAT Credit:</span>
                        <span className="font-mono">£{calculateTotals.vat.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold border-t pt-2">
                        <span>Gross Credit Total:</span>
                        <span className="font-mono">£{calculateTotals.gross.toFixed(2)}</span>
                    </div>
                </div>
            </CardFooter>
        </Card>
    );
}

function ReviewCreditNoteStep({ originalInvoice, creditNote, onSave }: { originalInvoice: Invoice, creditNote: Omit<Invoice, 'id' | 'status' | 'invoiceNumber'>, onSave: () => void }) {

     return (
        <Card>
            <CardHeader>
                <CardTitle>Create Credit Note (Step 3 of 3)</CardTitle>
                <CardDescription>Review the credit note details before saving.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="grid grid-cols-1 gap-4 rounded-lg border p-4 sm:grid-cols-2">
                     <div>
                        <h3 className="font-semibold">Credit For</h3>
                        <p>{creditNote.client.name}</p>
                        <p>{creditNote.client.address}</p>
                        <p>{creditNote.client.zipcode}</p>
                    </div>
                    <div>
                        <h3 className="font-semibold">Details</h3>
                        <p><span className="text-muted-foreground">Credit Note Date:</span> {format(new Date(creditNote.date), 'PPP')}</p>
                        <p><span className="text-muted-foreground">Original Invoice:</span> {originalInvoice.invoiceNumber}</p>
                    </div>
                </div>

                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[50%] border-r">Description</TableHead>
                            <TableHead className="text-center border-r">Qty</TableHead>
                            <TableHead className="text-right border-r">Unit Price</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {creditNote.lineItems.map((item) => (
                        <TableRow key={item.id}>
                            <TableCell className="border-r">{item.description}</TableCell>
                            <TableCell className="text-center border-r">{item.quantity}</TableCell>
                            <TableCell className="text-right font-mono border-r">£{item.unitPrice.toFixed(2)}</TableCell>
                            <TableCell className="text-right font-mono">£{(item.quantity * item.unitPrice).toFixed(2)}</TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                </Table>
                
                 <div className="flex justify-end">
                    <div className="grid w-full max-w-sm gap-2">
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">Net Credit:</span>
                        <span className="font-mono">£{creditNote.totals.net.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-muted-foreground">VAT Credit:</span>
                        <span className="font-mono">£{creditNote.totals.vat.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-lg">
                        <span>Gross Credit Total:</span>
                        <span className="font-mono">£{creditNote.totals.gross.toFixed(2)}</span>
                    </div>
                    </div>
                </div>

            </CardContent>
            <CardFooter className="flex justify-end gap-2">
                <Button variant="outline" onClick={onSave}>
                    <Save className="mr-2" />
                    Save Credit Note
                </Button>
            </CardFooter>
        </Card>
    );
}

export default function CreditNotePage() {
    const router = useRouter();
    const { toast } = useToast();
    const [step, setStep] = useState(1);
    const [originalInvoice, setOriginalInvoice] = useState<Invoice | null>(null);
    const [lineItems, setLineItems] = useState<LineItem[]>([]);

    const handleInvoiceSelect = (invoice: Invoice) => {
        setOriginalInvoice(invoice);
        // Deep copy line items to prevent mutation of original invoice data
        setLineItems(JSON.parse(JSON.stringify(invoice.lineItems)));
    };

    const goToNextStep = () => setStep(prev => Math.min(prev + 1, 3));
    const goToPrevStep = () => setStep(prev => Math.max(prev - 1, 1));
    
    const isStep2Valid = lineItems.length > 0 && lineItems.some(item => item.quantity > 0 && item.unitPrice >= 0);

    const calculateTotals = useCallback(() => {
        let subtotal = 0;
        let vat = 0;
        lineItems.forEach(item => {
            const itemTotal = item.quantity * item.unitPrice;
            const itemVat = itemTotal * (parseFloat(item.vatRate) / 100);
            subtotal += itemTotal;
            vat += isNaN(itemVat) ? 0 : itemVat;
        });
        const gross = subtotal + vat;
        return { net: subtotal, vat, gross };
    }, [lineItems]);


    const handleSaveCreditNote = () => {
        if (!originalInvoice) return;
        
        try {
            const existingInvoices: Invoice[] = JSON.parse(localStorage.getItem('invoices') || '[]');
            
            const creditNoteNumber = `CN-${originalInvoice.invoiceNumber}`;
            const totals = calculateTotals();

            const newCreditNote: Invoice = {
                id: Date.now().toString(),
                invoiceNumber: creditNoteNumber,
                client: originalInvoice.client,
                date: format(new Date(), 'yyyy-MM-dd'),
                dueDate: '', // Not applicable for credit note
                lineItems: lineItems,
                discount: 0,
                totals: {
                    net: totals.net,
                    vat: totals.vat,
                    gross: totals.gross,
                },
                status: 'Credit Note',
                mtdDetails: originalInvoice.mtdDetails,
                creditNoteFor: originalInvoice.invoiceNumber,
            };

            localStorage.setItem('invoices', JSON.stringify([...existingInvoices, newCreditNote]));

            toast({
                title: "Credit Note Saved",
                description: `Credit Note ${creditNoteNumber} has been created.`,
            });
            router.push('/dashboard/invoices');

        } catch (e) {
            toast({
                variant: "destructive",
                title: "Error saving credit note",
                description: e instanceof Error ? e.message : "An unknown error occurred",
            });
        }
    };


    const getCreditNoteForReview = () => {
        if (!originalInvoice) return null;
        const totals = calculateTotals();
        return {
            client: originalInvoice.client,
            date: format(new Date(), 'yyyy-MM-dd'),
            dueDate: '',
            lineItems,
            discount: 0,
            totals: {
                net: totals.net,
                vat: totals.vat,
                gross: totals.gross,
            },
            mtdDetails: originalInvoice.mtdDetails,
        };
    }

    return (
        <div className="space-y-6">
            {step === 1 && <SelectInvoiceStep onSelect={handleInvoiceSelect} goToNextStep={goToNextStep} />}
            {step === 2 && originalInvoice && <EditCreditNoteStep originalInvoice={originalInvoice} lineItems={lineItems} setLineItems={setLineItems} />}
            {step === 3 && originalInvoice && (
                <ReviewCreditNoteStep 
                    originalInvoice={originalInvoice}
                    creditNote={getCreditNoteForReview()!}
                    onSave={handleSaveCreditNote}
                />
            )}

             <div className="flex justify-between">
                {step > 1 && (
                    <Button variant="outline" onClick={goToPrevStep}>
                        <ArrowLeft className="mr-2" />
                        Back
                    </Button>
                )}
                {step < 3 && (
                    <Button 
                        onClick={goToNextStep} 
                        className="ml-auto"
                        disabled={
                            (step === 1 && !originalInvoice) ||
                            (step === 2 && !isStep2Valid)
                        }
                    >
                        Next: Review Credit Note
                        <ArrowRight className="ml-2" />
                    </Button>
                )}
            </div>
        </div>
    )
}
