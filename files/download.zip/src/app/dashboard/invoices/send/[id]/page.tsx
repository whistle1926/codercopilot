

'use client';

import { useEffect, useState } from 'react';
import { notFound, useRouter, useParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import type { Invoice } from '@/lib/types';
import { Paperclip, Send, Loader2, ArrowLeft, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { CoderCoPilotLogo } from '@/components/icons';
import { format } from 'date-fns';

export default function SendInvoicePage() {
  const router = useRouter();
  const params = useParams();
  const { toast } = useToast();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [emailBody, setEmailBody] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  
  useEffect(() => {
    const invoiceId = Array.isArray(params.id) ? params.id[0] : params.id;
    const allInvoices: Invoice[] = JSON.parse(localStorage.getItem('invoices') || '[]');
    const currentInvoice = allInvoices.find(inv => inv.id === invoiceId);
    if (currentInvoice) {
      setInvoice(currentInvoice);
      // Generate a default email body
      setEmailBody(`Dear ${currentInvoice.client.mainContactPerson || currentInvoice.client.name},

Please find attached your invoice ${currentInvoice.invoiceNumber} for £${currentInvoice.totals.gross.toFixed(2)}.

The due date for this invoice is ${currentInvoice.dueDate ? new Date(currentInvoice.dueDate).toLocaleDateString() : 'N/A'}.

Thank you for your business.

Best regards,
Your Company`);
    } else {
      notFound();
    }
  }, [params.id]);

  const handleSendInvoice = () => {
    setIsLoading(true);
    // Simulate sending email
    setTimeout(() => {
      // Update invoice status to 'Sent'
      const invoiceId = Array.isArray(params.id) ? params.id[0] : params.id;
      const allInvoices: Invoice[] = JSON.parse(localStorage.getItem('invoices') || '[]');
      const updatedInvoices = allInvoices.map(inv => 
        inv.id === invoiceId ? { ...inv, status: 'Sent' as const } : inv
      );
      localStorage.setItem('invoices', JSON.stringify(updatedInvoices));
      
      toast({
        title: 'Invoice Sent!',
        description: `Invoice ${invoice?.invoiceNumber} has been sent to ${invoice?.client.name}.`,
      });
      
      setIsLoading(false);
      router.push('/dashboard/invoices');
    }, 1500);
  };
  
  if (!invoice) {
    return <div>Loading invoice...</div>;
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Send Invoice: {invoice.invoiceNumber}</CardTitle>
          <CardDescription>Prepare and send the invoice to {invoice.client.name}.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="recipient">Recipient Email</Label>
              <Input id="recipient" value={invoice.client.email} readOnly />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subject">Subject</Label>
              <Input id="subject" defaultValue={`Invoice ${invoice.invoiceNumber} from Your Company`} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="emailBody">Email Body</Label>
            <Textarea 
              id="emailBody"
              value={emailBody}
              onChange={(e) => setEmailBody(e.target.value)}
              rows={10}
              className="min-h-[200px]"
            />
          </div>
          <div>
            <Label>Attachment</Label>
            <div className="mt-2 flex items-center gap-2 rounded-md border p-3 bg-muted/50">
              <Paperclip className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm font-medium">{`Invoice-${invoice.invoiceNumber}.pdf`}</span>
              <span className="text-sm text-muted-foreground">(123 KB)</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsPreviewOpen(true)}>
              <Eye className="mr-2 h-4 w-4" />
              Preview
            </Button>
            <Button onClick={handleSendInvoice} disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Send className="mr-2 h-4 w-4" />
              )}
              Finalize and Send Invoice
            </Button>
          </div>
        </CardFooter>
      </Card>
      
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-4xl p-0">
             <DialogHeader className="p-8 pb-0">
                <DialogTitle>Invoice Preview</DialogTitle>
                <DialogDescription>
                    This is a preview of the invoice that will be sent to your client.
                </DialogDescription>
            </DialogHeader>
            <div className="p-8">
                <div className="grid grid-cols-2 items-start gap-8">
                    <div>
                        <CoderCoPilotLogo className="h-10 w-10 text-primary mb-4" />
                        <h2 className="text-lg font-semibold">Your Company Name</h2>
                        <p className="text-sm text-muted-foreground">123 Your Street, Your Town, YR1 2CD</p>
                    </div>
                    <div className="text-right">
                        <h1 className="text-2xl font-bold">INVOICE</h1>
                        <p className="text-muted-foreground"># {invoice.invoiceNumber}</p>
                    </div>
                </div>
                <Separator className="my-6" />
                <div className="grid grid-cols-2 gap-8">
                    <div>
                        <p className="font-semibold text-muted-foreground">BILL TO</p>
                        <p className="font-bold">{invoice.client.name}</p>
                        <p>{invoice.client.address}</p>
                        <p>{invoice.client.zipcode}</p>
                    </div>
                    <div className="text-right space-y-1">
                        <p><span className="font-semibold text-muted-foreground">Invoice Date: </span>{format(new Date(invoice.date), 'dd MMM yyyy')}</p>
                        <p><span className="font-semibold text-muted-foreground">Due Date: </span>{invoice.dueDate ? format(new Date(invoice.dueDate), 'dd MMM yyyy') : 'N/A'}</p>
                    </div>
                </div>

                 <div className="mt-8">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[50%]">Description</TableHead>
                                <TableHead className="text-center">Qty</TableHead>
                                <TableHead className="text-right">Unit Price</TableHead>
                                <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {invoice.lineItems.map(item => (
                                <TableRow key={item.id}>
                                    <TableCell className="font-medium">{item.description}</TableCell>
                                    <TableCell className="text-center">{item.quantity}</TableCell>
                                    <TableCell className="text-right font-mono">£{item.unitPrice.toFixed(2)}</TableCell>
                                    <TableCell className="text-right font-mono">£{(item.quantity * item.unitPrice).toFixed(2)}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                
                <div className="mt-6 flex justify-end">
                    <div className="w-full max-w-sm space-y-2">
                        <div className="flex justify-between">
                            <span className="text-muted-foreground">Subtotal</span>
                            <span className="font-mono">£{(invoice.totals.net + invoice.discount).toFixed(2)}</span>
                        </div>
                         {invoice.discount > 0 && (
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Discount</span>
                                <span className="font-mono">- £{invoice.discount.toFixed(2)}</span>
                            </div>
                        )}
                        <div className="flex justify-between">
                            <span className="text-muted-foreground">VAT</span>
                            <span className="font-mono">£{invoice.totals.vat.toFixed(2)}</span>
                        </div>
                        <Separator />
                         <div className="flex justify-between font-bold text-lg">
                            <span>Total</span>
                            <span className="font-mono">£{invoice.totals.gross.toFixed(2)}</span>
                        </div>
                         {invoice.mtdDetails.allowYapilyPayment && (
                            <div className="pt-4">
                                <Button className="w-full">Pay with Yapily</Button>
                            </div>
                        )}
                    </div>
                </div>

            </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
