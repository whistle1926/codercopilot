

"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { FilePlus2, FileText, Upload, MoreHorizontal, Calendar as CalendarIcon, X, Check, ChevronsUpDown, ArrowRight, Filter, Eye, ArrowLeft, Edit2 } from 'lucide-react';
import { useEffect, useState, useMemo } from 'react';
import type { Invoice, Client } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { addDays, format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
    Collapsible,
    CollapsibleContent,
    CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { clients as allClients } from '@/lib/data';
import type { DateRange } from 'react-day-picker';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command"
import { useActiveClient } from '@/hooks/use-active-client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { MTDSimpleLogo } from '@/components/icons';
import { Separator } from '@/components/ui/separator';


function InvoiceFilters({ filters, setFilters, clients, activeClient }: {
  filters: { date: DateRange | undefined; clientId: string; status: string };
  setFilters: React.Dispatch<React.SetStateAction<{ date: DateRange | undefined; clientId: string; status: string }>>;
  clients: Client[];
  activeClient: Client | null;
}) {

  const clearFilters = () => {
    setFilters({ date: undefined, clientId: 'all', status: 'all' });
  };

  const [open, setOpen] = useState(false)
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);
    
  return (
    <Collapsible className="border-b">
        <div className="p-4 flex justify-end">
            <CollapsibleTrigger asChild>
                <Button variant="outline">
                    <Filter className="mr-2 h-4 w-4" />
                    Filter Invoices
                </Button>
            </CollapsibleTrigger>
        </div>
        <CollapsibleContent>
            <div className="flex flex-col sm:flex-row gap-2 items-center p-4 pt-0">
                <div className="flex-1 w-full sm:w-auto">
                    <Popover open={isDatePopoverOpen} onOpenChange={setIsDatePopoverOpen}>
                        <PopoverTrigger asChild>
                        <Button
                            id="date"
                            variant={"outline"}
                            className={cn(
                            "w-full sm:w-[300px] justify-start text-left font-normal",
                            !filters.date && "text-muted-foreground"
                            )}
                        >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {filters.date?.from ? (
                            filters.date.to ? (
                                <>
                                {format(filters.date.from, "LLL dd, y")} -{" "}
                                {format(filters.date.to, "LLL dd, y")}
                                </>
                            ) : (
                                format(filters.date.from, "LLL dd, y")
                            )
                            ) : (
                            <span>Pick a date range</span>
                            )}
                        </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                            initialFocus
                            mode="range"
                            defaultMonth={filters.date?.from}
                            selected={filters.date}
                            onSelect={(date) => setFilters(prev => ({...prev, date}))}
                            numberOfMonths={2}
                        />
                        <div className="p-2 border-t flex justify-end">
                            <Button onClick={() => setIsDatePopoverOpen(false)}>
                                Next <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                        </PopoverContent>
                    </Popover>
                </div>
                {!activeClient && (
                    <div className="flex-1 w-full sm:w-auto">
                        <Popover open={open} onOpenChange={setOpen}>
                            <PopoverTrigger asChild>
                                <Button
                                variant="outline"
                                role="combobox"
                                aria-expanded={open}
                                className="w-full sm:w-[200px] justify-between"
                                >
                                {filters.clientId && filters.clientId !== 'all'
                                    ? clients.find((client) => client.id === filters.clientId)?.name
                                    : "Select client..."}
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[200px] p-0">
                                <Command>
                                <CommandInput placeholder="Search client..." />
                                <CommandEmpty>No client found.</CommandEmpty>
                                <CommandGroup>
                                    <CommandItem
                                        value="all"
                                        onSelect={() => {
                                            setFilters(prev => ({...prev, clientId: 'all'}));
                                            setOpen(false);
                                        }}
                                    >
                                        <Check
                                            className={cn(
                                            "mr-2 h-4 w-4",
                                            filters.clientId === 'all' ? "opacity-100" : "opacity-0"
                                            )}
                                        />
                                        All Clients
                                    </CommandItem>
                                    {clients.map((client) => (
                                    <CommandItem
                                        key={client.id}
                                        value={client.name}
                                        onSelect={(currentValue) => {
                                            const clientId = clients.find(c => c.name.toLowerCase() === currentValue.toLowerCase())?.id || 'all';
                                            setFilters(prev => ({...prev, clientId }));
                                            setOpen(false);
                                        }}
                                    >
                                        <Check
                                            className={cn(
                                            "mr-2 h-4 w-4",
                                            filters.clientId === client.id ? "opacity-100" : "opacity-0"
                                            )}
                                        />
                                        {client.name}
                                    </CommandItem>
                                    ))}
                                </CommandGroup>
                                </Command>
                            </PopoverContent>
                        </Popover>
                    </div>
                )}
                <div className="flex-1 w-full sm:w-auto">
                    <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({...prev, status: value}))}>
                        <SelectTrigger className="w-full sm:w-[180px]">
                            <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Statuses</SelectItem>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Sent">Sent</SelectItem>
                            <SelectItem value="Paid">Paid</SelectItem>
                            <SelectItem value="Overdue">Overdue</SelectItem>
                            <SelectItem value="Credit Note">Credit Note</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <Button variant="ghost" onClick={clearFilters} className="flex-shrink-0">
                    <X className="mr-2" />
                    Reset Filters
                </Button>
            </div>
        </CollapsibleContent>
    </Collapsible>
  );
}


function SentInvoicesList() {
    const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
    const [filteredInvoices, setFilteredInvoices] = useState<Invoice[]>([]);
    const [clients, setClients] = useState<Client[]>([]);
    const [filters, setFilters] = useState<{ date: DateRange | undefined; clientId: string; status: string }>({
        date: undefined,
        clientId: 'all',
        status: 'all',
    });
    const { activeClient } = useActiveClient();
    const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);


    useEffect(() => {
        const storedInvoices = JSON.parse(localStorage.getItem('invoices') || '[]') as Invoice[];
        setAllInvoices(storedInvoices);
        setClients(allClients as Client[]);
    }, []);

    useEffect(() => {
        let invoices = [...allInvoices];
        
        if (activeClient) {
            invoices = invoices.filter(inv => inv.client.id === activeClient.id);
        }

        // Date filter
        if (filters.date?.from) {
            invoices = invoices.filter(inv => {
                const invoiceDate = new Date(inv.date);
                if (filters.date?.to) {
                    return invoiceDate >= filters.date.from! && invoiceDate <= filters.date.to;
                }
                return format(invoiceDate, 'yyyy-MM-dd') === format(filters.date.from!, 'yyyy-MM-dd');
            });
        }

        // Client filter (only if no active client)
        if (!activeClient && filters.clientId !== 'all') {
            invoices = invoices.filter(inv => inv.client.id === filters.clientId);
        }

        // Status filter
        if (filters.status !== 'all') {
            invoices = invoices.filter(inv => inv.status === filters.status);
        }
        
        setFilteredInvoices(invoices.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));

    }, [filters, allInvoices, activeClient]);

    const handleStatusChange = (invoiceId: string, newStatus: Invoice['status']) => {
        const updatedInvoices = allInvoices.map(inv => 
            inv.id === invoiceId ? { ...inv, status: newStatus } : inv
        );
        setAllInvoices(updatedInvoices);
        localStorage.setItem('invoices', JSON.stringify(updatedInvoices));
    }

    const getStatusVariant = (status: Invoice['status']) => {
        switch (status) {
            case 'Sent':
                return 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700';
            case 'Paid':
                return 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/50 dark:text-green-300 dark:border-green-700';
            case 'Overdue':
                return 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/50 dark:text-red-300 dark:border-red-700';
            case 'Draft':
                 return 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600';
            case 'Credit Note':
                return 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700';
            default:
                return 'outline';
        }
    }

    if (allInvoices.length === 0) {
        return (
            <div className="flex h-48 items-center justify-center rounded-lg border-2 border-dashed p-6">
              <p className="text-muted-foreground">
                You haven't sent any invoices yet.
              </p>
            </div>
        )
    }

    return (
        <>
            <InvoiceFilters filters={filters} setFilters={setFilters} clients={clients} activeClient={activeClient} />
            <div className="p-6">
                {filteredInvoices.length === 0 ? (
                     <div className="flex h-48 items-center justify-center text-muted-foreground">
                        <p>No invoices match the current filters.</p>
                    </div>
                ) : (
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="border-r">Invoice #</TableHead>
                                <TableHead className="border-r">Client</TableHead>
                                <TableHead className="border-r">Date</TableHead>
                                <TableHead className="border-r">Due Date</TableHead>
                                <TableHead className="text-right border-r">Net Amount</TableHead>
                                <TableHead className="text-right border-r">VAT Amount</TableHead>
                                <TableHead className="text-right border-r">Gross Amount</TableHead>
                                <TableHead className="border-r">Income Source</TableHead>
                                <TableHead className="border-r">Included in MTD</TableHead>
                                <TableHead className="text-center border-r">Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredInvoices.map(invoice => (
                                <TableRow key={invoice.id}>
                                    <TableCell className="font-medium border-r">{invoice.invoiceNumber}{invoice.creditNoteFor && <span className="text-xs text-muted-foreground block"> (Credit for {invoice.creditNoteFor})</span>}</TableCell>
                                    <TableCell className="border-r">{invoice.client.name}</TableCell>
                                    <TableCell className="border-r">{invoice.dueDate ? format(new Date(invoice.date), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                    <TableCell className="border-r">{invoice.dueDate ? format(new Date(invoice.dueDate), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                    <TableCell className="text-right font-mono border-r">£{invoice.totals.net.toFixed(2)}</TableCell>
                                    <TableCell className="text-right font-mono border-r">£{invoice.totals.vat.toFixed(2)}</TableCell>
                                    <TableCell className="text-right font-mono border-r">£{invoice.totals.gross.toFixed(2)}</TableCell>
                                    <TableCell className="border-r">{invoice.mtdDetails?.incomeSource}</TableCell>
                                    <TableCell className="border-r">
                                        <Badge variant={invoice.mtdDetails?.includeInMtd ? 'default' : 'outline'} className={cn(invoice.mtdDetails?.includeInMtd && 'bg-green-500')}>
                                            {invoice.mtdDetails?.includeInMtd ? 'Yes' : 'No'}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-center border-r">
                                        <Badge variant="outline" className={cn('capitalize', getStatusVariant(invoice.status))}>{invoice.status}</Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                    <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon">
                                                    <MoreHorizontal className="h-4 w-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent>
                                                <DropdownMenuItem onClick={() => setPreviewInvoice(invoice)}>
                                                    <Eye className="mr-2 h-4 w-4" />
                                                    Preview
                                                </DropdownMenuItem>
                                                {invoice.status !== 'Paid' && invoice.status !== 'Credit Note' && (
                                                    <DropdownMenuItem onClick={() => handleStatusChange(invoice.id, 'Paid')}>
                                                        Mark as Paid
                                                    </DropdownMenuItem>
                                                )}
                                                <DropdownMenuItem asChild>
                                                    <Link href={`/dashboard/invoices/create?edit=${invoice.id}`}>Edit</Link>
                                                </DropdownMenuItem>
                                                <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                )}
            </div>
            {previewInvoice && (
                <Dialog open={!!previewInvoice} onOpenChange={() => setPreviewInvoice(null)}>
                    <DialogContent className="max-w-4xl p-0">
                        <DialogHeader className="p-8 pb-0">
                            <DialogTitle>Invoice Preview</DialogTitle>
                            <DialogDescription>
                                This is a preview of the invoice that will be sent to your client.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="p-8">
                            <div className="grid grid-cols-2 items-start gap-8">
                                <div>
                                    <MTDSimpleLogo className="h-10 w-10 text-primary mb-4" />
                                    <h2 className="text-lg font-semibold">Your Company Name</h2>
                                    <p className="text-sm text-muted-foreground">123 Your Street, Your Town, YR1 2CD</p>
                                </div>
                                <div className="text-right">
                                    <h1 className="text-2xl font-bold">INVOICE</h1>
                                    <p className="text-muted-foreground"># {previewInvoice.invoiceNumber}</p>
                                </div>
                            </div>
                            <Separator className="my-6" />
                            <div className="grid grid-cols-2 gap-8">
                                <div>
                                    <p className="font-semibold text-muted-foreground">BILL TO</p>
                                    <p className="font-bold">{previewInvoice.client.name}</p>
                                    <p>{previewInvoice.client.address}</p>
                                    <p>{previewInvoice.client.zipcode}</p>
                                </div>
                                <div className="text-right space-y-1">
                                    <p><span className="font-semibold text-muted-foreground">Invoice Date: </span>{format(new Date(previewInvoice.date), 'dd MMM yyyy')}</p>
                                    <p><span className="font-semibold text-muted-foreground">Due Date: </span>{previewInvoice.dueDate ? format(new Date(previewInvoice.dueDate), 'dd MMM yyyy') : 'N/A'}</p>
                                </div>
                            </div>

                            <div className="mt-8">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead className="w-[50%]">Description</TableHead>
                                            <TableHead className="text-center">Qty</TableHead>
                                            <TableHead className="text-right">Unit Price</TableHead>
                                            <TableHead className="text-right">Total</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {previewInvoice.lineItems.map(item => (
                                            <TableRow key={item.id}>
                                                <TableCell className="font-medium">{item.description}</TableCell>
                                                <TableCell className="text-center">{item.quantity}</TableCell>
                                                <TableCell className="text-right font-mono">£{item.unitPrice.toFixed(2)}</TableCell>
                                                <TableCell className="text-right font-mono">£{(item.quantity * item.unitPrice).toFixed(2)}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                            
                            <div className="mt-6 flex justify-end">
                                <div className="w-full max-w-sm space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-muted-foreground">Subtotal</span>
                                        <span className="font-mono">£{(previewInvoice.totals.net + previewInvoice.discount).toFixed(2)}</span>
                                    </div>
                                    {previewInvoice.discount > 0 && (
                                        <div className="flex justify-between">
                                            <span className="text-muted-foreground">Discount</span>
                                            <span className="font-mono">- £{previewInvoice.discount.toFixed(2)}</span>
                                        </div>
                                    )}
                                    <div className="flex justify-between">
                                        <span className="text-muted-foreground">VAT</span>
                                        <span className="font-mono">£{previewInvoice.totals.vat.toFixed(2)}</span>
                                    </div>
                                    <Separator />
                                    <div className="flex justify-between font-bold text-lg">
                                        <span>Total</span>
                                        <span className="font-mono">£{previewInvoice.totals.gross.toFixed(2)}</span>
                                    </div>
                                     {previewInvoice.mtdDetails.allowYapilyPayment && (
                                        <div className="pt-4">
                                            <Button className="w-full">Pay with Yapily</Button>
                                        </div>
                                    )}
                                </div>
                            </div>

                        </div>
                    </DialogContent>
                </Dialog>
            )}
        </>
    )

}

export default function InvoicesPage() {
    const { activeClient } = useActiveClient();
  return (
    <div className="space-y-6">
       <Card>
        <CardHeader>
            <div className="flex justify-between items-center">
                <div>
                    <CardTitle>Invoices</CardTitle>
                    <CardDescription>
                        Create, upload, and manage your invoices and credit notes. This screen shows all invoices of the Business and any invoices created by the client for their clients.
                    </CardDescription>
                </div>
                 {activeClient && (
                    <Button asChild variant="outline">
                        <Link href={`/dashboard/client/${activeClient.id}`}>
                            <ArrowLeft className="mr-2 h-4 w-4" />
                            Back to Client View
                        </Link>
                    </Button>
                )}
            </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button asChild>
              <Link href="/dashboard/invoices/create">
                <FilePlus2 />
                Create Invoice
              </Link>
            </Button>
            <Button variant="outline" asChild>
                <Link href="/dashboard/invoices/credit-note">
                    <FileText />
                    Create New Credit Note
                </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/dashboard/invoices/upload">
                <Upload />
                Upload Invoice
              </Link>
            </Button>
            <Button variant="secondary" asChild>
                <Link href="/dashboard/invoices?status=Draft">
                    <Edit2 />
                    Drafts
                </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Invoice Summary</CardTitle>
            <CardDescription>
              A summary of your recent invoice activity.
            </CardDescription>
          </CardHeader>
            <SentInvoicesList />
        </Card>
      </div>
    </div>
  );
}
