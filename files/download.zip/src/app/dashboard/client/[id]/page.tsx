

"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { clients as initialClients } from '@/lib/data';
import Link from 'next/link';
import { notFound, useParams } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  Banknote,
  FileText,
  Landmark,
  PlusCircle,
  Users,
  ArrowUpRight,
  Edit,
  Save,
  X,
  CalendarIcon,
  Building,
} from 'lucide-react';
import type { Client, BankFeedStatus } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useState, useEffect } from 'react';
import { add, format } from 'date-fns';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useActiveClient } from '@/hooks/use-active-client';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const getVatReturnColor = (days: number) => {
  if (days < 15) return 'bg-red-500 text-white';
  if (days >= 15 && days <= 59) return 'bg-yellow-500 text-black';
  if (days >= 60) return 'bg-green-500 text-white';
  return 'bg-gray-500/20 text-gray-700';
};

const getStatusColor = (status: Client['hmrcStatus'] | BankFeedStatus) => {
  switch (status) {
    case 'Connected':
      return 'bg-green-500 text-white';
    case 'Expiring Soon':
      return 'bg-yellow-500 text-black';
    case 'Disconnected':
    case 'Needs Reconnection':
      return 'bg-red-500 text-white';
    default:
      return 'bg-gray-500/20 text-gray-700';
  }
};

export default function ClientPage() {
  const params = useParams();
  const id = params.id as string;
  const [client, setClient] = useState<Client | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editableClient, setEditableClient] = useState<Client | null>(null);
  const { toast } = useToast();
  const { setActiveClient } = useActiveClient();

  useEffect(() => {
    const allClients = JSON.parse(localStorage.getItem('clients') || JSON.stringify(initialClients));
    const clientData = allClients.find((c: Client) => c.id === id);

    if (clientData) {
      const now = new Date();
      const fullClientData = {
        ...clientData,
        vatReturnDueDate: format(add(now, { days: clientData.vatReturnDays }), 'dd MMM yyyy'),
        mtdIncomeTaxDueDate: format(add(now, { days: clientData.mtdIncomeTaxDays }), 'dd MMM yyyy'),
      };
      setClient(fullClientData);
      setEditableClient(fullClientData);
      setActiveClient(fullClientData);
    } else {
      notFound();
    }
  }, [id, setActiveClient]);
  
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'clients') {
          const allClients = JSON.parse(e.newValue || '[]');
          const clientData = allClients.find((c: Client) => c.id === id);
           if (clientData) {
              const now = new Date();
              const fullClientData = {
                ...clientData,
                vatReturnDueDate: format(add(now, { days: clientData.vatReturnDays }), 'dd MMM yyyy'),
                mtdIncomeTaxDueDate: format(add(now, { days: clientData.mtdIncomeTaxDays }), 'dd MMM yyyy'),
              };
              setClient(fullClientData);
              setActiveClient(fullClientData);
              if (!isEditing) {
                setEditableClient(fullClientData);
              }
           }
        }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [id, isEditing, setActiveClient]);

  const handleInputChange = (field: keyof Client, value: string | Date | undefined) => {
    if (editableClient) {
      setEditableClient({ ...editableClient, [field]: value });
    }
  };

  const handleSave = () => {
    if (editableClient) {
      const allClients = JSON.parse(localStorage.getItem('clients') || '[]') as Client[];
      const updatedClients = allClients.map(c => c.id === editableClient.id ? { ...c, ...editableClient } : c);
      localStorage.setItem('clients', JSON.stringify(updatedClients));
      
      window.dispatchEvent(new StorageEvent('storage', { key: 'clients', newValue: JSON.stringify(updatedClients)}));

      setClient(editableClient);
      setIsEditing(false);
      toast({
        title: "Client details saved",
        description: "The client's information has been updated.",
      });
    }
  };

  const handleCancel = () => {
    setEditableClient(client);
    setIsEditing(false);
  };

  if (!client || !editableClient) {
    return <div>Loading...</div>;
  }

  const totalUnpaid = client.unpaidInvoices.reduce((acc, inv) => acc + inv.amount, 0);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
            <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{client.name}{client.tradingName && <span className="text-muted-foreground text-lg"> ({client.tradingName})</span>}</CardTitle>
                   {!isEditing && (
                    <CardDescription className="pt-2">
                        Main Contact: {client.mainContactPerson}
                    </CardDescription>
                   )}
                </div>
                 <div className="flex gap-2">
                    {isEditing ? (
                        <>
                            <Button variant="outline" onClick={handleCancel}><X className="mr-2 h-4 w-4" />Cancel</Button>
                            <Button onClick={handleSave}><Save className="mr-2 h-4 w-4" />Save Changes</Button>
                        </>
                    ) : (
                        <Button variant="outline" onClick={() => setIsEditing(true)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Client
                        </Button>
                    )}
                </div>
            </div>
        </CardHeader>
        <CardContent>
            {isEditing ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="name">Client Name</Label>
                        <Input id="name" value={editableClient.name} onChange={e => handleInputChange('name', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="tradingName">Trading Name</Label>
                        <Input id="tradingName" value={editableClient.tradingName} onChange={e => handleInputChange('tradingName', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="mainContactPerson">Main Contact Person</Label>
                        <Input id="mainContactPerson" value={editableClient.mainContactPerson} onChange={e => handleInputChange('mainContactPerson', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={editableClient.email} onChange={e => handleInputChange('email', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="phoneNumber">Phone Number</Label>
                        <Input id="phoneNumber" value={editableClient.phoneNumber} onChange={e => handleInputChange('phoneNumber', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input id="address" value={editableClient.address} onChange={e => handleInputChange('address', e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="zipcode">Zip/Postcode</Label>
                        <Input id="zipcode" value={editableClient.zipcode} onChange={e => handleInputChange('zipcode', e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="country">Country</Label>
                        <Input id="country" value={editableClient.country || ''} onChange={e => handleInputChange('country', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="referenceNo">Reference No.</Label>
                        <Input id="referenceNo" value={editableClient.referenceNo} onChange={e => handleInputChange('referenceNo', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="vatNumber">VAT Number</Label>
                        <Input id="vatNumber" value={editableClient.vatNumber} onChange={e => handleInputChange('vatNumber', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="utrNo">UTR No.</Label>
                        <Input id="utrNo" value={editableClient.utrNo || ''} onChange={e => handleInputChange('utrNo', e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label>Select Currency</Label>
                        <RadioGroup value={editableClient.currency || 'GBP'} onValueChange={(value) => handleInputChange('currency', value)} className="flex gap-4">
                            <Label htmlFor="gbp" className="flex-1 cursor-pointer rounded-lg border p-4 peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary">
                                <div className="flex items-center justify-between"><span className="font-semibold">GBP (£)</span><RadioGroupItem value="GBP" id="gbp" /></div><p className="text-sm text-muted-foreground mt-1">British Pound</p>
                            </Label>
                            <Label htmlFor="eur" className="flex-1 cursor-pointer rounded-lg border p-4 peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary">
                                <div className="flex items-center justify-between"><span className="font-semibold">EUR (€)</span><RadioGroupItem value="EUR" id="eur" /></div><p className="text-sm text-muted-foreground mt-1">Euro</p>
                            </Label>
                        </RadioGroup>
                    </div>
                     <div className="space-y-2 md:col-span-2">
                        <Label>VAT Basis</Label>
                        <RadioGroup value={editableClient.vatBasis || 'accrual'} onValueChange={(value) => handleInputChange('vatBasis', value)} className="grid grid-cols-2 gap-4">
                            <div className="flex items-start gap-4 rounded-lg border p-4">
                                <RadioGroupItem value="accrual" id="accrual" className="mt-1"/><div className="flex-1"><Label htmlFor="accrual" className="text-base font-semibold">Accrual Basis</Label><p className="text-sm text-muted-foreground">VAT is accounted for based on the date of the invoice.</p></div>
                            </div>
                            <div className="flex items-start gap-4 rounded-lg border p-4">
                                <RadioGroupItem value="cash" id="cash" className="mt-1"/><div className="flex-1"><Label htmlFor="cash" className="text-base font-semibold">Cash Basis</Label><p className="text-sm text-muted-foreground">VAT is accounted for based on when payment is received.</p></div>
                            </div>
                        </RadioGroup>
                    </div>
                    <div className="space-y-2 md:col-span-3">
                        <Label>Company Type</Label>
                        <RadioGroup value={editableClient.companyType || 'ltd'} onValueChange={(value) => handleInputChange('companyType', value)} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <Label htmlFor="ltd" className="block cursor-pointer rounded-lg border p-4 peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary">
                                <div className="flex items-center justify-between"><span className="font-semibold">Limited Company</span><RadioGroupItem value="ltd" id="ltd" /></div>
                            </Label>
                            <Label htmlFor="sole-trader" className="block cursor-pointer rounded-lg border p-4 peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary">
                                <div className="flex items-center justify-between"><span className="font-semibold">Sole Trader</span><RadioGroupItem value="sole-trader" id="sole-trader" /></div>
                            </Label>
                            <Label htmlFor="partnership" className="block cursor-pointer rounded-lg border p-4 peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary">
                                <div className="flex items-center justify-between"><span className="font-semibold">Partnership</span><RadioGroupItem value="partnership" id="partnership" /></div>
                            </Label>
                        </RadioGroup>
                    </div>

                </div>
            ) : (
                 <CardDescription className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-2">
                    <div>
                        <span className="font-semibold text-foreground">Email: </span>
                        {client.email}
                    </div>
                    <div>
                        <span className="font-semibold text-foreground">Phone: </span>
                        {client.phoneNumber}
                    </div>
                    <div>
                        <span className="font-semibold text-foreground">Address: </span>
                        {client.address}, {client.zipcode}
                    </div>
                     <div>
                        <span className="font-semibold text-foreground">Country: </span>
                        {client.country}
                    </div>
                    <div>
                        <span className="font-semibold text-foreground">Reference No: </span>
                        {client.referenceNo}
                    </div>
                    <div>
                        <span className="font-semibold text-foreground">VAT Number: </span>
                        {client.vatNumber}
                    </div>
                    <div>
                        <span className="font-semibold text-foreground">UTR No: </span>
                        {client.utrNo || 'N/A'}
                    </div>
                     <div>
                        <span className="font-semibold text-foreground">Currency: </span>
                        {client.currency || 'N/A'}
                    </div>
                     <div>
                        <span className="font-semibold text-foreground">VAT Basis: </span>
                        <span className="capitalize">{client.vatBasis || 'N/A'}</span>
                    </div>
                     <div>
                        <span className="font-semibold text-foreground">Company Type: </span>
                        <span className="capitalize">{client.companyType?.replace('-', ' ') || 'N/A'}</span>
                    </div>
                </CardDescription>
            )}
        </CardContent>
      </Card>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="flex flex-col">
          <CardHeader className="flex flex-row items-center justify-center p-3 border-b">
            <CardTitle className="text-sm font-medium">VAT Return</CardTitle>
          </CardHeader>
          <CardContent className="pt-3 flex-grow space-y-2">
            <div className="text-sm text-foreground">Vat Reg Number: {client.vatNumber}</div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-foreground">HMRC Status:</span>
              <Badge variant="outline" className={cn('capitalize rounded-md', getStatusColor(client.hmrcStatus))}>
                {client.hmrcStatus}
              </Badge>
            </div>
            <div className="space-y-1">
              <div className="text-sm text-foreground">Next Vat Return Date:</div>
              <div className={cn('flex items-center justify-between gap-2 border rounded-md p-1 w-full text-base', getVatReturnColor(client.vatReturnDays))}>
                <span className="font-medium">{client.vatReturnDueDate}</span>
                <Badge variant="outline" className={cn('w-fit rounded-md', getVatReturnColor(client.vatReturnDays), 'hover:bg-none')}>
                  {client.vatReturnDays} days
                </Badge>
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-3 border-t">
            <Button size="sm" variant="default" className="w-full" asChild>
                <Link href="/dashboard/vat-returns">
                    View <ArrowUpRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardFooter>
        </Card>
        <Card className="flex flex-col">
          <CardHeader className="flex flex-row items-center justify-center p-3 border-b">
            <CardTitle className="text-sm font-medium">Bank Account Feeds</CardTitle>
          </CardHeader>
          <CardContent className="pt-3 flex-grow space-y-2">
            <div className="space-y-3">
              {client.bankFeeds.map(feed => (
                <div key={feed.bankName} className="flex items-center justify-between text-base">
                  <div className="flex items-center gap-2 text-foreground">
                    <Landmark className="h-4 w-4" />
                    <span className="font-medium">{feed.bankName}</span>
                  </div>
                  <Badge variant="outline" className={cn('capitalize rounded-md', getStatusColor(feed.status))}>
                    {feed.status}
                  </Badge>
                </div>
              ))}
            </div>
             <div className="mt-4 text-sm text-foreground">Last sync: 2 hours ago</div>
          </CardContent>
           <CardFooter className="p-3 border-t">
            <Button size="sm" variant="default" className="w-full" asChild>
                <Link href={`/dashboard/bank-feeds`}>
                    View <ArrowUpRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardFooter>
        </Card>
        <Card className="flex flex-col">
          <CardHeader className="flex flex-row items-center justify-center p-3 border-b">
            <CardTitle className="text-sm font-medium">MTD Income Tax</CardTitle>
          </CardHeader>
          <CardContent className="pt-3 flex-grow space-y-2">
            <div className="text-sm text-foreground">UTR: {client.utrNo || 'Not Set'}</div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-foreground">HMRC Status:</span>
              <Badge variant="outline" className={cn('capitalize rounded-md', getStatusColor('Connected'))}>
                Connected
              </Badge>
            </div>
          </CardContent>
           <CardFooter className="p-3 border-t">
            <Button size="sm" variant="default" className="w-full" asChild>
                <Link href="/dashboard/income-tax">
                    View <ArrowUpRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardFooter>
        </Card>
        <Card className="flex flex-col">
          <CardHeader className="flex flex-row items-center justify-center p-3 border-b">
            <CardTitle className="text-sm font-medium">Unpaid Invoices</CardTitle>
          </CardHeader>
          <CardContent className="pt-3 flex-grow">
            <div className="space-y-2 mb-4">
                <div className="text-sm font-medium text-foreground">Total Unpaid Invoices</div>
                <div className="text-2xl font-bold text-foreground">£{totalUnpaid.toFixed(2)}</div>
            </div>

            {client.unpaidInvoices.length > 0 ? (
                <div className="space-y-2 text-sm">
                    <div className="font-medium text-foreground">Recent Unpaid Invoices</div>
                    {client.unpaidInvoices.slice(0, 3).map(invoice => (
                        <div key={invoice.invoiceNumber} className="flex justify-between items-center text-foreground">
                            <span >{invoice.invoiceNumber}</span>
                            <span className="font-mono">£{invoice.amount.toFixed(2)}</span>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-sm text-foreground">No unpaid invoices.</p>
            )}
          </CardContent>
            <CardFooter className="p-3 border-t">
                <Button size="sm" className="w-full" asChild>
                <Link href="/dashboard/invoices">
                    View All Invoices <ArrowUpRight className="ml-2 h-4 w-4" />
                </Link>
                </Button>
            </CardFooter>
        </Card>
      </div>
    </div>
  );
}
