

"use client";

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Client, StaffMember } from '@/lib/types';
import { clients as initialClientsData, initialStaff } from '@/lib/data';
import { Eye, Briefcase, Users } from 'lucide-react';
import { useActiveClient } from '@/hooks/use-active-client';

export default function SuperAdminProjectsPage() {
    const router = useRouter();
    const [clients, setClients] = useState<Client[]>([]);
    const [staff, setStaff] = useState<StaffMember[]>([]);

    const { setActiveClient } = useActiveClient();

    const loadData = useCallback(() => {
        let clientData: Client[];
        try {
            const storedClients = localStorage.getItem('clients');
            clientData = storedClients ? JSON.parse(storedClients) : initialClientsData as Client[];
        } catch {
            clientData = initialClientsData as Client[];
        }
        setClients(clientData);

        let staffData: StaffMember[];
        try {
            const storedStaff = localStorage.getItem('hubStaff');
            staffData = storedStaff ? JSON.parse(storedStaff) : initialStaff;
        } catch {
            staffData = initialStaff;
        }
        setStaff(staffData);

    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);
    
    const handleViewProject = (client: Client) => {
        setActiveClient(client);
        router.push(`/staff-dashboard/project/${client.id}`);
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Current Projects</CardTitle>
                <CardDescription>An overview of all active company projects.</CardDescription>
            </CardHeader>
            <CardContent>
                 <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Company</TableHead>
                            <TableHead>Team Lead</TableHead>
                            <TableHead>Allocated Staff</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {clients.map(client => {
                            const teamLead = staff.find(s => s.id === client.assignedTeamLeadId);
                            const allocatedCount = client.allocatedStaffIds?.length || 0;
                            return (
                                <TableRow key={client.id}>
                                    <TableCell className="font-semibold">{client.name}</TableCell>
                                    <TableCell>
                                        {teamLead ? (
                                            <Badge variant="outline">{teamLead.name}</Badge>
                                        ) : (
                                            <Badge variant="destructive">Not Assigned</Badge>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <Users className="h-4 w-4 text-muted-foreground" />
                                            <span>{allocatedCount} Staff Member(s)</span>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button size="sm" variant="outline" onClick={() => handleViewProject(client)}>
                                            <Briefcase className="mr-2 h-4 w-4"/>
                                            Manage Project
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            )
                        })}
                    </TableBody>
                 </Table>
            </CardContent>
        </Card>
    );
}
