

"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function SuperAdminRedirectPage() {
    const router = useRouter();
    useEffect(() => {
        router.replace('/dashboard/super-admin/team-leads');
    }, [router]);
    return null;
}
