

"use client";

import Link from 'next/link';
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { clients as initialClients } from '@/lib/data';
import { ArrowUpRight, Pencil, Download, PlusCircle, Edit, Key, Trash2, MoreHorizontal } from 'lucide-react';
import type { Client } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useActiveClient } from '@/hooks/use-active-client';
import { useRouter } from 'next/navigation';

function CompanyFormDialog({ open, onOpenChange, onCompanySave, company, onDelete }: { 
    open: boolean, 
    onOpenChange: (open: boolean) => void, 
    onCompanySave: () => void, 
    company: Client | null,
    onDelete: (companyId: string) => void,
}) {
    const { toast } = useToast();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [phone, setPhone] = useState('');
    const [contact, setContact] = useState('');
    const [vatNumber, setVatNumber] = useState('');
    const [address, setAddress] = useState('');
    const [zipcode, setZipcode] = useState('');
    const [country, setCountry] = useState('Northern Ireland');
    const [referenceNo, setReferenceNo] = useState('');
    const [status, setStatus] = useState<Client['status']>('Active');
    const [cashBalance, setCashBalance] = useState<number | ''>(0);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    
    useEffect(() => {
        if (company) {
            setName(company.name);
            setEmail(company.email);
            setPassword(company.password || '');
            setPhone(company.phoneNumber);
            setContact(company.mainContactPerson);
            setVatNumber(company.vatNumber);
            setAddress(company.address);
            setZipcode(company.zipcode);
            setCountry(company.country || 'Northern Ireland');
            setReferenceNo(company.referenceNo);
            setStatus(company.status || 'Active');
            setCashBalance(company.cashBalance || 0);
        } else {
            // Reset for new company
            setName('');
            setEmail('');
            setPassword('');
            setPhone('');
            setContact('');
            setVatNumber('');
            setAddress('');
            setZipcode('');
            setCountry('Northern Ireland');
            setReferenceNo('');
            setStatus('Active');
            setCashBalance(0);
        }
    }, [company]);

    const handleSubmit = async () => {
        if (!name || !email || !contact) {
            toast({ variant: 'destructive', title: 'Missing Fields', description: 'Please fill out all required fields.' });
            return;
        }

        try {
            const allCompanies: Client[] = JSON.parse(sessionStorage.getItem('clients') || '[]');
            if (company) {
                 // Edit existing company
                const updatedCompanies = allCompanies.map(c => c.id === company.id ? { ...c, name, email, password, phoneNumber: phone, mainContactPerson: contact, vatNumber, address, zipcode, country, referenceNo, status, cashBalance: Number(cashBalance) || 0 } : c);
                sessionStorage.setItem('clients', JSON.stringify(updatedCompanies));
                toast({ title: 'Company Updated', description: `${name} has been updated.` });
            } else {
                // Add new company
                const newCompany: Client = {
                    id: `client-${Date.now()}`,
                    name,
                    email,
                    phoneNumber: phone,
                    mainContactPerson: contact,
                    vatNumber,
                    address,
                    zipcode,
                    country,
                    referenceNo,
                    status: 'Active', // New companies are active by default from super admin
                    tradingName: '',
                    hmrcStatus: 'Disconnected',
                    vatReturnDays: 90,
                    mtdIncomeTaxDays: 90,
                    bankFeeds: [],
                    bankFeedStatus: 'Disconnected',
                    unpaidInvoices: [],
                    password,
                    cashBalance: Number(cashBalance) || 0,
                    vatReturnDueDate: '',
                    mtdIncomeTaxDueDate: ''
                };

                const updatedCompanies = [...allCompanies, newCompany];
                sessionStorage.setItem('clients', JSON.stringify(updatedCompanies));
                toast({ title: 'Company Added', description: `${name} has been added.` });
            }

            onCompanySave();
            onOpenChange(false);
        } catch (e) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to save company.' });
        }
    };
    
    const handleResetPassword = () => {
        const newPassword = Math.random().toString(36).slice(-8);
        setPassword(newPassword);
        toast({
            title: 'Password Generated',
            description: 'A new password has been generated. Remember to save changes.'
        });
    }

    const handleDeleteConfirm = () => {
        if(company) {
            onDelete(company.id);
            onOpenChange(false);
        }
    }

    return (
        <>
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>{company ? 'Edit Company' : 'Add New Company'}</DialogTitle>
                    <DialogDescription>
                        {company ? `Update the details for ${company.name}.` : 'Enter the details for the new company.'}
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
                    <div className="space-y-2 col-span-2">
                        <Label htmlFor="name">Company Name</Label>
                        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="contact">Contact Person</Label>
                        <Input id="contact" value={contact} onChange={(e) => setContact(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="phone">Contact Number</Label>
                        <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="referenceNo">Reference No.</Label>
                        <Input id="referenceNo" value={referenceNo} onChange={(e) => setReferenceNo(e.target.value)} />
                    </div>
                    <div className="space-y-2 col-span-2">
                        <Label htmlFor="address">Address</Label>
                        <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="zipcode">Zip/Postcode</Label>
                        <Input id="zipcode" value={zipcode} onChange={(e) => setZipcode(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="country">Country</Label>
                        <Select value={country} onValueChange={setCountry}>
                            <SelectTrigger id="country">
                                <SelectValue placeholder="Select a country" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Northern Ireland">Northern Ireland</SelectItem>
                                <SelectItem value="UK">United Kingdom</SelectItem>
                                <SelectItem value="Ireland">Ireland</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="vatNumber">VAT Number</Label>
                        <Input id="vatNumber" value={vatNumber} onChange={(e) => setVatNumber(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="cashBalance">Cash Balance (£)</Label>
                        <Input id="cashBalance" type="number" value={cashBalance} onChange={(e) => setCashBalance(e.target.value === '' ? '' : parseFloat(e.target.value))} />
                    </div>
                    <div className="space-y-2 col-span-2">
                        <Label htmlFor="password">Password</Label>
                        <div className="flex gap-2">
                            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                            <Button variant="outline" type="button" onClick={handleResetPassword}><Key className="mr-2 h-4 w-4"/> Reset</Button>
                        </div>
                    </div>
                    <div className="flex items-center space-x-2 col-span-2">
                        <Switch id="status" checked={status === 'Active'} onCheckedChange={(checked) => setStatus(checked ? 'Active' : 'Inactive')} />
                        <Label htmlFor="status">{status === 'Active' ? 'Active' : 'Inactive'}</Label>
                    </div>
                </div>
                <DialogFooter className="justify-between">
                    <div>
                        {company && (
                             <Button variant="destructive" onClick={() => setIsDeleteDialogOpen(true)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete Company
                            </Button>
                        )}
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button onClick={handleSubmit}>{company ? 'Save Changes' : 'Add Company'}</Button>
                    </div>
                </DialogFooter>
            </DialogContent>
        </Dialog>
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
                <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the company and all associated data.
                </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteConfirm}>Continue</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
        </>
    );
}

export default function CompanyManagementPage() {
    const [companies, setCompanies] = useState<Client[]>([]);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingCompany, setEditingCompany] = useState<Client | null>(null);
    const { toast } = useToast();
    const { activeClient } = useActiveClient();
    const router = useRouter();

    useEffect(() => {
        // Security check: If a regular client is logged in, redirect them.
        if (activeClient) {
            router.replace('/dashboard/company');
        }
    }, [activeClient, router]);


    const fetchClients = () => {
        let storedClients;
        try {
            storedClients = JSON.parse(sessionStorage.getItem('clients') || '[]');
            if (storedClients.length === 0) {
                storedClients = initialClients;
                sessionStorage.setItem('clients', JSON.stringify(initialClients));
            }
        } catch {
            storedClients = initialClients;
            sessionStorage.setItem('clients', JSON.stringify(initialClients));
        }
        setCompanies(storedClients);
    };

    useEffect(() => {
        if (!activeClient) { // Only run if it's a super admin
            fetchClients();
        }
    }, [activeClient]);
    
    const handleExport = () => {
        const headers = [
          'Client Name', 'Trading Name', 'Reference No.', 'VAT Number', 
          'Main Contact', 'Email', 'Phone', 'Country', 'Status'
        ];

        const rows = companies.map(company => [
          `"${company.name}"`,
          `"${company.tradingName || ''}"`,
          company.referenceNo,
          company.vatNumber,
          `"${company.mainContactPerson}"`,
          company.email,
          company.phoneNumber,
          company.country || '',
          company.status,
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-t8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        const fileName = `coder-co-pilot-companies-${new Date().toISOString().split('T')[0]}.csv`;
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast({
            title: "Export Successful",
            description: "Your company list has been exported as a CSV file.",
        });
    }

    const openFormDialog = (company: Client | null) => {
        setEditingCompany(company);
        setIsFormOpen(true);
    };

    const handleDelete = (companyId: string) => {
        const updatedCompanies = companies.filter(c => c.id !== companyId);
        sessionStorage.setItem('clients', JSON.stringify(updatedCompanies));
        fetchClients();
        toast({
            title: "Company Deleted",
            description: "The company has been permanently removed.",
            variant: "destructive",
        });
    }

    const getStatusBadgeVariant = (status: Client['status']) => {
        switch (status) {
            case 'Active':
                return 'bg-green-500 text-white';
            case 'Inactive':
                return 'bg-gray-500 text-white';
            case 'Pending Approval':
                return 'bg-yellow-500 text-black';
            default:
                return 'secondary';
        }
    };
    

    // If a client is logged in, show a loading/redirecting state to prevent flashing the admin content
    if (activeClient) {
        return (
            <div className="flex justify-center items-center h-full">
                <p>Redirecting...</p>
            </div>
        );
    }

    return (
        <>
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>Company Management</CardTitle>
                            <CardDescription>Manage the companies that will use Coder Co-Pilot.</CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                            <Button onClick={() => openFormDialog(null)}>
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Add Company
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="border-r">Company Name</TableHead>
                                <TableHead className="border-r">Status</TableHead>
                                <TableHead className="border-r hidden sm:table-cell">Cash Balance</TableHead>
                                <TableHead className="hidden sm:table-cell border-r">VAT Number</TableHead>
                                <TableHead className="hidden md:table-cell border-r">Contact Person</TableHead>
                                <TableHead className="hidden md:table-cell border-r">Email</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {companies.map((company) => (
                                <TableRow key={company.id}>
                                    <TableCell className="font-medium border-r">{company.name}</TableCell>
                                    <TableCell className="border-r">
                                        <Badge className={cn(getStatusBadgeVariant(company.status))}>
                                            {company.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="font-mono text-right border-r hidden sm:table-cell">
                                        £{(company.cashBalance || 0).toFixed(2)}
                                    </TableCell>
                                    <TableCell className="hidden sm:table-cell border-r">{company.vatNumber}</TableCell>
                                    <TableCell className="hidden md:table-cell border-r">{company.mainContactPerson}</TableCell>
                                    <TableCell className="hidden md:table-cell border-r">{company.email}</TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="sm" onClick={() => openFormDialog(company)}>
                                            <Edit className="mr-2 h-4 w-4"/>
                                            Edit
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
                <CardFooter className="flex justify-end border-t pt-6">
                    <Button variant="outline" onClick={handleExport}>
                        <Download className="mr-2 h-4 w-4" />
                        Export as CSV
                    </Button>
                </CardFooter>
            </Card>
        </div>
         <CompanyFormDialog 
            open={isFormOpen} 
            onOpenChange={setIsFormOpen} 
            onCompanySave={fetchClients} 
            company={editingCompany}
            onDelete={handleDelete}
         />
        </>
    )
}
