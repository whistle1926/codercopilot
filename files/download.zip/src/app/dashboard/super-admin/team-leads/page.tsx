

"use client";

import { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowDown,
  ArrowUp,
  Search,
  MessageSquare,
  Briefcase,
  Upload,
  PlusCircle,
  Star,
  CheckCircle,
  Clock,
  Award,
  Edit,
  Trash2,
  Check,
  ChevronsUpDown,
  DollarSign,
  Key,
  X,
  Users,
  FileText,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { initialStaff as initialStaffData, clients as initialClients } from '@/lib/data';
import type { StaffMember, Skill, Task, Client, QuestionnaireSubmission } from '@/lib/types';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';


interface StaffTasks {
    [staffId: string]: {
        [companyId: string]: Task[];
    };
}

function QuestionnaireReviewCard({ 
    company, 
    submissions, 
    onAllocateClick,
}: { 
    company: Client, 
    submissions: QuestionnaireSubmission[], 
    onAllocateClick: () => void,
}) {
    
    if (submissions.length === 0) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle>{company.name}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">This company has not submitted their needs questionnaire yet.</p>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader className="flex flex-row justify-between items-start">
                <div>
                    <CardTitle>{company.name} - Projects</CardTitle>
                    <CardDescription>Review project needs and allocate staff.</CardDescription>
                </div>
                <Button onClick={onAllocateClick}>Allocate Staff</Button>
            </CardHeader>
            <CardContent className="space-y-4">
                {submissions.map(submission => (
                    <div key={submission.submissionDate} className="space-y-1 p-4 border rounded-lg">
                        <p className="font-semibold">{submission.projectName || 'Unnamed Project'}</p>
                        <p className="text-sm text-muted-foreground">{submission.projectDescription?.substring(0, 100) || 'No description provided.'}...</p>
                         <p className="text-xs text-muted-foreground">Submitted on {new Date(submission.submissionDate).toLocaleDateString()}</p>
                    </div>
                ))}
            </CardContent>
            <CardFooter>
                 <Button variant="outline" className="w-full" asChild>
                    <Link href={`/staff-dashboard/project/${company.id}`}>
                        Manage All Projects
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    )
}

function StaffAllocationDialog({
    open,
    onOpenChange,
    company,
    allStaff,
    onSaveAllocation,
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    company: Client | null;
    allStaff: StaffMember[];
    onSaveAllocation: (companyId: string, allocatedIds: string[]) => void;
}) {
    const [selectedStaffIds, setSelectedStaffIds] = useState<string[]>([]);

    useEffect(() => {
        if (company) {
            setSelectedStaffIds(company.allocatedStaffIds || []);
        }
    }, [company]);

    if (!company) return null;

    const availableStaff = allStaff.filter(s => !s.isTeamLead);

    const handleToggle = (staffId: string) => {
        setSelectedStaffIds(prev =>
            prev.includes(staffId) ? prev.filter(id => id !== staffId) : [...prev, staffId]
        );
    };

    const handleSave = () => {
        onSaveAllocation(company.id, selectedStaffIds);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Allocate Staff for {company.name}</DialogTitle>
                    <DialogDescription>
                        Select the professionals this company will be able to see and hire.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-4">
                        {availableStaff.map(staff => (
                            <div key={staff.id} className="flex items-center justify-between p-2 rounded-md border">
                                <div className="flex items-center gap-3">
                                    <Avatar>
                                        <AvatarImage src={staff.avatarUrl} />
                                        <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{staff.name}</p>
                                        <p className="text-sm text-muted-foreground">{staff.role}</p>
                                    </div>
                                </div>
                                <Checkbox
                                    checked={selectedStaffIds.includes(staff.id)}
                                    onCheckedChange={() => handleToggle(staff.id)}
                                />
                            </div>
                        ))}
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Allocation</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function SkillEditDialog({
  open,
  onOpenChange,
  skill: initialSkill,
  onSave,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  skill: Skill | null;
  onSave: (skill: Skill) => void;
  onDelete: () => void;
}) {
  const [skill, setSkill] = useState<Skill | null>(initialSkill);

  useEffect(() => {
    setSkill(initialSkill);
  }, [initialSkill]);

  if (!open || !skill) return null;

  const handleSave = () => {
    onSave(skill);
    onOpenChange(false);
  };
  
  const handleDeleteClick = () => {
      onDelete();
      onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initialSkill?.name ? 'Edit Skill' : 'Add New Skill'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="skill-name">Skill Name</Label>
            <Input
              id="skill-name"
              value={skill.name}
              onChange={(e) => setSkill({ ...skill, name: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="skill-years">Years of Experience</Label>
                <Input
                id="skill-years"
                type="number"
                value={skill.years === 0 ? '' : skill.years}
                onChange={(e) => setSkill({ ...skill, years: e.target.value === '' ? 0 : parseInt(e.target.value) || 0 })}
                />
            </div>
            <div className="space-y-2">
              <Label htmlFor="skill-level">Proficiency Level</Label>
              <Select
                value={skill.level}
                onValueChange={(value: Skill['level']) => setSkill({ ...skill, level: value })}
              >
                <SelectTrigger id="skill-level">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Intermediate">Intermediate</SelectItem>
                  <SelectItem value="Advanced">Advanced</SelectItem>
                  <SelectItem value="Expert">Expert</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter className="justify-between">
            {initialSkill?.name && (
                <Button variant="destructive" onClick={handleDeleteClick}>Delete Skill</Button>
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save Skill</Button>
            </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


const availabilityColors = {
  'Available For Hire': 'bg-green-500',
  'Currently Hired': 'bg-red-500',
};

type SortKey = keyof StaffMember | 'rate' | 'costRate' | 'margin';
type SortDirection = 'asc' | 'desc';

function SkillBar({ skill }: { skill: Skill }) {
    const levelValues = { 'Intermediate': 60, 'Advanced': 80, 'Expert': 100 };
    const isMtdCertified = skill.name === 'Coder Co-Pilot Certified';
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className={cn("text-sm font-medium", isMtdCertified && "text-primary")}>{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                     <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600', 
                            isMtdCertified && 'bg-primary',
                            skill.level === 'Advanced' && 'bg-blue-100 text-blue-800',
                            skill.level === 'Intermediate' && 'bg-blue-100 text-blue-800'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={levelValues[skill.level]} className={cn("h-2", isMtdCertified && "[&>div]:bg-primary")} />
        </div>
    )
}

const predefinedRoles = [
    'Junior Accountant',
    'Intermediate Accountant',
    'Mid-Level Accountant',
    'Senior Accountant',
    'Bookkeeper',
    'Tax Specialist',
    'Financial Data Analyst',
    'Cloud Accounting Specialist',
    'Virtual Assistant',
    'Team Lead',
];

function StaffForm({ 
    open, 
    onOpenChange,
    staff, 
    clients,
    onSave,
    onDelete,
}: { 
    open: boolean;
    onOpenChange: (open: boolean) => void;
    staff: StaffMember | null;
    clients: Client[];
    onSave: (staff: StaffMember) => void;
    onDelete: (staffId: string) => void;
}) {
    const [formData, setFormData] = useState<StaffMember | null>(null);
    const [isRolePopoverOpen, setIsRolePopoverOpen] = useState(false);
    const [isHiredByPopoverOpen, setIsHiredByPopoverOpen] = useState(false);
    
    const [editingSkill, setEditingSkill] = useState<{skill: Skill | null, type: 'technicalSkills' | 'softSkills', index: number | null}>({ skill: null, type: 'technicalSkills', index: null });


    const allRoleOptions = useMemo(() => {
        const roles = new Set(predefinedRoles);
        if (formData?.role && !roles.has(formData.role)) {
            roles.add(formData.role);
        }
        return Array.from(roles);
    }, [formData?.role]);

    useEffect(() => {
        if (open) {
            setFormData(staff || {
                id: `staff-${Date.now()}`,
                name: '',
                email: '',
                password: '',
                role: 'Team Lead', // Default to Team Lead
                location: '',
                avatarUrl: `https://picsum.photos/seed/${Date.now()}/40/40`,
                skills: [],
                technicalSkills: [],
                softSkills: [],
                rate: 0,
                costRate: 0,
                availability: 'Available For Hire',
                hiredBy: null,
                lastActive: 'Now',
                experience: '',
                rating: 0,
                reviews: 0,
                projects: 0,
                joinedDate: new Date().toISOString().split('T')[0],
                about: '',
                verified: false,
                premium: false,
                isVisible: true,
                isTeamLead: true, // Default to true for this form
                showPricing: true,
            });
        }
    }, [staff, open]);

    if (!formData) return null;

    const handleInputChange = (field: keyof StaffMember, value: any) => {
        setFormData(prev => {
            if (!prev) return null;
            let updatedState = { ...prev, [field]: value };
            if (field === 'hiredBy') {
                updatedState.availability = (value && value.length > 0) ? 'Currently Hired' : 'Available For Hire';
            }
            return updatedState;
        });
    };
    
    const openSkillEditor = (skill: Skill | null, type: 'technicalSkills' | 'softSkills', index: number | null = null) => {
        setEditingSkill({ skill: skill ? {...skill} : { name: '', level: 'Intermediate', years: 0 }, type, index });
    };

    const handleSaveSkill = (updatedSkill: Skill) => {
        setFormData(prev => {
            if (!prev) return null;
            const { type, index } = editingSkill;
            const newSkills = [...prev[type]];
            if (index !== null) { // Editing existing skill
                newSkills[index] = updatedSkill;
            } else { // Adding new skill
                newSkills.push(updatedSkill);
            }
            return { ...prev, [type]: newSkills };
        });
    };
    
    const handleDeleteSkill = () => {
         setFormData(prev => {
            if (!prev) return null;
            const { type, index } = editingSkill;
            if (index === null) return prev; // Should not happen
            const newSkills = prev[type].filter((_, i) => i !== index);
            return { ...prev, [type]: newSkills };
        });
    }

    const handleSave = () => {
        if (formData) {
            const allSkills = [...formData.technicalSkills, ...formData.softSkills].map(s => s.name);
            onSave({...formData, skills: allSkills, isTeamLead: true}); // Always save as team lead
            onOpenChange(false);
        }
    };
    
    const handleDeleteClick = () => {
        if (formData) {
            onDelete(formData.id);
            onOpenChange(false);
        }
    }
    
    const handleResetPassword = () => {
        if (formData) {
            const newPassword = Math.random().toString(36).slice(-8);
            handleInputChange('password', newPassword);
        }
    }

    const handleHiredByToggle = (clientId: string) => {
        if (!formData) return;
        const currentHiredBy = formData.hiredBy || [];
        let updatedHiredBy;
        if (currentHiredBy.includes(clientId)) {
            updatedHiredBy = currentHiredBy.filter(id => id !== clientId);
        } else {
            updatedHiredBy = [...currentHiredBy, clientId];
        }
        handleInputChange('hiredBy', updatedHiredBy);
    }

    const selectedClients = formData.hiredBy ? clients.filter(c => formData.hiredBy!.includes(c.id)) : [];

    const SkillEditorSection = ({ title, skillType }: { title: string, skillType: 'technicalSkills' | 'softSkills' }) => (
        <div className="col-span-2 space-y-3 rounded-lg border p-4">
            <div className="flex justify-between items-center">
                <Label>{title}</Label>
                <Button type="button" size="sm" variant="outline" onClick={() => openSkillEditor(null, skillType, null)}>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Skill
                </Button>
            </div>
            <div className="space-y-2">
                {formData[skillType].map((skill, index) => (
                     <div key={index} className="flex items-center gap-2 rounded-md p-2 bg-muted hover:bg-muted/80 cursor-pointer" onClick={() => openSkillEditor(skill, skillType, index)}>
                         <span className="flex-1 font-medium">{skill.name}</span>
                         <span className="text-sm text-muted-foreground">{skill.years} yrs</span>
                         <Badge variant="secondary">{skill.level}</Badge>
                    </div>
                ))}
                {formData[skillType].length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">No {title.toLowerCase()} added.</p>
                )}
            </div>
        </div>
    );

    return (
        <>
            <Dialog open={open} onOpenChange={onOpenChange}>
                <DialogContent className="sm:max-w-[700px]">
                    <DialogHeader>
                        <DialogTitle>{staff ? 'Edit Team Lead' : 'Add New Team Lead'}</DialogTitle>
                    </DialogHeader>
                    <div className="py-4 grid grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto pr-4">
                        <div className="space-y-2"><Label>Name</Label><Input value={formData.name || ''} onChange={e => handleInputChange('name', e.target.value)} /></div>
                        <div className="space-y-2">
                            <Label>Role</Label>
                            <Input value={formData.role || ''} onChange={e => handleInputChange('role', e.target.value)} />
                        </div>
                        <div className="space-y-2 col-span-2"><Label>Email</Label><Input type="email" value={formData.email || ''} onChange={e => handleInputChange('email', e.target.value)} /></div>
                        <div className="space-y-2 col-span-2">
                            <Label>Password</Label>
                            <div className="flex items-center gap-2">
                                <Input type="password" value={formData.password || ''} onChange={e => handleInputChange('password', e.target.value)} />
                                <Button variant="outline" type="button" onClick={handleResetPassword}><Key className="mr-2 h-4 w-4"/> Generate</Button>
                            </div>
                        </div>
                        <div className="space-y-2"><Label>Location</Label><Input value={formData.location || ''} onChange={e => handleInputChange('location', e.target.value)} /></div>
                        <div className="space-y-2">
                            <Label>Frontend Rate (£/hr)</Label>
                            <Input 
                                type="number" 
                                value={formData.rate === 0 ? '' : formData.rate}
                                placeholder="e.g., 75"
                                onChange={e => handleInputChange('rate', e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)} 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>Cost Rate (£/hr)</Label>
                            <Input 
                                type="number" 
                                value={formData.costRate === 0 ? '' : formData.costRate}
                                placeholder="e.g., 50"
                                onChange={e => handleInputChange('costRate', e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)} 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>Hired By</Label>
                            <Popover open={isHiredByPopoverOpen} onOpenChange={setIsHiredByPopoverOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        role="combobox"
                                        className="w-full justify-between"
                                    >
                                        <span className="truncate">
                                            {selectedClients.length > 0 
                                                ? selectedClients.map(c => c.name).join(', ')
                                                : "Not Hired"}
                                        </span>
                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                                    <Command>
                                        <CommandInput placeholder="Search company..." />
                                        <CommandList>
                                            <CommandEmpty>No company found.</CommandEmpty>
                                            <CommandGroup>
                                                {clients.map((client) => (
                                                    <CommandItem
                                                        key={client.id}
                                                        value={client.name}
                                                        onSelect={() => handleHiredByToggle(client.id)}
                                                    >
                                                        <Check
                                                            className={cn(
                                                                "mr-2 h-4 w-4",
                                                                formData.hiredBy?.includes(client.id) ? "opacity-100" : "opacity-0"
                                                            )}
                                                        />
                                                        {client.name}
                                                    </CommandItem>
                                                ))}
                                            </CommandGroup>
                                        </CommandList>
                                    </Command>
                                </PopoverContent>
                            </Popover>
                        </div>

                        <div className="space-y-2 col-span-2"><Label>About</Label><Textarea value={formData.about || ''} onChange={e => handleInputChange('about', e.target.value)} /></div>

                        <SkillEditorSection title="Technical Skills" skillType="technicalSkills" />
                        <SkillEditorSection title="Soft Skills" skillType="softSkills" />
                        
                        <div className="space-y-2"><Label>Experience</Label><Input value={formData.experience || ''} onChange={e => handleInputChange('experience', e.target.value)} /></div>
                        
                        <div className="flex items-center space-x-2"><Checkbox checked={formData.verified} onCheckedChange={v => handleInputChange('verified', !!v)} id="verified" /><Label htmlFor="verified">Staff Hub Pro Verified</Label></div>
                        <div className="flex items-center space-x-2"><Checkbox checked={formData.premium} onCheckedChange={v => handleInputChange('premium', !!v)} id="premium" /><Label htmlFor="premium">Top Rated By Employers</Label></div>
                         <div className="flex items-center space-x-2"><Checkbox checked={formData.isTeamLead} disabled id="isTeamLead" /><Label htmlFor="isTeamLead" className="text-muted-foreground">Team Lead</Label></div>
                    
                        <div className="col-span-2">
                            <Separator className="my-4" />
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="showPricing" className="flex flex-col space-y-1">
                                        <span>Show Pricing to Staff</span>
                                        <span className="font-normal leading-snug text-muted-foreground">
                                            Control whether this staff member can see their own rates and earnings.
                                        </span>
                                    </Label>
                                    <Switch
                                        id="showPricing"
                                        checked={formData.showPricing}
                                        onCheckedChange={v => handleInputChange('showPricing', v)}
                                    />
                                </div>
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="isVisible" className="flex flex-col space-y-1">
                                        <span>Show on Hub</span>
                                        <span className="font-normal leading-snug text-muted-foreground">
                                            Uncheck to hide this professional from the main list.
                                        </span>
                                    </Label>
                                    <Switch
                                        id="isVisible"
                                        checked={formData.isVisible}
                                        onCheckedChange={v => handleInputChange('isVisible', v)}
                                    />
                                </div>
                                {staff && (
                                    <div className="flex items-center justify-between">
                                        <Label htmlFor="delete" className="flex flex-col space-y-1 text-destructive">
                                            <span>Delete Professional</span>
                                            <span className="font-normal leading-snug ">
                                                This action is permanent and cannot be undone.
                                            </span>
                                        </Label>
                                        <Button variant="destructive" onClick={handleDeleteClick}>
                                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>


                    <DialogFooter>
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button onClick={handleSave}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <SkillEditDialog 
                open={!!editingSkill.skill}
                onOpenChange={() => setEditingSkill({ skill: null, type: 'technicalSkills', index: null })}
                skill={editingSkill.skill}
                onSave={handleSaveSkill}
                onDelete={handleDeleteSkill}
            />
        </>
    )
}

function FinancialOverview({ staff, allTasks }: { staff: StaffMember, allTasks: StaffTasks }) {
    const [financials, setFinancials] = useState({ income: 0, paymentDue: 0, profit: 0 });

    useEffect(() => {
        const staffTaskData = allTasks[staff.id] || {};
        let totalHours = 0;
        
        Object.values(staffTaskData).forEach(companyTasksObject => {
            if(companyTasksObject && typeof companyTasksObject === 'object') {
                Object.values(companyTasksObject).forEach(task => {
                    if(task && typeof task.hoursLogged === 'number') {
                        totalHours += task.hoursLogged;
                    }
                })
            }
        });

        const income = totalHours * staff.rate;
        const paymentDue = totalHours * (staff.costRate || 0);
        const profit = income - paymentDue;

        setFinancials({ income, paymentDue, profit });
    }, [staff, allTasks]);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-muted-foreground" />
                    Financial Overview
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Income Earned</span>
                    <span className="font-mono font-semibold">£{financials.income.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Payment Due to Staff</span>
                    <span className="font-mono font-semibold">£{financials.paymentDue.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold">
                    <span>Total Profit</span>
                    <span className="font-mono">£{financials.profit.toFixed(2)}</span>
                </div>
            </CardContent>
        </Card>
    );
}

export default function SuperAdminTeamLeadsPage() {
  const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [questionnaireSubmissions, setQuestionnaireSubmissions] = useState<QuestionnaireSubmission[]>([]);
  const [allTasks, setAllTasks] = useState<StaffTasks>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [sortConfig, setSortConfig] = useState<{
    key: SortKey;
    direction: SortDirection;
  } | null>({ key: 'rate', direction: 'asc' });

  const { toast } = useToast();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);

  const [isAllocationOpen, setIsAllocationOpen] = useState(false);
  const [allocatingCompany, setAllocatingCompany] = useState<Client | null>(null);

  const loadData = useCallback(() => {
    let staffData: StaffMember[];
    try {
        const storedStaff = localStorage.getItem('hubStaff');
        staffData = storedStaff ? JSON.parse(storedStaff).map((s:any) => ({...s, costRate: s.costRate || 0, isVisible: s.isVisible !== false, isTeamLead: s.isTeamLead || false, showPricing: s.showPricing !== false })) : initialStaffData.map(s => ({...s, costRate: s.costRate || s.rate * 0.7, isTeamLead: s.isTeamLead || false, showPricing: true }));
    } catch {
        staffData = initialStaffData.map(s => ({...s, costRate: s.costRate || s.rate * 0.7, isTeamLead: s.isTeamLead || false, showPricing: true }));
    }
    setAllStaff(staffData);

    let clientData: Client[];
    try {
        const storedClients = localStorage.getItem('clients');
        clientData = storedClients ? JSON.parse(storedClients) : initialClients as Client[];
    } catch {
        clientData = initialClients as Client[];
    }
    setClients(clientData);

    let submissionData: QuestionnaireSubmission[];
    try {
        const storedSubmissions = localStorage.getItem('questionnaireSubmissions');
        submissionData = storedSubmissions ? JSON.parse(storedSubmissions) : [];
    } catch {
        submissionData = [];
    }
    setQuestionnaireSubmissions(submissionData);

    const storedTasks = localStorage.getItem('staffTasks');
    if (storedTasks) {
        setAllTasks(JSON.parse(storedTasks));
    }
  }, []);

  useEffect(() => {
    loadData();
    window.addEventListener('storage', loadData);
    return () => window.removeEventListener('storage', loadData);
  }, [loadData]);
  
  const teamLeads = useMemo(() => allStaff.filter(s => s.isTeamLead), [allStaff]);


  useEffect(() => {
    if (!selectedStaff && teamLeads.length > 0) {
        const firstStaff = teamLeads[0];
        if(firstStaff) setSelectedStaff(firstStaff);
    }
  }, [teamLeads, selectedStaff]);

  const saveAllStaffList = (list: StaffMember[]) => {
    localStorage.setItem('hubStaff', JSON.stringify(list));
    setAllStaff(list);
  };
  
  const handleSaveStaff = (staffMember: StaffMember) => {
    const isNew = !allStaff.some(s => s.id === staffMember.id);
    let updatedStaff;
    if (isNew) {
      updatedStaff = [...allStaff, staffMember];
       toast({ title: 'Team Lead Added', description: `${staffMember.name} has been added.` });
    } else {
      updatedStaff = allStaff.map(s => s.id === staffMember.id ? staffMember : s);
       toast({ title: 'Team Lead Updated', description: `${staffMember.name}'s profile has been updated.` });
    }
    saveAllStaffList(updatedStaff);
    setSelectedStaff(staffMember);
  }

  const handleDeleteStaff = (staffId: string) => {
    const updatedStaff = allStaff.filter(s => s.id !== staffId);
    saveAllStaffList(updatedStaff);
    toast({ title: 'Team Lead Deleted', description: `The team lead has been removed.` });
    if (selectedStaff?.id === staffId) {
        setSelectedStaff(updatedStaff[0] || null);
    }
  }

  const openForm = (staffMember: StaffMember | null) => {
    setEditingStaff(staffMember);
    setIsFormOpen(true);
  }
  
  const openAllocationDialog = (company: Client) => {
      setAllocatingCompany(company);
      setIsAllocationOpen(true);
  }

  const handleSaveAllocation = (companyId: string, allocatedIds: string[]) => {
      const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
      const updatedClients = allClients.map(c => c.id === companyId ? { ...c, allocatedStaffIds: allocatedIds } : c);
      setClients(updatedClients);
      localStorage.setItem('clients', JSON.stringify(updatedClients));
      toast({
          title: 'Staff Allocated',
          description: `Staff allocation for ${clients.find(c => c.id === companyId)?.name} has been updated.`
      });
  }

  const sortedStaff = useMemo(() => {
    let sortableItems = [...teamLeads];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (sortConfig.key === 'margin') {
            const marginA = a.rate > 0 ? ((a.rate - (a.costRate || 0)) / a.rate) * 100 : 0;
            const marginB = b.rate > 0 ? ((b.rate - (b.costRate || 0)) / b.rate) * 100 : 0;
            if (marginA < marginB) return sortConfig.direction === 'asc' ? -1 : 1;
            if (marginA > marginB) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        }

        const valA = a[sortConfig.key as keyof StaffMember] || 0;
        const valB = b[sortConfig.key as keyof StaffMember] || 0;

        if (valA < valB) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (valA > valB) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [sortConfig, teamLeads]);

  const filteredStaff = useMemo(() => {
    return sortedStaff.filter(
      (staffMember) => {
        const matchesSearch =
            staffMember.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.role.toLowerCase().includes(searchTerm.toLowerCase());

        return matchesSearch;
      }
    );
  }, [searchTerm, sortedStaff]);
  
  const assignedCompanies = useMemo(() => {
      if (!selectedStaff) return [];
      return clients.filter(c => c.assignedTeamLeadId === selectedStaff.id);
  }, [selectedStaff, clients]);

  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortKey) => {
    if (!sortConfig || sortConfig.key !== key) {
      return null;
    }
    return sortConfig.direction === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  const isMtdCertified = selectedStaff?.technicalSkills.some(skill => skill.name === 'Coder Co-Pilot Certified');

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Users className="h-6 w-6"/>
                  Manage Team Leads
                </CardTitle>
                <CardDescription>
                  Add, edit, and manage team leads who act as points of contact for companies.
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => openForm(null)}>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Team Lead
                </Button>
              </div>
            </div>
            <div className="mt-4 flex gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or role..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('name')}>
                          Team Lead {getSortIcon('name')}
                      </button>
                  </TableHead>
                  <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('costRate')}>
                          Cost Rate {getSortIcon('costRate')}
                      </button>
                  </TableHead>
                   <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('rate')}>
                          Frontend Rate {getSortIcon('rate')}
                      </button>
                  </TableHead>
                  <TableHead>
                      <button className="flex items-center gap-1" onClick={() => requestSort('margin')}>
                          Margin % {getSortIcon('margin')}
                      </button>
                  </TableHead>
                  <TableHead>Availability</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStaff.map((staffMember) => {
                    const margin = staffMember.rate > 0 ? ((staffMember.rate - (staffMember.costRate || 0)) / staffMember.rate) * 100 : 0;
                    const hiredByClients = staffMember.hiredBy ? clients.filter(c => staffMember.hiredBy!.includes(c.id)) : [];
                    const availabilityText = hiredByClients.length > 0 ? `Hired by ${hiredByClients.map(c => c.name).join(', ')}` : staffMember.availability;

                    return (
                  <TableRow 
                      key={staffMember.id} 
                      className={cn("cursor-pointer", selectedStaff?.id === staffMember.id && "bg-muted")}
                      onClick={() => setSelectedStaff(staffMember)}
                  >
                    <TableCell>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={staffMember.avatarUrl} alt={staffMember.name} />
                        <AvatarFallback>
                          {staffMember.name
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                          <div className="font-medium">{staffMember.name}</div>
                          <Badge variant="outline" className="border-green-500 text-green-700">Team Lead</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {staffMember.role}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono font-semibold">
                      £{(staffMember.costRate || 0).toFixed(2)}/hr
                    </TableCell>
                    <TableCell className="font-mono font-semibold">
                      £{staffMember.rate.toFixed(2)}/hr
                    </TableCell>
                    <TableCell className="font-mono font-semibold">
                        {margin.toFixed(2)}%
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            'h-2.5 w-2.5 rounded-full',
                            hiredByClients.length > 0 ? availabilityColors['Currently Hired'] : availabilityColors[staffMember.availability]
                          )}
                        />
                        <div className="text-sm truncate max-w-[150px]">{availabilityText}</div>
                      </div>
                    </TableCell>
                  </TableRow>
                    )
                })}
              </TableBody>
            </Table>
             {filteredStaff.length === 0 && (
                <div className="text-center p-8 text-muted-foreground">
                    <p>No Team Leads found matching your criteria.</p>
                </div>
             )}
          </CardContent>
        </Card>
        {selectedStaff && (
          <Card className="lg:col-span-1 sticky top-6">
              <CardHeader>
                   <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                        <Avatar className="h-20 w-20">
                            <AvatarImage src={selectedStaff.avatarUrl} alt={selectedStaff.name} />
                            <AvatarFallback className="text-3xl">
                                {selectedStaff.name.split(' ').map((n) => n[0]).join('')}
                            </AvatarFallback>
                        </Avatar>
                        <div className="space-y-1">
                            <h3 className="text-2xl font-bold">{selectedStaff.name}</h3>
                            <Badge variant="secondary" className="text-base">{selectedStaff.role}</Badge>
                            <p className="text-sm text-muted-foreground pt-1">{selectedStaff.location}</p>
                        </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => openForm(selectedStaff)}>
                        <Edit className="h-4 w-4" />
                    </Button>
                  </div>
              </CardHeader>

              <CardContent className="space-y-4">
                 <Tabs defaultValue="questionnaires">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="questionnaires">Questionnaires</TabsTrigger>
                        <TabsTrigger value="details">Details</TabsTrigger>
                    </TabsList>
                    <TabsContent value="questionnaires" className="pt-4 space-y-4">
                         <h4 className="font-semibold text-lg">Assigned Companies & Questionnaires</h4>
                         {assignedCompanies.length > 0 ? assignedCompanies.map(company => {
                            const companySubmissions = questionnaireSubmissions.filter(s => s.companyId === company.id);
                             return (
                                 <QuestionnaireReviewCard 
                                    key={company.id}
                                    company={company}
                                    submissions={companySubmissions}
                                    onAllocateClick={() => openAllocationDialog(company)}
                                 />
                             )
                         }) : (
                             <p className="text-sm text-muted-foreground text-center py-4">No companies assigned to this team lead yet.</p>
                         )}
                    </TabsContent>
                    <TabsContent value="details" className="pt-4 space-y-4">
                          <FinancialOverview staff={selectedStaff} allTasks={allTasks} />
                          <div className="space-y-6 text-sm">
                              <div>
                                  <h4 className="font-semibold mb-2 text-base">About</h4>
                                  <p className="text-muted-foreground">{selectedStaff.about}</p>
                              </div>
                              <div>
                                  <h4 className="font-semibold mb-2 text-base">Skills & Expertise</h4>
                                  <div className="grid grid-cols-1 gap-6">
                                      <div className="space-y-4">
                                          <h5 className="font-medium">Technical Skills</h5>
                                          {selectedStaff.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                                      </div>
                                      <div className="space-y-4">
                                          <h5 className="font-medium">Soft Skills</h5>
                                          {selectedStaff.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                                      </div>
                                  </div>
                              </div>
                          </div>
                    </TabsContent>
                 </Tabs>
              </CardContent>
          </Card>
        )}
      </div>

      <StaffForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        staff={editingStaff}
        clients={clients}
        onSave={handleSaveStaff}
        onDelete={handleDeleteStaff}
      />
       <StaffAllocationDialog 
        open={isAllocationOpen}
        onOpenChange={setIsAllocationOpen}
        company={allocatingCompany}
        allStaff={allStaff}
        onSaveAllocation={handleSaveAllocation}
      />
    </div>
  );
}
