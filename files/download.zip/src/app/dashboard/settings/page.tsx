

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Users, FileText, Landmark, Banknote, Search, Settings, BookCopy, Folder, Key, UserPlus, Construction, Phone, Video, Briefcase, MessageSquare, Building, Wallet } from "lucide-react";
import { SidebarProvider, Sidebar, SidebarHeader, SidebarContent, SidebarFooter, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarTrigger, SidebarInset, useSidebar } from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { UserNav } from "@/components/user-nav";
import { CoderCoPilotLogo } from '@/components/icons';
import { useActiveClient } from "@/hooks/use-active-client";
import { Clock } from "@/components/clock";
import { cn } from "@/lib/utils";
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from "@/components/ui/button";


const navItems = [
  { href: '/dashboard/company', icon: Briefcase, label: 'Coder Co-Pilot', exact: true, clientSpecific: false },
  { href: '/dashboard/messages', icon: MessageSquare, label: 'Messages', exact: false, clientSpecific: false },
  { href: '/dashboard/credits', icon: Wallet, label: 'Balance', exact: false, clientSpecific: false },
];

const hiredStaffNavItem = { href: '/dashboard/hired-staff', icon: Users, label: 'Hired Staff', exact: false, clientSpecific: false };


function isNavItemActive(item: typeof navItems[number], pathname: string) {
    if (item.href === '/dashboard' && item.exact) {
        return pathname === '/dashboard';
    }
    // Make bank-feeds active even on sub-pages
    if (item.href === '/dashboard/bank-feeds') {
        return pathname.startsWith('/dashboard/bank-feeds');
    }
     if (item.href === '/dashboard/messages') {
        return pathname.startsWith('/dashboard/messages');
    }
    if (item.href === '/dashboard/build-progress') {
        return pathname.startsWith('/dashboard/build-progress');
    }
     if (item.href === '/dashboard/hired-staff') {
        return pathname.startsWith('/dashboard/hired-staff');
    }
     if (item.href === '/dashboard/credits') {
        return pathname.startsWith('/dashboard/credits');
    }
    return pathname.startsWith(item.href) && !item.exact ? pathname.startsWith(item.href) : pathname === item.href;
}

function getLinkHref(item: typeof navItems[number], activeClient: ReturnType<typeof useActiveClient>['activeClient']) {
    // ALWAYS link to the bank feeds summary page, not a specific bank.
    if (item.href === '/dashboard/bank-feeds') {
        return '/dashboard/bank-feeds';
    }
    
    if (!activeClient || !item.clientSpecific) return item.href;
    
    return item.href;
}

function WelcomeVideoDialog({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
    const handleClose = () => {
        localStorage.setItem('hasWatchedIntroVideo', 'true');
        onOpenChange(false);
    }
    
    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent className="max-w-3xl">
                <DialogHeader>
                    <DialogTitle>Welcome to Coder Co-Pilot!</DialogTitle>
                    <DialogDescription>
                        Watch this short video to get an overview of the platform and its features.
                    </DialogDescription>
                </DialogHeader>
                <div className="aspect-video rounded-lg overflow-hidden border">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/UCtHtlHXMS0?autoplay=1"
                        title="YouTube video player"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                    ></iframe>
                </div>
                <DialogFooter>
                    <Button onClick={handleClose}>Close</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

function NavMenu({ activeClient, hasHiredStaff }: { activeClient: ReturnType<typeof useActiveClient>['activeClient'], hasHiredStaff: boolean }) {
    const pathname = usePathname();
    const isSuperAdmin = pathname.includes('/super-admin');

    if (isSuperAdmin) {
        return (
             <SidebarMenu className="p-2">
                 <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      isActive={pathname.startsWith('/dashboard/super-admin/staff')}
                      tooltip="Manage Staff"
                    >
                      <Link href="/dashboard/super-admin">
                        <Briefcase />
                        <span>Manage Staff</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      isActive={pathname.startsWith('/dashboard/super-admin/company-settings')}
                      tooltip="Company Settings"
                    >
                      <Link href="/dashboard/super-admin/company-settings">
                        <Building />
                        <span>Company Settings</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
             </SidebarMenu>
        )
    }

    const allNavItems = hasHiredStaff ? [...navItems, hiredStaffNavItem] : navItems;


    return (
        <SidebarMenu className="p-2">
            {allNavItems.map((item) => {
                const label = item.clientSpecific && activeClient ? `${item.label} (${activeClient.name})` : item.label;
                const link = getLinkHref(item, activeClient);

                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                      asChild
                      isActive={isNavItemActive(item, pathname)}
                      tooltip={label}
                      disabled={item.clientSpecific && !activeClient}
                      aria-disabled={item.clientSpecific && !activeClient}
                    >
                      <Link href={link}>
                        <item.icon />
                        <span>
                          {item.label}
                          {item.clientSpecific && activeClient && (
                            <span className="block text-xs opacity-75 -mt-1">{activeClient.name}</span>
                          )}
                        </span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
            })}
        </SidebarMenu>
    )
}

function TopNav({ activeClient, hasHiredStaff }: { activeClient: ReturnType<typeof useActiveClient>['activeClient'], hasHiredStaff: boolean }) {
    const { state, isMobile } = useSidebar();
    const pathname = usePathname();

    if (state === 'expanded' || isMobile) {
        return null;
    }
    
    const allNavItems = hasHiredStaff ? [...navItems, hiredStaffNavItem] : navItems;

    return (
        <nav className="flex items-center space-x-1">
            {allNavItems.map((item) => {
                const isActive = isNavItemActive(item, pathname);
                const isDisabled = item.clientSpecific && !activeClient;
                const link = getLinkHref(item, activeClient);

                return (
                    <Link
                        key={item.href}
                        href={link}
                        className={cn(
                            "flex items-center gap-2 rounded-md px-3 py-1.5 text-sm transition-colors",
                            isActive
                                ? "bg-primary text-primary-foreground font-semibold"
                                : "text-muted-foreground hover:bg-accent/50 hover:text-accent-foreground",
                            isDisabled && "pointer-events-none opacity-50"
                        )}
                        aria-disabled={isDisabled}
                    >
                        <item.icon className="h-4 w-4" />
                        <div className="flex flex-col items-start leading-tight">
                            <span>{item.label}</span>
                            {item.clientSpecific && activeClient && (
                                <span className={cn("text-xs -mt-0.5", isActive ? "opacity-80" : "opacity-75")}>({activeClient.name})</span>
                            )}
                        </div>
                    </Link>
                );
            })}
        </nav>
    );
}

function DashboardLayoutContent({ children }: { children: React.ReactNode }) {
  const { activeClient } = useActiveClient();
  const { state: sidebarState, isMobile } = useSidebar();
  const pathname = usePathname();
  const isSuperAdmin = pathname.includes('/super-admin');
  const [hasHiredStaff, setHasHiredStaff] = useState(false);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    
    const hired = localStorage.getItem('hiredStaff');
    setHasHiredStaff(hired ? JSON.parse(hired).length > 0 : false);
    
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'hiredStaff') {
            const newHired = e.newValue;
            setHasHiredStaff(newHired ? JSON.parse(newHired).length > 0 : false);
        }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return (
    <>
      <Sidebar>
        <SidebarHeader>
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <CoderCoPilotLogo className="h-6 w-6" />
            </div>
            <h2 className="text-lg font-semibold">{isSuperAdmin ? 'Super Admin' : 'Coder Co-Pilot'}</h2>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <NavMenu activeClient={activeClient} hasHiredStaff={hasHiredStaff} />
        </SidebarContent>
        
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 sm:px-6">
          <SidebarTrigger />
          {sidebarState === 'expanded' || isMobile ? (
            <>
              <Clock />
              {activeClient && !isSuperAdmin && (
                <div className="hidden md:block font-semibold text-lg text-muted-foreground">
                  Client: <Link href={`/dashboard/client/${activeClient.id}`} className="text-foreground hover:underline">{activeClient.name}</Link>
                </div>
              )}
              {isSuperAdmin && (
                <div className="hidden md:block font-semibold text-lg text-muted-foreground">
                  Super Admin Dashboard
                </div>
              )}
            </>
          ) : (
            <TopNav activeClient={activeClient} hasHiredStaff={hasHiredStaff} />
          )}
          <div className="relative ml-auto flex items-center gap-4">
            {isClient && activeClient && !isSuperAdmin && (
              <div className="flex items-center gap-2 text-sm font-semibold p-2 rounded-md bg-muted">
                <Wallet className="h-5 w-5 text-primary" />
                <span className="whitespace-nowrap">Balance: <span className="font-mono">£{(activeClient.cashBalance || 0).toFixed(2)}</span></span>
                <Button size="sm" asChild variant="outline" className="h-7">
                  <Link href="/dashboard/credits">Top Up</Link>
                </Button>
              </div>
            )}
          </div>
          <UserNav />
        </header>
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </SidebarInset>
    </>
  )
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [showVideo, setShowVideo] = React.useState(false);

  React.useEffect(() => {
    // This effect runs on the client after hydration
    const hasWatched = localStorage.getItem('hasWatchedIntroVideo');
    if (!hasWatched) {
        setShowVideo(true);
    }
  }, []);

  return (
      <>
        <WelcomeVideoDialog open={showVideo} onOpenChange={setShowVideo} />
        <SidebarProvider>
            <DashboardLayoutContent>{children}</DashboardLayoutContent>
        </SidebarProvider>
      </>
  );
}
