

"use client";

import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { MessageSquare, ListChecks, PlusCircle, Check, Flag, Clock, Edit, X, CalendarIcon, Eye, DollarSign, Save, Pause, Play, Trash2, ThumbsUp, ThumbsDown, Lock, Unlock, TimerIcon, RotateCcw, UserMinus, Award, Send, AlertTriangle } from 'lucide-react';
import type { StaffMember, Client } from '@/lib/types';
import type { Task, TaskStatus, TaskPriority, Comment, SubTask, CostLimits, TimeLimit, DayOfWeek, ProjectUpdate } from '@/lib/types';
import Link from 'next/link';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format, parse, differenceInMilliseconds, isWithinInterval, addDays, differenceInHours, differenceInMinutes, differenceInSeconds, isAfter, formatDistanceToNow } from 'date-fns';
import type { DateRange } from 'react-day-picker';
import { toZonedTime, fromZonedTime } from 'date-fns-tz';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { useActiveClient } from '@/hooks/use-active-client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from '@/components/ui/separator';
import { initialStaff, clients as initialClientsData } from '@/lib/data';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface StaffTasks {
    [staffId: string]: {
        [companyId: string]: Task[];
    };
}

// Storing schedule requests in localStorage for prototype purposes
// In a real app, this would be in a database.
const getScheduleRequests = (): Record<string, HourRequest> => {
    try {
        return JSON.parse(localStorage.getItem('scheduleRequests') || '{}');
    } catch {
        return {};
    }
};

const saveScheduleRequests = (requests: Record<string, HourRequest>) => {
    localStorage.setItem('scheduleRequests', JSON.stringify(requests));
     window.dispatchEvent(new StorageEvent('storage', { key: 'scheduleRequests', newValue: JSON.stringify(requests)}));
};


function ScheduleApproval({
    staff,
    company,
    onScheduleUpdate,
}: {
    staff: StaffMember;
    company: Client;
    onScheduleUpdate: () => void;
}) {
    const { toast } = useToast();
    const [request, setRequest] = useState<HourRequest | null>(null);

    useEffect(() => {
        const requests = getScheduleRequests();
        const requestKey = `req_${company.id}_${staff.id}`;
        setRequest(requests[requestKey] || null);
    }, [company.id, staff.id]);

    const handleApproval = (status: 'Approved' | 'Rejected') => {
        if (!request) return;
        
        const requests = getScheduleRequests();
        const requestKey = `req_${company.id}_${staff.id}`;
        
        // Update the staff member's actual timeLimits only on approval
        if (status === 'Approved') {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const updatedAllStaff = allStaff.map(s => 
                s.id === staff.id ? { ...s, timeLimits: request.timeLimits } : s
            );
            localStorage.setItem('hubStaff', JSON.stringify(updatedAllStaff));
            window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff' }));
        }

        // Remove the request from the queue
        delete requests[requestKey];
        saveScheduleRequests(requests);
        onScheduleUpdate(); // Trigger re-render in parent

        toast({
            title: `Schedule ${status}`,
            description: `The work schedule for ${staff.name} has been ${status.toLowerCase()}.`
        });
    };
    
    if (!request || request.status !== 'Pending Approval') {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Schedule For Approval</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">There is no pending work schedule for {staff.name}.</p>
                </CardContent>
            </Card>
        );
    }
    
    const weeklyCost = request.timeLimits.reduce((acc, limit) => {
        if (limit.startTime && limit.endTime) {
            try {
                const start = parse(limit.startTime, 'HH:mm', new Date());
                const end = parse(limit.endTime, 'HH:mm', new Date());
                const dailyMilliseconds = differenceInMilliseconds(end, start);
                const dailyHours = dailyMilliseconds > 0 ? dailyMilliseconds / (1000 * 60 * 60) : 0;
                return acc + (dailyHours * staff.rate);
            } catch { return acc; }
        }
        return acc;
    }, 0);


    return (
        <Card className="border-yellow-500 border-2">
             <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                        <CardTitle className="flex items-center gap-2 text-yellow-600">
                            <AlertTriangle />
                            New Schedule Submitted for Approval
                        </CardTitle>
                        <CardDescription>
                            Your Team Manager has submitted a new work schedule for {staff.name}. Please review and approve.
                        </CardDescription>
                    </div>
                     <p className="text-sm text-muted-foreground">Submitted on {format(new Date(request.requestDate), 'dd MMM yyyy')}</p>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Day</TableHead>
                            <TableHead>Start Time</TableHead>
                            <TableHead>End Time</TableHead>
                            <TableHead className="text-right">Hours</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {request.timeLimits.map(limit => {
                             const hours = (limit.startTime && limit.endTime) ? differenceInHours(parse(limit.endTime, 'HH:mm', new Date()), parse(limit.startTime, 'HH:mm', new Date())) : 0;
                            return (
                                <TableRow key={limit.day}>
                                    <TableCell className="font-semibold">{limit.day}</TableCell>
                                    <TableCell>{limit.startTime}</TableCell>
                                    <TableCell>{limit.endTime}</TableCell>
                                    <TableCell className="text-right font-mono">{hours > 0 ? `${hours} hrs` : '-'}</TableCell>
                                </TableRow>
                            )
                        })}
                    </TableBody>
                     <TableFooter>
                        <TableRow>
                            <TableCell colSpan={3} className="text-right font-bold text-lg">Estimated Weekly Cost</TableCell>
                            <TableCell className="text-right font-bold text-lg font-mono">£{weeklyCost.toFixed(2)}</TableCell>
                        </TableRow>
                    </TableFooter>
                </Table>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
                <Button variant="destructive" onClick={() => handleApproval('Rejected')}>Reject Schedule</Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={() => handleApproval('Approved')}>Approve Schedule</Button>
            </CardFooter>
        </Card>
    )
}


function RewardDialog({ open, onOpenChange, onReward, staffName, clientBalance }: { open: boolean, onOpenChange: (open: boolean) => void, onReward: (amount: number, note: string) => void, staffName: string, clientBalance: number }) {
    const [amount, setAmount] = useState<number | ''>('');
    const [note, setNote] = useState('');

    const handleReward = () => {
        if (typeof amount === 'number' && amount > 0) {
            onReward(amount, note);
            onOpenChange(false);
            setAmount('');
            setNote('');
        }
    };

    const isInvalid = typeof amount === 'number' && amount > clientBalance;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Reward {staffName}</DialogTitle>
                    <DialogDescription>
                        Recognize excellent work with a bonus. This amount will be deducted from your company's cash balance.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="p-2 rounded-md bg-muted text-center">
                        <p className="text-sm text-muted-foreground">Your Current Balance</p>
                        <p className="text-lg font-bold">£{clientBalance.toFixed(2)}</p>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="reward-amount">Bonus Amount (£)</Label>
                        <Input
                            id="reward-amount"
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
                            placeholder="e.g., 50"
                        />
                        {isInvalid && (
                            <p className="text-sm text-destructive">Bonus amount cannot exceed your cash balance.</p>
                        )}
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="reward-note">Personal Note (Optional)</Label>
                        <Textarea
                            id="reward-note"
                            value={note}
                            onChange={(e) => setNote(e.target.value)}
                            placeholder={`e.g., "Great job on the quarterly report, ${staffName}!"`}
                        />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleReward} disabled={!amount || isInvalid}>Send Reward</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function PaymentReleaseButton({
    disabled,
    onClick,
    amount
}: {
    disabled: boolean;
    onClick: () => void;
    amount: number;
}) {
    return (
        <Button onClick={onClick} disabled={disabled || amount <= 0}>
            <Send className="mr-2 h-4 w-4" />
            Release Payment (£{amount.toFixed(2)})
        </Button>
    )
}

function PaymentsTab({ 
    staff, 
    tasks, 
    onReleasePayments 
}: { 
    staff: StaffMember, 
    tasks: Task[], 
    onReleasePayments: () => void 
}) {
    const [timeLeft, setTimeLeft] = useState('');
    const [isPaymentLocked, setIsPaymentLocked] = useState(false);
    
    const weeklyCost = useMemo(() => {
        if (!staff.timeLimits) return 0;
        let totalWeeklyHours = 0;
        staff.timeLimits.forEach(limit => {
            if (limit.startTime && limit.endTime) {
                try {
                    const start = parse(limit.startTime, 'HH:mm', new Date());
                    const end = parse(limit.endTime, 'HH:mm', new Date());
                    const dailyMilliseconds = differenceInMilliseconds(end, start);
                    if (dailyMilliseconds > 0) {
                        const dailyHours = dailyMilliseconds / (1000 * 60 * 60);
                        totalWeeklyHours += dailyHours;
                    }
                } catch (e) {
                    console.error("Invalid time format in timeLimits", e);
                }
            }
        });
        return totalWeeklyHours * staff.rate;
    }, [staff.timeLimits, staff.rate]);

    const paymentHistory = useMemo(() => {
        return tasks.filter(t => t.title.startsWith('Weekly Payment') || t.title.startsWith('Bonus from')).sort((a,b) => new Date(b.completionDate || 0).getTime() - new Date(a.completionDate || 0).getTime());
    }, [tasks]);
    
    useEffect(() => {
        const lastWeeklyPayment = paymentHistory.find(p => p.title.startsWith('Weekly Payment'));
        let intervalId: NodeJS.Timeout;

        const checkPaymentLock = () => {
            if (lastWeeklyPayment && lastWeeklyPayment.completionDate) {
                const lastPaymentDate = new Date(lastWeeklyPayment.completionDate);
                const unlockDate = addDays(lastPaymentDate, 7);

                if (isAfter(unlockDate, new Date())) {
                    setIsPaymentLocked(true);
                    const now = new Date();
                    const hours = differenceInHours(unlockDate, now);
                    const minutes = differenceInMinutes(unlockDate, now) % 60;
                    const seconds = differenceInSeconds(unlockDate, now) % 60;
                    setTimeLeft(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
                } else {
                    setIsPaymentLocked(false);
                    setTimeLeft('');
                    clearInterval(intervalId);
                }
            } else {
                 setIsPaymentLocked(false);
                 setTimeLeft('');
            }
        };

        checkPaymentLock();
        intervalId = setInterval(checkPaymentLock, 1000);

        return () => clearInterval(intervalId);
    }, [paymentHistory]);


    return (
        <Card>
            <CardHeader>
                <CardTitle>Payments for {staff.name}</CardTitle>
                <CardDescription>Review costs and release payments for approved tasks.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                    <Card>
                        <CardHeader className="pb-2"><CardTitle className="text-base font-medium">Scheduled Weekly Hours</CardTitle></CardHeader>
                        <CardContent><p className="text-2xl font-bold">{
                             staff.timeLimits ? staff.timeLimits.reduce((acc, limit) => {
                                if (limit.startTime && limit.endTime) {
                                    try {
                                        const start = parse(limit.startTime, 'HH:mm', new Date());
                                        const end = parse(limit.endTime, 'HH:mm', new Date());
                                        const dailyMilliseconds = differenceInMilliseconds(end, start);
                                        return acc + (dailyMilliseconds > 0 ? dailyMilliseconds / (1000 * 60 * 60) : 0);
                                    } catch { return acc; }
                                }
                                return acc;
                            }, 0).toFixed(2) : '0.00'
                        } hrs</p></CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="pb-2"><CardTitle className="text-base font-medium">Payment Amount Pending</CardTitle></CardHeader>
                        <CardContent><p className="text-2xl font-bold">£{weeklyCost.toFixed(2)}</p></CardContent>
                    </Card>
                </div>

                 <div>
                    <h4 className="font-semibold mb-2">Payment History</h4>
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Date</TableHead>
                                <TableHead>Description</TableHead>
                                <TableHead className="text-right">Amount</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {paymentHistory.length > 0 ? paymentHistory.map(task => (
                                <TableRow key={task.id}>
                                    <TableCell>{task.completionDate ? format(new Date(task.completionDate), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                    <TableCell>{task.title}</TableCell>
                                    <TableCell className="text-right font-mono">£{(task.cost || 0).toFixed(2)}</TableCell>
                                </TableRow>
                            )) : (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center text-muted-foreground">No payments have been made yet.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
             <CardFooter>
                 {isPaymentLocked ? (
                    <Button disabled>
                        <Clock className="mr-2 h-4 w-4" />
                        Next payment available in {timeLeft}
                    </Button>
                ) : (
                    <PaymentReleaseButton
                        disabled={weeklyCost <= 0}
                        onClick={onReleasePayments}
                        amount={weeklyCost}
                    />
                )}
            </CardFooter>
        </Card>
    );
}

function RestrictionsManager({ staff, onStaffUpdate }: { staff: StaffMember, onStaffUpdate: (updatedStaff: StaffMember) => void }) {
    const { toast } = useToast();
    const [costLimits, setCostLimits] = useState<CostLimits>(staff.costLimits || {});
    const [timeLimits, setTimeLimits] = useState<TimeLimit[]>(staff.timeLimits || []);
    const { activeClient } = useActiveClient();
    const [isLocked, setIsLocked] = useState(staff.isLocked || false);

    const companyTimezone = useMemo(() => activeClient?.timezone || 'Europe/London', [activeClient]);
    const staffTimezone = useMemo(() => staff.timezone || 'Asia/Manila', [staff]);

    useEffect(() => {
        let totalWeeklyHours = 0;
        let maxDailyHours = 0;

        timeLimits.forEach(limit => {
            if (limit.startTime && limit.endTime) {
                try {
                    const start = parse(limit.startTime, 'HH:mm', new Date());
                    const end = parse(limit.endTime, 'HH:mm', new Date());
                    const dailyMilliseconds = differenceInMilliseconds(end, start);
                    const dailyHours = dailyMilliseconds > 0 ? dailyMilliseconds / (1000 * 60 * 60) : 0;
                    
                    if (dailyHours > 0) {
                        totalWeeklyHours += dailyHours;
                        if (dailyHours > maxDailyHours) {
                            maxDailyHours = dailyHours;
                        }
                    }
                } catch (e) {
                    // Ignore invalid time formats during input
                }
            }
        });

        const rate = staff.rate; // Use frontend rate for limits shown to company
        const dailyLimit = maxDailyHours * rate;
        const weeklyLimit = totalWeeklyHours * rate;
        const monthlyLimit = weeklyLimit * 4;

        setCostLimits({
            daily: parseFloat(dailyLimit.toFixed(2)),
            weekly: parseFloat(weeklyLimit.toFixed(2)),
            monthly: parseFloat(monthlyLimit.toFixed(2)),
        });
    }, [timeLimits, staff.rate]);


    const days: DayOfWeek[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    const handleTimeLimitChange = (day: DayOfWeek, field: 'startTime' | 'endTime', value: string) => {
        let updated = [...timeLimits];
        const existing = updated.find(t => t.day === day);
        if (existing) {
            updated = updated.map(t => t.day === day ? { ...t, [field]: value } : t);
        } else {
            updated.push({ day, startTime: field === 'startTime' ? value : '', endTime: field === 'endTime' ? value : '' });
        }
        setTimeLimits(updated);
    };

    const handleDayToggle = (day: DayOfWeek, checked: boolean) => {
        let updated = [...timeLimits];
        if (checked) {
            if (!updated.some(t => t.day === day)) {
                updated.push({ day, startTime: '09:00', endTime: '17:00' });
            }
        } else {
            updated = updated.filter(t => t.day !== day);
        }
        setTimeLimits(updated.sort((a, b) => days.indexOf(a.day) - days.indexOf(b.day)));
    };

    const handleSaveRestrictions = () => {
        const updatedStaff = { ...staff, costLimits, timeLimits, isLocked };
        onStaffUpdate(updatedStaff);
        toast({ title: 'Restrictions Saved', description: `Work limits for ${staff.name} have been updated.` });
    };

    const convertAndFormatTime = (time: string, fromTz: string, toTz: string) => {
        if (!time) return '--:--';
        try {
            const today = new Date();
            const [hours, minutes] = time.split(':').map(Number);
            const sourceDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), hours, minutes);
            
            const zonedDate = fromZonedTime(sourceDate, fromTz);
            const targetDate = toZonedTime(zonedDate, toTz);

            return format(targetDate, 'HH:mm');
        } catch (e) {
            return 'Invalid';
        }
    };
    
    const handleLockToggle = (locked: boolean) => {
        setIsLocked(locked);
        const updatedStaff = { ...staff, isLocked: locked };
        onStaffUpdate(updatedStaff);
        toast({ 
            title: `Staff Member ${locked ? 'Locked' : 'Unlocked'}`, 
            description: `${staff.name} has been ${locked ? 'locked and cannot start new work' : 'unlocked and can resume work'}.`
        });
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Work Restrictions</CardTitle>
                <CardDescription>Set working hours and budget limits for {staff.name}.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-4 rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                         <Label htmlFor="lock-staff" className="flex flex-col space-y-1">
                            <span className="font-semibold text-base">Lock/Unlock Staff Member</span>
                            <span className="font-normal leading-snug text-muted-foreground">
                                Locking a staff member immediately prevents them from starting new tasks.
                            </span>
                        </Label>
                        <div className="flex items-center gap-2">
                             {isLocked ? <Lock className="h-5 w-5 text-destructive" /> : <Unlock className="h-5 w-5 text-green-500" />}
                            <Switch
                                id="lock-staff"
                                checked={isLocked}
                                onCheckedChange={handleLockToggle}
                            />
                        </div>
                    </div>
                </div>

                <div className="space-y-4 rounded-lg border p-4">
                    <h4 className="font-semibold">Cost Limits</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="daily-limit">Daily Limit (£)</Label>
                            <Input id="daily-limit" type="number" placeholder="e.g., 200" value={costLimits.daily ?? ''} readOnly />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="weekly-limit">Weekly Limit (£)</Label>
                            <Input id="weekly-limit" type="number" placeholder="e.g., 1000" value={costLimits.weekly ?? ''} readOnly />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="monthly-limit">Monthly Limit (£)</Label>
                            <Input id="monthly-limit" type="number" placeholder="e.g., 4000" value={costLimits.monthly ?? ''} readOnly />
                        </div>
                    </div>
                </div>
                <div className="space-y-4 rounded-lg border p-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-semibold">Allowed Working Hours</h4>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <span>Company Time ({companyTimezone.split('/')[1].replace('_', ' ')})</span>
                        <span>Staff Time ({staffTimezone.split('/')[1].replace('_', ' ')})</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                        {days.map(day => {
                            const limit = timeLimits.find(t => t.day === day);
                            return (
                                <div key={day} className="flex flex-col sm:flex-row items-center gap-4">
                                    <Checkbox id={`day-${day}`} checked={!!limit} onCheckedChange={(checked) => handleDayToggle(day, !!checked)} className="sm:mt-6" />
                                    <Label htmlFor={`day-${day}`} className="w-24 font-semibold">{day}</Label>
                                    <div className="grid grid-cols-2 gap-2 flex-1">
                                        <div className="space-y-1">
                                            <Label htmlFor={`start-${day}`} className="text-xs">Start Time</Label>
                                            <Input id={`start-${day}`} type="time" value={limit?.startTime || ''} onChange={e => handleTimeLimitChange(day, 'startTime', e.target.value)} disabled={!limit} />
                                             {limit?.startTime && <p className="text-xs text-muted-foreground">Staff time: {convertAndFormatTime(limit.startTime, companyTimezone, staffTimezone)}</p>}
                                        </div>
                                        <div className="space-y-1">
                                            <Label htmlFor={`end-${day}`} className="text-xs">End Time</Label>
                                            <Input id={`end-${day}`} type="time" value={limit?.endTime || ''} onChange={e => handleTimeLimitChange(day, 'endTime', e.target.value)} disabled={!limit} />
                                            {limit?.endTime && <p className="text-xs text-muted-foreground">Staff time: {convertAndFormatTime(limit.endTime, companyTimezone, staffTimezone)}</p>}
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </CardContent>
            <CardFooter>
                <Button onClick={handleSaveRestrictions}>Save Restrictions</Button>
            </CardFooter>
        </Card>
    );
}

function TeamMemberCard({ staff }: { staff: StaffMember }) {
    const SkillBar = ({ skill }: { skill: Skill }) => (
         <div>
            <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                    <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={skill.level === 'Expert' ? 100 : skill.level === 'Advanced' ? 80 : 60} className="h-2" />
        </div>
    );

    return (
        <Card>
            <CardHeader className="flex flex-row items-center gap-4">
                <Avatar className="h-16 w-16">
                    <AvatarImage src={staff.avatarUrl} />
                    <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                    <CardTitle>{staff.name}</CardTitle>
                    <CardDescription>{staff.role}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <h4 className="font-semibold text-sm mb-2">About</h4>
                    <p className="text-sm text-muted-foreground">{staff.about}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <h4 className="font-semibold text-sm mb-2">Technical Skills</h4>
                        <div className="space-y-2">
                            {staff.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold text-sm mb-2">Soft Skills</h4>
                        <div className="space-y-2">
                            {staff.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function StaffRow({ 
    staff, 
    isSelected, 
    onSelect, 
    hasNewActivity, 
    onStaffUpdate, 
    onUnHire, 
    activeCompany,
    allTasks,
    onTasksUpdate,
    onBalanceUpdate,
    onScheduleUpdate,
}: { 
    staff: StaffMember, 
    isSelected: boolean, 
    onSelect: (staff: StaffMember) => void, 
    hasNewActivity: boolean,
    onStaffUpdate: (updatedStaff: StaffMember) => void,
    onUnHire: (staffId: string) => void,
    activeCompany: Client | null,
    allTasks: StaffTasks,
    onTasksUpdate: (staffId: string, companyId: string, tasks: Task[]) => void,
    onBalanceUpdate: (newBalance: number) => void;
    onScheduleUpdate: () => void;
}) {
    const { toast } = useToast();
    const [tasks, setTasks] = useState<Task[]>([]);
    const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
    const [editingTask, setEditingTask] = useState<Task | null>(null);
    const [viewingTask, setViewingTask] = useState<Task | null>(null);
    const [commentingTask, setCommentingTask] = useState<Task | null>(null);
    const [newComment, setNewComment] = useState('');
    const [subTaskingTask, setSubTaskingTask] = useState<Task | null>(null);
    const [newSubTask, setNewSubTask] = useState('');
    const [isRewardDialogOpen, setIsRewardDialogOpen] = useState(false);
    const [scheduleRequest, setScheduleRequest] = useState<HourRequest | null>(null);

    useEffect(() => {
        if (activeCompany && allTasks[staff.id] && allTasks[staff.id][activeCompany.id]) {
            setTasks(allTasks[staff.id][activeCompany.id]);
        } else {
            setTasks([]);
        }
        
        const requests = getScheduleRequests();
        const requestKey = activeCompany ? `req_${activeCompany.id}_${staff.id}` : null;
        if (requestKey) {
            setScheduleRequest(requests[requestKey] || null);
        } else {
            setScheduleRequest(null);
        }

    }, [allTasks, staff.id, activeCompany]);
    

    const weeklyCost = useMemo(() => {
        if (!staff.timeLimits) return 0;
        let totalWeeklyHours = 0;
        staff.timeLimits.forEach(limit => {
            if (limit.startTime && limit.endTime) {
                try {
                    const start = parse(limit.startTime, 'HH:mm', new Date());
                    const end = parse(limit.endTime, 'HH:mm', new Date());
                    const dailyMilliseconds = differenceInMilliseconds(end, start);
                    if (dailyMilliseconds > 0) {
                        const dailyHours = dailyMilliseconds / (1000 * 60 * 60);
                        totalWeeklyHours += dailyHours;
                    }
                } catch (e) {
                    // Ignore parse errors for invalid time
                }
            }
        });
        return totalWeeklyHours * staff.rate;
    }, [staff.timeLimits, staff.rate]);

    const tasksByStatus = useMemo(() => ({
        'To Do': tasks.filter(t => t.status === 'To Do'),
        'In Progress': tasks.filter(t => t.status === 'In Progress'),
        'Done': tasks.filter(t => t.status === 'Done'),
        'Approved': tasks.filter(t => t.status === 'Approved'),
        'Paid': tasks.filter(t => t.status === 'Paid'),
    }), [tasks]);

    const updateAndSaveTasks = (newTasks: Task[]) => {
        if (!activeCompany) return;
        setTasks(newTasks);
        onTasksUpdate(staff.id, activeCompany.id, newTasks);
    };

    const handleSaveTask = (taskData: { title: string, details: string, dueDate?: Date, priority: TaskPriority }) => {
        let updatedTasks;
        if (editingTask) {
            updatedTasks = tasks.map(task => 
                task.id === editingTask.id ? { ...task, ...taskData } : task
            );
        } else {
            const newTask: Task = {
                id: `task-${Date.now()}`,
                ...taskData,
                status: 'To Do',
                hoursLogged: 0,
                comments: [],
                subTasks: [],
                cost: 0,
            };
            updatedTasks = [newTask, ...tasks];
        }
        updateAndSaveTasks(updatedTasks);
        toast({ title: 'Task Saved', description: 'Your changes have been saved.' });
        setIsTaskFormOpen(false);
        setEditingTask(null);
    };

    const openTaskForm = (task: Task | null) => {
        setEditingTask(task);
        setIsTaskFormOpen(true);
    };

    const handleDeleteTask = (taskId: string) => {
        const updatedTasks = tasks.filter(task => task.id !== taskId);
        updateAndSaveTasks(updatedTasks);
    };

    const handleApproveTask = (task: Task) => {
        if (!activeCompany) return;

        const updatedTasks = tasks.map(t => 
            t.id === task.id ? { ...t, status: 'Approved' as const } : t
        );
        updateAndSaveTasks(updatedTasks);
        
        toast({
            title: 'Task Approved',
            description: `Task "${task.title}" has been approved.`,
        });
    };
    
     const handleReward = (amount: number, note: string) => {
        if (!activeCompany) return;
        const currentBalance = activeCompany.cashBalance || 0;
        
        const newBalance = currentBalance - amount;
        onBalanceUpdate(newBalance);

        // Create a special 'Paid' task for the reward
        const rewardTask: Task = {
            id: `reward-${Date.now()}`,
            title: `Bonus from ${activeCompany.name}`,
            details: note || 'Bonus for excellent work.',
            status: 'Paid',
            priority: 'Medium',
            hoursLogged: 0,
            cost: amount,
            completionDate: new Date().toISOString(),
            comments: [],
            subTasks: [],
        };

        const allTasksForStaff = allTasks[staff.id] ? (allTasks[staff.id][activeCompany.id] || []) : [];
        const updatedTasks = [rewardTask, ...allTasksForStaff];
        updateAndSaveTasks(updatedTasks);

        toast({
            title: 'Reward Sent!',
            description: `You have sent a £${amount.toFixed(2)} bonus to ${staff.name}.`
        });
    };

    const handleAddComment = () => {
        if (!commentingTask || !newComment.trim() || !activeCompany) return;

        const comment: Comment = {
            id: `comment-${Date.now()}`,
            author: 'Admin', // In a real app, this would be the logged-in user's name
            text: newComment,
            timestamp: new Date().toISOString(),
        };

        const updatedTasks = tasks.map(task =>
            task.id === commentingTask.id
                ? { ...task, comments: [...(task.comments || []), comment] }
                : task
        );
        updateAndSaveTasks(updatedTasks);
        setNewComment('');
    };

    const handleAddSubTask = () => {
        if (!subTaskingTask || !newSubTask.trim() || !activeCompany) return;

        const subTask: SubTask = {
            id: `subtask-${Date.now()}`,
            title: newSubTask,
            completed: false,
        };

        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id
                ? { ...task, subTasks: [...(task.subTasks || []), subTask] }
                : task
        );
        
        updateAndSaveTasks(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: [...(prev.subTasks || []), subTask] } : null);
        setNewSubTask('');
    };

    const handleToggleSubTask = (subTaskId: string) => {
        if (!subTaskingTask || !activeCompany) return;

        const updatedSubTasks = (subTaskingTask.subTasks || []).map(st =>
            st.id === subTaskId ? { ...st, completed: !st.completed } : st
        );

        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id
                ? { ...task, subTasks: updatedSubTasks }
                : task
        );
        updateAndSaveTasks(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: updatedSubTasks } : null);
    };

    const handleReleasePayments = () => {
        if (!activeCompany) return;

        const totalToRelease = weeklyCost;
        
        if (totalToRelease > (activeCompany.cashBalance || 0)) {
            toast({
                variant: 'destructive',
                title: 'Insufficient Balance',
                description: `You need £${totalToRelease.toFixed(2)} but only have £${(activeCompany.cashBalance || 0).toFixed(2)}. Please top up your balance.`,
            });
            return;
        }
        
        const newBalance = (activeCompany.cashBalance || 0) - totalToRelease;
        onBalanceUpdate(newBalance);

        // Create a special 'Paid' task for the payment
        const paymentTask: Task = {
            id: `payment-${Date.now()}`,
            title: `Weekly Payment from ${activeCompany.name}`,
            details: `Weekly payment based on scheduled hours.`,
            status: 'Paid',
            priority: 'Medium',
            hoursLogged: 0,
            cost: totalToRelease,
            completionDate: new Date().toISOString(),
            comments: [],
            subTasks: [],
        };
        updateAndSaveTasks([paymentTask, ...tasks]);


        toast({
            title: 'Payments Released',
            description: `£${totalToRelease.toFixed(2)} has been released to ${staff.name}.`,
        });
    };
    
    const reopenTask = (task: Task) => {
        const updatedTasks = tasks.map(t =>
            t.id === task.id ? { ...t, status: 'To Do' as TaskStatus } : t
        );
        updateAndSaveTasks(updatedTasks);
        toast({
            title: 'Task Re-opened',
            description: `"${task.title}" has been moved back to the To Do list.`,
        });
    };


    const TaskCard = ({ task, isCompleted = false }: { task: Task; isCompleted?: boolean }) => {
        const priorityConfig = {
            High: { icon: Flag, color: "text-red-500" },
            Medium: { icon: Flag, color: "text-yellow-500" },
            Low: { icon: Flag, color: "text-gray-400" },
        }
        const PriorityIcon = priorityConfig[task.priority].icon;
        
        const completedSubTasks = (task.subTasks || []).filter(st => st.completed).length;
        const totalSubTasks = (task.subTasks || []).length;
        const subTaskProgress = totalSubTasks > 0 ? (completedSubTasks / totalSubTasks) * 100 : 0;

        return (
            <Card className="bg-background shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-4 space-y-3">
                    <div className="flex justify-between items-start">
                        <p className="font-semibold leading-tight">{task.title}</p>
                        <div className="flex items-center gap-1">
                             <PriorityIcon className={cn("h-4 w-4", priorityConfig[task.priority].color)} />
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openTaskForm(task)}>
                                <Edit className="h-4 w-4 text-muted-foreground" />
                             </Button>
                             <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleDeleteTask(task.id)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                             </Button>
                        </div>
                    </div>
                    {task.details && <p className="text-sm text-muted-foreground">{task.details}</p>}
                    
                    {totalSubTasks > 0 && (
                        <div className="space-y-1">
                            <div className="flex justify-between items-center text-xs text-muted-foreground">
                                <span>Checklist Progress</span>
                                <span>{completedSubTasks} / {totalSubTasks}</span>
                            </div>
                            <Progress value={subTaskProgress} className="h-2" />
                        </div>
                    )}

                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                        {task.dueDate && (
                            <div className="flex items-center gap-1.5">
                                <CalendarIcon className="h-4 w-4"/>
                                <span>{format(new Date(task.dueDate), 'dd MMM')}</span>
                            </div>
                        )}
                        
                         <div className="flex items-center gap-1">
                             <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setSubTaskingTask(task)}>
                                <ListChecks className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setCommentingTask(task)}>
                                <MessageSquare className="h-4 w-4" />
                                {task.comments?.length > 0 && (
                                    <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 justify-center p-0">{task.comments.length}</Badge>
                                )}
                            </Button>
                         </div>
                    </div>
                </CardContent>
                {isCompleted && (
                    <CardFooter className="p-2 border-t">
                        <Button size="sm" variant="outline" className="w-full" onClick={() => reopenTask(task)}>
                            <RotateCcw className="mr-2 h-4 w-4" />
                            Re-open Task
                        </Button>
                    </CardFooter>
                )}
            </Card>
        )
    }

    return (
        <tbody className={cn("border-b transition-colors", isSelected && "bg-muted")}>
            <TableRow onClick={() => onSelect(staff)} className="cursor-pointer">
                <TableCell className="font-medium w-[300px]">
                    <div className="flex items-center gap-3">
                        <Avatar>
                            <AvatarImage src={staff.avatarUrl} alt={staff.name} />
                            <AvatarFallback>{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div className="flex items-center gap-2">
                             {hasNewActivity && <span className="h-2 w-2 rounded-full bg-blue-500 animate-pulse"></span>}
                            <div>
                                <p className="font-medium">{staff.name}</p>
                                <p className="text-sm text-muted-foreground">{staff.location}</p>
                            </div>
                            {staff.isTeamLead && <Badge variant="outline" className="border-green-500 text-green-700">Team Lead</Badge>}
                            {staff.isLocked && <Badge variant="destructive"><Lock className="mr-2 h-3 w-3" /> Locked</Badge>}
                        </div>
                    </div>
                </TableCell>
                <TableCell>{staff.role}</TableCell>
                <TableCell>
                    <div className="font-mono">£{(staff.rate).toFixed(2)}/hr</div>
                </TableCell>
                <TableCell>
                    <div className="flex items-center gap-2 font-mono text-base font-semibold">
                        <span>£{weeklyCost.toFixed(2)}</span>
                    </div>
                </TableCell>
                <TableCell className="text-right">
                    {staff.isTeamLead && (
                        <Button variant="outline" size="sm" asChild onClick={e => e.stopPropagation()}>
                            <Link href={`/dashboard/messages?staffId=${staff.id}`}>
                                <MessageSquare className="mr-2 h-4 w-4" /> Message
                            </Link>
                        </Button>
                    )}
                </TableCell>
            </TableRow>
            {isSelected && activeCompany && (
                 <TableRow>
                    <TableCell colSpan={6} className="p-0">
                        <div className="bg-muted/50 p-6">
                            <Tabs defaultValue="board">
                                <div className="flex justify-between items-center mb-6">
                                    <div className="flex items-center gap-4">
                                        <TabsList>
                                            <TabsTrigger value="board">Task Board</TabsTrigger>
                                            <TabsTrigger value="project-team">Project Team</TabsTrigger>
                                            <TabsTrigger value="approval">For Approval <Badge className="ml-2">{tasksByStatus['Done'].length}</Badge></TabsTrigger>
                                             <TabsTrigger value="schedule-approval" className={cn(scheduleRequest && scheduleRequest.status === 'Pending Approval' && "bg-yellow-200 text-yellow-800 data-[state=active]:bg-yellow-400")}>
                                                Schedule for Approval
                                                {scheduleRequest && scheduleRequest.status === 'Pending Approval' && <Badge variant="destructive" className="ml-2">1</Badge>}
                                            </TabsTrigger>
                                            <TabsTrigger value="paid">Company Approved</TabsTrigger>
                                            <TabsTrigger value="payments">Payments</TabsTrigger>
                                            <TabsTrigger value="restrictions">Restrictions</TabsTrigger>
                                        </TabsList>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button variant="outline" onClick={() => setIsRewardDialogOpen(true)}>
                                            <Award className="mr-2 h-4 w-4" /> Reward Staff
                                        </Button>
                                        <Button variant="outline" onClick={() => onUnHire(staff.id)}>
                                            <UserMinus className="mr-2 h-4 w-4" /> Un-hire Professional
                                        </Button>
                                        <Button onClick={() => openTaskForm(null)}>
                                            <PlusCircle className="mr-2 h-4 w-4" /> Add New Task
                                        </Button>
                                    </div>
                                </div>
                                <TabsContent value="board">
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        {['To Do', 'In Progress', 'Done'].map((status) => (
                                            <div key={status} className="space-y-4 bg-card p-4 rounded-lg shadow-sm">
                                                <div className="flex items-center gap-2 px-2">
                                                    <h4 className="font-semibold text-lg">{status}</h4>
                                                    <Badge variant="secondary">{tasksByStatus[status as 'To Do' | 'In Progress' | 'Done'].length}</Badge>
                                                </div>
                                                <div className="space-y-4 rounded-lg p-2 min-h-[200px]">
                                                    {tasksByStatus[status as 'To Do' | 'In Progress' | 'Done'].length > 0 ? tasksByStatus[status as 'To Do' | 'In Progress' | 'Done'].map(task => <TaskCard key={task.id} task={task} />) : <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-32 flex items-center justify-center">No tasks here.</div>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </TabsContent>
                                <TabsContent value="project-team">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                         <TeamMemberCard staff={staff} />
                                    </div>
                                </TabsContent>
                                <TabsContent value="payments">
                                    <PaymentsTab staff={staff} tasks={tasks} onReleasePayments={handleReleasePayments} />
                                </TabsContent>
                                <TabsContent value="restrictions">
                                    <RestrictionsManager staff={staff} onStaffUpdate={onStaffUpdate} />
                                </TabsContent>
                                 <TabsContent value="schedule-approval">
                                    <ScheduleApproval staff={staff} company={activeCompany} onScheduleUpdate={onScheduleUpdate} />
                                </TabsContent>
                                <TabsContent value="approval">
                                    <Card>
                                        <CardHeader>
                                            <CardTitle>Completed Tasks for Approval</CardTitle>
                                            <CardDescription>Review completed tasks and approve them.</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            {tasksByStatus['Done'].length > 0 ? (
                                                <Table>
                                                    <TableHeader>
                                                        <TableRow>
                                                            <TableHead>Completed Date</TableHead>
                                                            <TableHead>Task</TableHead>
                                                            <TableHead className="text-center">Actions</TableHead>
                                                        </TableRow>
                                                    </TableHeader>
                                                    <TableBody>
                                                        {tasksByStatus['Done'].map(task => (
                                                            <TableRow key={task.id}>
                                                                <TableCell>{task.completionDate ? format(new Date(task.completionDate), 'dd MMM yyyy, HH:mm') : 'N/A'}</TableCell>
                                                                <TableCell>{task.title}</TableCell>
                                                                <TableCell className="text-center space-x-2">
                                                                    <Button size="sm" onClick={() => handleApproveTask(task)}>
                                                                        <ThumbsUp className="mr-2 h-4 w-4" /> Approve This Task
                                                                    </Button>
                                                                    <Button variant="ghost" size="icon" onClick={() => setViewingTask(task)}><Eye className="h-4 w-4"/></Button>
                                                                </TableCell>
                                                            </TableRow>
                                                        ))}
                                                    </TableBody>
                                                </Table>
                                            ) : (
                                                <div className="text-center p-8 text-muted-foreground">
                                                    No tasks are awaiting approval.
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                </TabsContent>
                                 <TabsContent value="paid">
                                     <Card>
                                        <CardHeader>
                                            <CardTitle>Approved Tasks</CardTitle>
                                            <CardDescription>A log of all tasks that have been approved.</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            {[...tasksByStatus['Paid'], ...tasksByStatus['Approved']].length > 0 ? (
                                                <Table>
                                                    <TableHeader>
                                                        <TableRow>
                                                            <TableHead>Completed Date</TableHead>
                                                            <TableHead>Task</TableHead>
                                                            <TableHead>Status</TableHead>
                                                        </TableRow>
                                                    </TableHeader>
                                                    <TableBody>
                                                        {[...tasksByStatus['Paid'], ...tasksByStatus['Approved']].sort((a,b) => new Date(b.completionDate || 0).getTime() - new Date(a.completionDate || 0).getTime()).map(task => (
                                                            <TableRow key={task.id}>
                                                                <TableCell>{task.completionDate ? format(new Date(task.completionDate), 'dd MMM yyyy, HH:mm') : 'N/A'}</TableCell>
                                                                <TableCell>{task.title}</TableCell>
                                                                <TableCell><Badge variant={task.status === 'Paid' ? 'default' : 'outline'} className={cn(task.status === 'Paid' && 'bg-green-500')}>{task.status}</Badge></TableCell>
                                                            </TableRow>
                                                        ))}
                                                    </TableBody>
                                                </Table>
                                            ) : (
                                                <div className="text-center p-8 text-muted-foreground">
                                                    No tasks have been approved yet.
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                </TabsContent>
                            </Tabs>
                        </div>
                    </TableCell>
                </TableRow>
            )}
             {/* Dialogs */}
            <TaskFormDialog 
                open={isTaskFormOpen} 
                onOpenChange={setIsTaskFormOpen} 
                task={editingTask}
                onSave={handleSaveTask}
            />
            {activeCompany && (
                 <RewardDialog
                    open={isRewardDialogOpen}
                    onOpenChange={setIsRewardDialogOpen}
                    onReward={handleReward}
                    staffName={staff.name}
                    clientBalance={activeCompany.cashBalance || 0}
                />
            )}
            <Dialog open={!!viewingTask} onOpenChange={() => setViewingTask(null)}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Task Details: {viewingTask?.title}</DialogTitle></DialogHeader>
                    {viewingTask && <div className="py-4 space-y-4">...</div>}
                    <DialogFooter><Button onClick={() => setViewingTask(null)}>Close</Button></DialogFooter>
                </DialogContent>
            </Dialog>
            <Dialog open={!!commentingTask} onOpenChange={() => setCommentingTask(null)}>
                <DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Comments for "{commentingTask?.title}"</DialogTitle></DialogHeader>
                    <div className="py-4 space-y-4">
                        <ScrollArea className="h-72 w-full rounded-md border p-4">
                            {(commentingTask?.comments || []).length > 0 ? (
                                <div className="space-y-4">{(commentingTask?.comments || []).map(comment => <div key={comment.id} className="flex gap-2.5"><Avatar className="h-8 w-8"><AvatarFallback>{comment.author.charAt(0)}</AvatarFallback></Avatar><div className="grid w-full"><div className="flex items-center gap-2"><p className="font-semibold text-sm">{comment.author}</p><p className="text-xs text-muted-foreground">{format(new Date(comment.timestamp), 'dd MMM, p')}</p></div><p className="text-sm text-muted-foreground">{comment.text}</p></div></div>)}</div>
                            ) : (<p className="text-center text-muted-foreground py-12">No comments yet.</p>)}
                        </ScrollArea>
                         <div className="space-y-2"><Label htmlFor="new-comment">Add a comment</Label><Textarea id="new-comment" value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Write a comment..." /></div>
                    </div>
                    <DialogFooter><Button variant="outline" onClick={() => setCommentingTask(null)}>Close</Button><Button onClick={handleAddComment} disabled={!newComment.trim()}>Post Comment</Button></DialogFooter>
                </DialogContent>
            </Dialog>
            <Dialog open={!!subTaskingTask} onOpenChange={() => setSubTaskingTask(null)}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Checklist for "{subTaskingTask?.title}"</DialogTitle><DialogDescription>Add, edit, and complete sub-tasks.</DialogDescription></DialogHeader>
                    <div className="py-4 space-y-4"><form onSubmit={(e) => { e.preventDefault(); handleAddSubTask(); }} className="flex gap-2"><Input value={newSubTask} onChange={(e) => setNewSubTask(e.target.value)} placeholder="Add a new sub-task..." /><Button type="submit" disabled={!newSubTask.trim()}>Add</Button></form><ScrollArea className="h-60 w-full rounded-md border p-2"><div className="space-y-2 p-2">{(subTaskingTask?.subTasks || []).length > 0 ? ((subTaskingTask?.subTasks || []).map(st => <div key={st.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted"><Checkbox id={st.id} checked={st.completed} onCheckedChange={() => handleToggleSubTask(st.id)} /><Label htmlFor={st.id} className={cn("flex-1", st.completed && "line-through text-muted-foreground")}>{st.title}</Label></div>)) : (<p className="text-center text-muted-foreground py-8">No sub-tasks yet.</p>)}</div></ScrollArea></div>
                </DialogContent>
            </Dialog>
        </tbody>
    )
}

export default function HiredStaffPage() {
    const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
    const [openStaffIds, setOpenStaffIds] = useState<string[]>([]);
    const [activityTimestamps, setActivityTimestamps] = useState<Record<string, string>>({});
    const { activeClient, isClientInitialised, setActiveClient } = useActiveClient();
    const { toast } = useToast();
    const [clients, setClients] = useState<Client[]>([]);

    const [allTasks, setAllTasks] = useState<StaffTasks>({});

    const fetchHiredStaff = useCallback(() => {
        let clientData: Client[];
        try {
            const storedClients = localStorage.getItem('clients');
            clientData = storedClients ? JSON.parse(storedClients) : (initialClientsData as Client[]);
        } catch(e) {
            clientData = initialClientsData as Client[];
        }
        setClients(clientData);

        let staffData: StaffMember[];
        try {
            const storedStaff = localStorage.getItem('hubStaff');
            staffData = storedStaff ? JSON.parse(storedStaff) : initialStaff;
        } catch(e) {
            staffData = initialStaff;
        }
        setAllStaff(staffData);

        let taskData: StaffTasks;
        try {
            const storedTasks = localStorage.getItem('staffTasks');
            taskData = storedTasks ? JSON.parse(storedTasks) : {};
        } catch (e) {
            taskData = {};
        }
        setAllTasks(taskData);

    }, []);

    const refreshData = useCallback(() => {
        fetchHiredStaff();
    }, [fetchHiredStaff]);


    useEffect(() => {
        fetchHiredStaff();
        
        const timestamps: Record<string, string> = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('lastActivity_') || key.startsWith('lastViewed_'))) {
                timestamps[key] = localStorage.getItem(key)!;
            }
        }
        setActivityTimestamps(timestamps);

         const handleStorageChange = (e: StorageEvent) => {
            fetchHiredStaff();
            if (e.key && (e.key.startsWith('lastActivity_') || e.key.startsWith('lastViewed_'))) {
                setActivityTimestamps(prev => ({...prev, [e.key!]: e.newValue!}));
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }, [fetchHiredStaff]);
    
    const { currentlyHired, previouslyHired } = useMemo(() => {
        if (!activeClient) return { currentlyHired: [], previouslyHired: [] };
        
        const projectTeamIds = new Set(activeClient.allocatedStaffIds || []);
        if (activeClient.assignedTeamLeadId) {
            projectTeamIds.add(activeClient.assignedTeamLeadId);
        }
        
        let hiredForThisClient = allStaff.filter(staff => projectTeamIds.has(staff.id));
        
        // Sort to put the Team Lead at the top
        hiredForThisClient.sort((a, b) => {
            if (a.id === activeClient.assignedTeamLeadId) return -1;
            if (b.id === activeClient.assignedTeamLeadId) return 1;
            return a.name.localeCompare(b.name);
        });

        const previouslyHiredStaff = allStaff.filter(staff => 
            (staff.hiredByHistory || []).includes(activeClient.id) && 
            !projectTeamIds.has(staff.id)
        );
        return { currentlyHired: hiredForThisClient, previouslyHired: previouslyHiredStaff };
    }, [allStaff, activeClient]);

    useEffect(() => {
        if (currentlyHired.length > 0) {
            setOpenStaffIds(prevOpen => {
                if (prevOpen.length === 0) {
                    return [currentlyHired[0].id];
                }
                return prevOpen;
            });
        }
    }, [currentlyHired]);


    const handleTasksUpdate = (staffId: string, companyId: string, updatedTasks: Task[]) => {
        const newAllTasks = { 
            ...allTasks, 
            [staffId]: {
                ...allTasks[staffId],
                [companyId]: updatedTasks
            }
        };
        setAllTasks(newAllTasks);
        localStorage.setItem('staffTasks', JSON.stringify(newAllTasks));
        window.dispatchEvent(new StorageEvent('storage', { key: 'staffTasks', newValue: JSON.stringify(newAllTasks) }));
    };

    const handleToggleStaff = (staff: StaffMember) => {
        setOpenStaffIds(prev => 
            prev.includes(staff.id) 
                ? prev.filter(id => id !== staff.id) 
                : [staff.id] // Only allow one to be open at a time
        );
        
        if (!openStaffIds.includes(staff.id)) {
             const now = new Date().toISOString();
             localStorage.setItem(`lastViewed_${staff.id}`, now);
             setActivityTimestamps(prev => ({...prev, [`lastViewed_${staff.id}`]: now}));
        }
    };

    const handleStaffUpdate = (updatedStaff: StaffMember) => {
        const updatedList = allStaff.map(s => s.id === updatedStaff.id ? updatedStaff : s);
        setAllStaff(updatedList);
        localStorage.setItem('hubStaff', JSON.stringify(updatedList));
        window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff', newValue: JSON.stringify(updatedList)}));
    };
    
    const handleUnHire = (staffId: string) => {
        const staffToUnHire = allStaff.find(s => s.id === staffId);
        if (!staffToUnHire || !activeClient) return;

        const updatedStaffMember: StaffMember = {
            ...staffToUnHire,
            hiredBy: Array.isArray(staffToUnHire.hiredBy) ? staffToUnHire.hiredBy.filter(id => id !== activeClient.id) : [],
            availability: 'Available For Hire',
            hiredByHistory: [...(staffToUnHire.hiredByHistory || []), activeClient.id]
        };
        if(updatedStaffMember.hiredBy?.length === 0) {
            updatedStaffMember.hiredBy = null;
        }

        const updatedList = allStaff.map(s => s.id === staffId ? updatedStaffMember : s);
        setAllStaff(updatedList);
        localStorage.setItem('hubStaff', JSON.stringify(updatedList));
        window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff', newValue: JSON.stringify(updatedList)}));
        
        toast({
            title: "Professional Un-hired",
            description: `${staffToUnHire.name} is no longer assigned to your company.`,
        });
    }

    const handleReHire = (staff: StaffMember) => {
        if (!activeClient) return;
        
        const isHiredBySomeoneElse = staff.hiredBy && staff.hiredBy.length > 0;

        if (staff.availability !== 'Available For Hire' && isHiredBySomeoneElse) {
            toast({
                variant: 'destructive',
                title: 'Cannot Re-hire',
                description: `${staff.name} is currently hired by another company.`,
            });
            return;
        }

        const updatedStaffMember: StaffMember = {
            ...staff,
            hiredBy: [...(staff.hiredBy || []), activeClient.id],
            availability: 'Currently Hired',
        };

        const updatedList = allStaff.map(s => s.id === staff.id ? updatedStaffMember : s);
        setAllStaff(updatedList);
        localStorage.setItem('hubStaff', JSON.stringify(updatedList));
        window.dispatchEvent(new StorageEvent('storage', { key: 'hubStaff', newValue: JSON.stringify(updatedList)}));
        
        toast({
            title: 'Professional Re-hired!',
            description: `${staff.name} is now active for your company again.`,
        });
    };

    const handleBalanceUpdate = (newBalance: number) => {
        if (!activeClient) return;

        const updatedClient = { ...activeClient, cashBalance: newBalance };
        
        const allClients = JSON.parse(localStorage.getItem('clients') || '[]') as Client[];
        const updatedClients = allClients.map(c => c.id === activeClient.id ? updatedClient : c);
        localStorage.setItem('clients', JSON.stringify(updatedClients));
        window.dispatchEvent(new StorageEvent('storage', { key: 'clients', newValue: JSON.stringify(updatedClients)}));

        // This will also trigger the active client hook to update itself
        setActiveClient(updatedClient);
    }
    
    if (!isClientInitialised) {
        return <div>Loading client data...</div>;
    }

    if (!activeClient) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>No Active Client</CardTitle>
                    <CardDescription>Please select a client from your client list to manage their hired staff.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <p className="text-muted-foreground">This page is for managing staff hired by a specific company. If you are a Super Admin, please select a company to view their hired staff or manage staff profiles in the <Link href="/dashboard/super-admin/staff" className="underline">Staff Hub Management</Link> page.</p>
                </CardContent>
            </Card>
        );
    }
    
    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Current Projects & Hired Staff for {activeClient.name}</CardTitle>
                    <CardDescription>Manage the professionals you've hired and assign them tasks.</CardDescription>
                </CardHeader>
                <CardContent>
                     <ProjectUpdates company={activeClient} />
                    {currentlyHired.length > 0 ? (
                        <div className="border rounded-lg mt-6">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-[300px]">Professional</TableHead>
                                        <TableHead>Role</TableHead>
                                        <TableHead>Staff Rate</TableHead>
                                        <TableHead>Weekly Cost</TableHead>
                                        <TableHead className="text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                {currentlyHired.map(staff => {
                                    const lastActivity = activityTimestamps[`lastActivity_${staff.id}`];
                                    const lastViewed = activityTimestamps[`lastViewed_${staff.id}`];
                                    const hasNewActivity = lastActivity && (!lastViewed || new Date(lastActivity) > new Date(lastViewed));

                                    return (
                                        <StaffRow 
                                            key={staff.id} 
                                            staff={staff} 
                                            isSelected={openStaffIds.includes(staff.id)}
                                            onSelect={handleToggleStaff}
                                            hasNewActivity={!!hasNewActivity}
                                            onStaffUpdate={handleStaffUpdate}
                                            onUnHire={handleUnHire}
                                            activeCompany={activeClient}
                                            allTasks={allTasks}
                                            onTasksUpdate={handleTasksUpdate}
                                            onBalanceUpdate={handleBalanceUpdate}
                                            onScheduleUpdate={refreshData}
                                        />
                                    );
                                })}
                            </Table>
                        </div>
                    ) : (
                        <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                            <p>You haven't hired any staff for {activeClient.name} yet.</p>
                            <Button asChild variant="link">
                                <Link href="/dashboard/staff-hub">Find a Professional to Hire</Link>
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>

             <Collapsible>
                <CollapsibleTrigger asChild>
                    <Button variant="link">Show/Hide Previously Hired ({previouslyHired.length})</Button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                    <Card className="mt-2">
                        <CardHeader>
                            <CardTitle>Previously Hired</CardTitle>
                            <CardDescription>A list of professionals you have worked with in the past.</CardDescription>
                        </CardHeader>
                        <CardContent>
                             {previouslyHired.length > 0 ? (
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Name</TableHead>
                                            <TableHead>Role</TableHead>
                                            <TableHead>Availability</TableHead>
                                            <TableHead className="text-right">Actions</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {previouslyHired.map(staff => (
                                            <TableRow key={staff.id}>
                                                <TableCell>{staff.name}</TableCell>
                                                <TableCell>{staff.role}</TableCell>
                                                <TableCell>
                                                    <Badge variant={staff.availability === 'Available For Hire' ? 'default' : 'secondary'} className={cn(staff.availability === 'Available For Hire' && 'bg-green-500')}>
                                                        {staff.availability}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell className="text-right">
                                                    <Button 
                                                        size="sm" 
                                                        onClick={() => handleReHire(staff)}
                                                        disabled={staff.availability !== 'Available For Hire'}
                                                    >
                                                        Re-hire
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            ) : (
                                <p className="text-muted-foreground">No previously hired staff.</p>
                            )}
                        </CardContent>
                    </Card>
                </CollapsibleContent>
            </Collapsible>
        </div>
    );
}

function ProjectUpdates({ company }: { company: Client }) {
    if (!company.projectUpdates || company.projectUpdates.length === 0) {
        return null;
    }

    return (
        <Card className="mb-6 bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-700">
            <CardHeader>
                <CardTitle className="text-blue-800 dark:text-blue-300">Project Updates</CardTitle>
                <CardDescription>Latest updates from your Team Manager.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4 max-h-48 overflow-y-auto">
                    {company.projectUpdates.map(update => (
                        <div key={update.id} className="text-sm">
                             <p className="text-muted-foreground">
                                <span className="font-semibold text-foreground">{update.author}</span> posted {formatDistanceToNow(new Date(update.date), { addSuffix: true })}
                            </p>
                            <p>{update.content}</p>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}


function TaskFormDialog({ open, onOpenChange, task, onSave }: { open: boolean; onOpenChange: (open: boolean) => void; task: Task | null, onSave: (taskData: { title: string, details: string, dueDate?: Date, priority: TaskPriority }) => void }) {
    const [title, setTitle] = useState('');
    const [details, setDetails] = useState('');
    const [dueDate, setDueDate] = useState<Date | undefined>();
    const [priority, setPriority] = useState<TaskPriority>('Medium');

    useEffect(() => {
        if (task) {
            setTitle(task.title);
            setDetails(task.details);
            setDueDate(task.dueDate ? new Date(task.dueDate) : undefined);
            setPriority(task.priority);
        } else {
            setTitle('');
            setDetails('');
            setDueDate(undefined);
            setPriority('Medium');
        }
    }, [task, open]);

    const handleSaveClick = () => {
        onSave({ title, details, dueDate, priority });
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader><DialogTitle>{task ? 'Edit Task' : 'Add New Task'}</DialogTitle></DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2"><Label htmlFor="task-title">Task Title</Label><Input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
                    <div className="space-y-2"><Label htmlFor="task-details">Details</Label><Textarea id="task-details" value={details} onChange={(e) => setDetails(e.target.value)} /></div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2"><Label>Due Date</Label><Popover><PopoverTrigger asChild><Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !dueDate && "text-muted-foreground")}><CalendarIcon className="mr-2 h-4 w-4" />{dueDate ? format(new Date(dueDate), "PPP") : <span>Pick a date</span>}</Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar mode="single" selected={dueDate} onSelect={setDueDate} initialFocus /></PopoverContent></Popover></div>
                        <div className="space-y-2"><Label>Priority</Label><Select value={priority} onValueChange={(v: TaskPriority) => setPriority(v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="High">High</SelectItem><SelectItem value="Medium">Medium</SelectItem><SelectItem value="Low">Low</SelectItem></SelectContent></Select></div>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSaveClick}>Save Task</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}



    






