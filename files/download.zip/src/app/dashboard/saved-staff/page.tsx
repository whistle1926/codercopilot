
"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { initialStaff as initialStaffData } from '@/lib/data';
import type { StaffMember } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Award, Briefcase, MessageSquare } from 'lucide-react';
import Link from 'next/link';
import { useActiveClient } from '@/hooks/use-active-client';

function StaffCard({ staff, onRemove }: { staff: StaffMember, onRemove: (staffId: string) => void }) {
    const isMtdCertified = staff.technicalSkills.some(skill => skill.name === 'MTD Simple Certified');

    return (
        <Card>
            <CardContent className="p-6">
                <div className="flex items-start gap-4">
                    <Avatar className="h-16 w-16">
                        <AvatarImage src={staff.avatarUrl} alt={staff.name} />
                        <AvatarFallback>{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-xl font-bold">{staff.name}</h3>
                                <Badge variant="secondary" className="text-base">{staff.role}</Badge>
                            </div>
                            <Button variant="destructive" size="sm" onClick={() => onRemove(staff.id)}>
                                Remove
                            </Button>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{staff.location}</p>
                        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
                            {staff.verified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> Staff Hub Pro Verified</div>}
                            {isMtdCertified && <div className="flex items-center gap-1 font-semibold text-primary"><CheckCircle className="h-4 w-4" /> MTD Simple Approved</div>}
                            {staff.premium && <div className="flex items-center gap-1 font-semibold text-amber-500"><Award className="h-4 w-4" /> Top Rated By Employers</div>}
                        </div>
                    </div>
                </div>
                <div className="mt-4 flex gap-2">
                    <Button className="w-full" asChild>
                        <Link href="/dashboard/staff-hub">
                            <Briefcase className="mr-2 h-4 w-4" /> Hire
                        </Link>
                    </Button>
                    <Button className="w-full" variant="outline" asChild>
                        <Link href={`/dashboard/messages?staffId=${staff.id}`}>
                            <MessageSquare className="mr-2 h-4 w-4" /> Message
                        </Link>
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}

export default function SavedStaffPage() {
    const [savedStaff, setSavedStaff] = useState<StaffMember[]>([]);
    const { activeClient } = useActiveClient();

    const loadSavedStaff = useCallback(() => {
        if (activeClient) {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const savedIds: string[] = JSON.parse(localStorage.getItem(`saved_staff_${activeClient.id}`) || '[]');
            const saved = allStaff.filter(s => savedIds.includes(s.id));
            setSavedStaff(saved);
        }
    }, [activeClient]);

    useEffect(() => {
        loadSavedStaff();
        window.addEventListener('storage', loadSavedStaff);
        return () => window.removeEventListener('storage', loadSavedStaff);
    }, [loadSavedStaff]);

    const handleRemove = (staffId: string) => {
        if (activeClient) {
            const savedIds: string[] = JSON.parse(localStorage.getItem(`saved_staff_${activeClient.id}`) || '[]');
            const updatedIds = savedIds.filter(id => id !== staffId);
            localStorage.setItem(`saved_staff_${activeClient.id}`, JSON.stringify(updatedIds));
            loadSavedStaff();
        }
    };
    
    if (!activeClient) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle>Saved Staff</CardTitle>
                    <CardDescription>You need to be logged in as a company to view saved staff.</CardDescription>
                </CardHeader>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Saved Staff</CardTitle>
                <CardDescription>A list of professionals you've saved for future consideration.</CardDescription>
            </CardHeader>
            <CardContent>
                {savedStaff.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {savedStaff.map(staff => (
                            <StaffCard key={staff.id} staff={staff} onRemove={handleRemove} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12 text-muted-foreground border-2 border-dashed rounded-lg">
                        <p>You haven't saved any staff members yet.</p>
                        <Button asChild variant="link">
                            <Link href="/dashboard/staff-hub">Browse Professionals</Link>
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
