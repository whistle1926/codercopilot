
"use client";

import dynamic from 'next/dynamic';

const MessagesClientPage = dynamic(
    () => import('./components/messages-client-page'),
    { ssr: false }
);

export default function MessagesPage() {
    return <MessagesClientPage />;
}
