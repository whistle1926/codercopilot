
"use client";

import { useState, useEffect } from 'react';
import { initialStaff } from '@/lib/data';
import type { StaffMember } from '@/lib/types';
import { ChatInterface } from './chat-interface';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useSearchParams } from 'next/navigation';
import { useActiveClient } from '@/hooks/use-active-client';

export default function MessagesClientPage() {
    const searchParams = useSearchParams();
    const staffId = searchParams.get('staffId');
    const [staffList, setStaffList] = useState<StaffMember[]>([]);
    const { activeClient } = useActiveClient();

    const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);

    useEffect(() => {
        // Load staff from localStorage
        const storedStaff = localStorage.getItem('hubStaff');
        const allStaff = storedStaff ? JSON.parse(storedStaff) : initialStaff;

        let relevantStaff = allStaff;
        if (activeClient) {
            relevantStaff = allStaff.filter((s: StaffMember) => s.hiredBy?.includes(activeClient.id));
        }
        
        setStaffList(relevantStaff);

        if (staffId) {
            setSelectedStaff(relevantStaff.find((s: StaffMember) => s.id === staffId) || relevantStaff[0] || null);
        } else if (relevantStaff.length > 0) {
            setSelectedStaff(relevantStaff[0]);
        }
    }, [staffId, activeClient]);

    return (
        <div className="h-[calc(100vh-10rem)]">
             <Card>
                <CardHeader>
                    <CardTitle>Messages</CardTitle>
                    <CardDescription>Communicate with professionals before and after hiring.</CardDescription>
                </CardHeader>
            </Card>
            <ChatInterface 
                staffList={staffList} 
                selectedStaff={selectedStaff}
                onSelectStaff={setSelectedStaff}
            />
        </div>
    );
}
