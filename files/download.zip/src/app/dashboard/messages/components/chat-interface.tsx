
"use client";

import { useState, useRef, useEffect } from 'react';
import type { StaffMember, Client, ChatMessage, UserStatus } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, Search, MoreHorizontal, Edit, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { useActiveClient } from '@/hooks/use-active-client';
import { initialConversations } from '@/lib/data';
import { Badge } from '@/components/ui/badge';

const statusColors: Record<UserStatus, string> = {
    Online: 'bg-green-500',
    Offline: 'bg-gray-500',
    Busy: 'bg-yellow-500',
};

export function ChatInterface({ staffList, selectedStaff, onSelectStaff }: { staffList: StaffMember[], selectedStaff: StaffMember | null, onSelectStaff: (staff: StaffMember) => void }) {
  const [conversations, setConversations] = useState<Record<string, ChatMessage[]>>({});
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { activeClient } = useActiveClient();
  
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null);
  const [editedText, setEditedText] = useState('');
  const [deletingMessageId, setDeletingMessageId] = useState<string | null>(null);

  const getConversationKey = (staffId: string, clientId: string) => `staff-${staffId}_client-${clientId}`;

  useEffect(() => {
    const loadConversations = () => {
      try {
          const storedConversations = localStorage.getItem('chatConversations');
          if (storedConversations) {
              setConversations(JSON.parse(storedConversations));
          } else {
              setConversations(initialConversations);
          }
      } catch (error) {
          console.error("Failed to load conversations from localStorage", error);
          setConversations(initialConversations);
      }
    };
    
    loadConversations();
    window.addEventListener('storage', loadConversations);
    return () => window.removeEventListener('storage', loadConversations);
  }, []);

  const saveConversations = (newConversations: Record<string, ChatMessage[]>) => {
    setConversations(newConversations);
    localStorage.setItem('chatConversations', JSON.stringify(newConversations));
    window.dispatchEvent(new StorageEvent('storage', { key: 'chatConversations', newValue: JSON.stringify(newConversations) }));
  };

  const conversationKey = selectedStaff && activeClient ? getConversationKey(selectedStaff.id, activeClient.id) : null;
  const currentConversation = conversationKey ? conversations[conversationKey] || [] : [];
  
  const filteredStaffList = staffList.filter(staff => staff.name.toLowerCase().includes(searchTerm.toLowerCase()));

  useEffect(() => {
    if (!editingMessage) {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentConversation, editingMessage]);
  
  useEffect(() => {
    // Mark messages as read when a conversation is opened
    if (conversationKey && conversations[conversationKey]) {
      let hasUnread = false;
      const updatedConversation = conversations[conversationKey].map(msg => {
        if (msg.sender === 'staff' && !msg.read) {
          hasUnread = true;
          return { ...msg, read: true };
        }
        return msg;
      });

      if (hasUnread) {
        saveConversations({
          ...conversations,
          [conversationKey]: updatedConversation,
        });
      }
    }
  }, [conversationKey, conversations]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !conversationKey || !activeClient) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: activeClient.id,
      sender: 'user',
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
    };

    const updatedConversation = [...currentConversation, newMsg];
    saveConversations({
      ...conversations,
      [conversationKey]: updatedConversation,
    });
    setNewMessage('');
  };
  
  const handleEdit = (message: ChatMessage) => {
    setEditingMessage(message);
    setEditedText(message.text);
  };
  
  const handleCancelEdit = () => {
    setEditingMessage(null);
    setEditedText('');
  };

  const handleSaveEdit = () => {
    if (!editingMessage || !conversationKey) return;
    
    const updatedConversation = currentConversation.map(msg => 
        msg.id === editingMessage.id ? { ...msg, text: editedText, timestamp: `${msg.timestamp} (edited)` } : msg
    );

    saveConversations({
        ...conversations,
        [conversationKey]: updatedConversation
    });

    handleCancelEdit();
  };
  
  const handleDelete = () => {
    if (!deletingMessageId || !conversationKey) return;
    
    const updatedConversation = currentConversation.filter(msg => msg.id !== deletingMessageId);
    
    saveConversations({
        ...conversations,
        [conversationKey]: updatedConversation
    });

    setDeletingMessageId(null);
  };

  return (
    <div className="flex h-full border rounded-lg mt-4">
      <div className="w-1/3 border-r flex flex-col">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search contacts..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <ScrollArea className="flex-1">
          {filteredStaffList.map(staff => {
            const convKey = activeClient ? getConversationKey(staff.id, activeClient.id) : null;
            const conversation = convKey ? conversations[convKey] || [] : [];
            const lastMessage = conversation.length > 0 ? conversation[conversation.length - 1] : null;
            const hasUnread = conversation.some(msg => msg.sender === 'staff' && !msg.read);

            return (
              <div
                key={staff.id}
                className={cn(
                  "flex items-center gap-4 p-4 cursor-pointer hover:bg-muted",
                  selectedStaff?.id === staff.id && 'bg-muted'
                )}
                onClick={() => onSelectStaff(staff)}
              >
                <div className="relative">
                  <Avatar>
                    <AvatarImage src={staff.avatarUrl} alt={staff.name} />
                    <AvatarFallback>{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <span className={cn(
                      "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-background",
                      statusColors[staff.status]
                  )} />
                </div>
                <div className="flex-1 overflow-hidden flex items-center justify-between">
                    <div>
                        <p className="font-semibold">{staff.name}</p>
                        <p className="text-sm text-muted-foreground truncate">
                            {lastMessage?.text || 'No messages yet'}
                        </p>
                    </div>
                    {hasUnread && <div className="h-2.5 w-2.5 rounded-full bg-blue-500 shrink-0" />}
                </div>
              </div>
            )
          })}
        </ScrollArea>
      </div>

      <div className="w-2/3 flex flex-col">
        {selectedStaff && activeClient ? (
          <>
            <div className="p-4 border-b flex items-center gap-4">
              <div className="relative">
                <Avatar>
                  <AvatarImage src={selectedStaff.avatarUrl} alt={selectedStaff.name} />
                  <AvatarFallback>{selectedStaff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <span className={cn(
                    "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-background",
                    statusColors[selectedStaff.status]
                )} />
              </div>
              <div>
                  <p className="font-semibold">{selectedStaff.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedStaff.role}</p>
              </div>
            </div>

            <ScrollArea className="flex-1 p-6 space-y-4 bg-gray-50 dark:bg-gray-900/50">
              {currentConversation.map(msg => (
                <div key={msg.id} className={cn("flex items-end gap-2 group", msg.sender === 'user' && 'justify-end')}>
                  {msg.sender === 'staff' && (
                    <Avatar className="h-8 w-8">
                       <AvatarImage src={selectedStaff.avatarUrl} />
                       <AvatarFallback>{selectedStaff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                  )}
                  {msg.id === editingMessage?.id ? (
                      <div className="flex-1 max-w-lg">
                          <Textarea 
                            value={editedText}
                            onChange={(e) => setEditedText(e.target.value)}
                            className="bg-white"
                          />
                          <div className="flex justify-end gap-2 mt-2">
                              <Button size="sm" variant="ghost" onClick={handleCancelEdit}>Cancel</Button>
                              <Button size="sm" onClick={handleSaveEdit}>Save</Button>
                          </div>
                      </div>
                  ) : (
                    <>
                    {msg.sender === 'user' && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => handleEdit(msg)}>
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => setDeletingMessageId(msg.id)}>
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                    <div className={cn(
                      "p-3 rounded-lg max-w-md",
                      msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'
                    )}>
                      <p>{msg.text}</p>
                      <p className={cn("text-xs mt-1", msg.sender === 'user' ? 'text-primary-foreground/70' : 'text-muted-foreground')}>{msg.timestamp}</p>
                    </div>
                    {msg.sender === 'staff' && (
                        <div className="w-8" /> 
                    )}
                    </>
                  )}
                </div>
              ))}
               <div ref={messagesEndRef} />
            </ScrollArea>

            <div className="p-4 border-t">
              <form onSubmit={handleSendMessage} className="flex items-center gap-4">
                <Input 
                  placeholder="Type a message..." 
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  disabled={!!editingMessage}
                />
                <Button type="submit" disabled={!newMessage.trim() || !!editingMessage}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <p>Select a conversation to start chatting.</p>
          </div>
        )}
      </div>
      
       <AlertDialog open={!!deletingMessageId} onOpenChange={() => setDeletingMessageId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this message.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
