

"use client";

import { useState, useEffect, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Check, CheckCircle, Copy, Key, Edit, Save, Trash2, PlusCircle, Star, Sparkles, Building, Flame, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { License, Client, PricingTier } from '@/lib/types';
import { initialLicenses } from '@/lib/data';
import { clients as allClients } from '@/lib/data';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { initialPricingTiers } from '@/lib/data';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';

type EditablePricingTier = Omit<PricingTier, 'total' | 'licenses' | 'pricePerLicense'> & {
    total: number | '';
    licenses: number | '';
    pricePerLicense: number | '';
};

function EditablePricingCard({ tier, onSave, onSelect, isEditing, onDelete, onCancel }: {
    tier: PricingTier;
    onSave: (updatedTier: PricingTier) => void;
    onSelect: () => void;
    isEditing: boolean;
    onDelete: (id: string) => void;
    onCancel: () => void;
}) {
    const [editableTier, setEditableTier] = useState<EditablePricingTier>({ ...tier, total: tier.total, licenses: tier.licenses, pricePerLicense: tier.pricePerLicense, mostPopularText: tier.mostPopularText || '', featuredOfferText: tier.featuredOfferText || '', bannerText: tier.bannerText || '' });
    const [featuresText, setFeaturesText] = useState((tier.features || []).join('\n'));

    useEffect(() => {
        if (isEditing) {
            setEditableTier({ 
                ...tier, 
                total: tier.total, 
                licenses: tier.licenses, 
                pricePerLicense: tier.pricePerLicense,
                mostPopularText: tier.mostPopularText || '', 
                featuredOfferText: tier.featuredOfferText || '',
                bannerText: tier.bannerText || '',
            });
            setFeaturesText((tier.features || []).join('\n'));
        }
    }, [tier, isEditing]);

    const handleSave = () => {
        onSave({
            ...editableTier,
            total: typeof editableTier.total === 'string' ? parseFloat(editableTier.total) || 0 : editableTier.total,
            licenses: typeof editableTier.licenses === 'string' ? parseInt(editableTier.licenses, 10) || 0 : editableTier.licenses,
            pricePerLicense: typeof editableTier.pricePerLicense === 'string' ? parseFloat(editableTier.pricePerLicense) || 0 : editableTier.pricePerLicense,
            features: featuresText.split('\n').filter(f => f.trim() !== ''),
            bannerText: editableTier.bannerText,
        });
    };

    const handleInputChange = (field: keyof EditablePricingTier, value: string | number | boolean) => {
        setEditableTier(prev => ({ ...prev, [field]: value }));
    };

    if (isEditing) {
        return (
            <Card className={cn("flex flex-col rounded-2xl border-2 border-primary", tier.isFeatured ? 'col-span-full' : '')}>
                <CardContent className="pt-6 flex-grow space-y-4">
                    <div className="space-y-2">
                        <Label>Tier Name</Label>
                        <Input value={editableTier.name} onChange={(e) => handleInputChange('name', e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label>Number of Licenses</Label>
                        <Input type="number" value={editableTier.licenses} onChange={(e) => handleInputChange('licenses', e.target.value === '' ? '' : parseInt(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                        <Label>Description</Label>
                        <Input value={editableTier.description} onChange={(e) => handleInputChange('description', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label>Price (£/year)</Label>
                        <Input type="number" value={editableTier.total} onChange={(e) => handleInputChange('total', e.target.value === '' ? '' : parseFloat(e.target.value))} />
                    </div>
                     <div className="space-y-2">
                        <Label>Price Per License (£)</Label>
                        <Input type="number" value={editableTier.pricePerLicense} onChange={(e) => handleInputChange('pricePerLicense', e.target.value === '' ? '' : parseFloat(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                        <Label>Banner Text</Label>
                        <Input value={editableTier.bannerText} onChange={(e) => handleInputChange('bannerText', e.target.value)} placeholder="e.g., Save £100" />
                    </div>
                     <div className="space-y-2">
                        <Label>Features (one per line)</Label>
                        <Textarea value={featuresText} onChange={(e) => setFeaturesText(e.target.value)} rows={5} />
                    </div>
                     <div className="flex items-center space-x-2">
                        <Checkbox id={`popular-${tier.id}`} checked={editableTier.isMostPopular} onCheckedChange={(checked) => handleInputChange('isMostPopular', !!checked)} />
                        <Label htmlFor={`popular-${tier.id}`}>Mark as "Most Popular"</Label>
                    </div>
                    {editableTier.isMostPopular && (
                         <div className="space-y-2 pl-6">
                            <Label>Most Popular Badge Text</Label>
                            <Input value={editableTier.mostPopularText} onChange={(e) => handleInputChange('mostPopularText', e.target.value)} />
                        </div>
                    )}
                     <div className="flex items-center space-x-2">
                        <Checkbox id={`featured-${tier.id}`} checked={editableTier.isFeatured} onCheckedChange={(checked) => handleInputChange('isFeatured', !!checked)} />
                        <Label htmlFor={`featured-${tier.id}`}>Mark as Featured Offer</Label>
                    </div>
                    {editableTier.isFeatured && (
                         <div className="space-y-2 pl-6">
                            <Label>Featured Badge Text</Label>
                            <Input value={editableTier.featuredOfferText} onChange={(e) => handleInputChange('featuredOfferText', e.target.value)} />
                        </div>
                    )}
                    <Separator />
                    <div className="space-y-2">
                         <Label>Display Options</Label>
                         <div className="flex items-center space-x-2">
                            <Checkbox id={`displayLicenses-${tier.id}`} checked={editableTier.displayOnLicensesPage} onCheckedChange={(checked) => handleInputChange('displayOnLicensesPage', !!checked)} />
                            <Label htmlFor={`displayLicenses-${tier.id}`}>Show on Licenses Page</Label>
                        </div>
                         <div className="flex items-center space-x-2">
                            <Checkbox id={`displayRegistration-${tier.id}`} checked={editableTier.displayOnRegistrationPage} onCheckedChange={(checked) => handleInputChange('displayOnRegistrationPage', !!checked)} />
                            <Label htmlFor={`displayRegistration-${tier.id}`}>Show on Registration Page</Label>
                        </div>
                    </div>
                </CardContent>
                <CardFooter className="mt-auto flex justify-between">
                    <Button variant="ghost" onClick={() => onDelete(tier.id)}><Trash2 className="text-destructive"/></Button>
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={onCancel}>Cancel</Button>
                        <Button onClick={handleSave}>Save</Button>
                    </div>
                </CardFooter>
            </Card>
        );
    }
    
    const Icon = tier.icon === 'Star' ? Star : tier.icon === 'Zap' ? Zap : Flame;

    if (tier.isFeatured) {
        return (
             <Card className="col-span-full relative overflow-hidden rounded-2xl bg-primary text-primary-foreground">
                 <div className="absolute top-4 right-0 left-0 flex justify-center z-10">
                     <Badge className="bg-black/80 text-white border border-black/80 px-4 py-1">{tier.featuredOfferText}</Badge>
                 </div>
                  <Button variant="ghost" size="icon" onClick={onSelect} className="absolute top-4 right-4 h-8 w-8 hover:bg-white/20 z-20">
                    <Edit className="h-4 w-4" />
                </Button>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    <CardContent className="pt-16 px-8">
                       <div className={cn("h-12 w-12 rounded-full flex items-center justify-center bg-black/20 mb-4")}>
                            <Icon className={cn("h-8 w-8 text-white")} />
                        </div>
                        <h3 className="text-2xl font-semibold">{tier.name}</h3>
                        <p className="text-primary-foreground/80 mt-2">{tier.description}</p>
                        <ul className="space-y-2 text-sm mt-4">
                            {(tier.features || []).map((feature, i) => (
                                <li key={i} className="flex items-center gap-2">
                                <CheckCircle className="h-4 w-4 text-green-400" />
                                <span>{feature}</span>
                                </li>
                            ))}
                            {(!tier.features || tier.features.length === 0) && (
                                <li className={"text-primary-foreground/80"}>No features listed.</li>
                            )}
                        </ul>
                    </CardContent>
                    <div className="p-8 bg-black/10 flex flex-col items-center justify-center text-center h-full">
                        <div>
                            {tier.pricePerLicense > 0 ? (
                                <>
                                    <p className="text-5xl font-bold">
                                        Only - £{tier.pricePerLicense.toFixed(2)}
                                    </p>
                                    <p className="text-xl font-normal text-primary-foreground/80">
                                        Per License Per year
                                    </p>
                                    <div className="mt-2 text-center">
                                        <div className="mt-1" />
                                        <p className={"text-sm text-primary-foreground/80"}>
                                            (Total £{tier.total.toLocaleString()} per year)
                                        </p>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <p className="text-5xl font-bold">
                                        £{tier.total.toLocaleString()}
                                    </p>
                                    <p className="text-xl font-normal text-primary-foreground/80">
                                        / Per year
                                    </p>
                                </>
                            )}
                        </div>
                        <Button className="w-full mt-6 bg-black text-white hover:bg-black/80">
                            Get Started
                        </Button>
                    </div>
                </div>
            </Card>
        )
    }

    return (
        <Card className={cn(
            "flex flex-col relative rounded-2xl", 
            tier.isMostPopular ? 'bg-black text-white' : 'bg-card'
            )}>
          {tier.isMostPopular && (
                <Badge className="absolute -top-3 right-4 bg-sidebar-primary text-sidebar-primary-foreground flex items-center gap-1">
                    {tier.mostPopularText || 'Most Popular'}
                </Badge>
            )}
          {tier.bannerText && !tier.isMostPopular && (
                <Badge className="absolute -top-3 right-4 bg-primary text-primary-foreground flex items-center gap-1">
                    {tier.bannerText}
                </Badge>
          )}
            <CardHeader className="flex-row justify-between items-center">
                 <div className={cn("h-10 w-10 rounded-full flex items-center justify-center", tier.isMostPopular ? 'bg-sidebar-primary/20' : 'bg-primary/10')}>
                    <Icon className={cn("h-6 w-6", tier.isMostPopular ? 'text-sidebar-primary' : 'text-primary')} />
                </div>
                 <Button variant="ghost" size="icon" onClick={onSelect} className={cn(tier.isMostPopular && "text-white hover:bg-white/10")}>
                    <Edit className="h-4 w-4" />
                </Button>
            </CardHeader>
            <CardContent className="pt-0 flex-grow">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">{tier.name}</h3>
                <p className={cn("text-sm", tier.isMostPopular ? "text-white/80" : "text-muted-foreground")}>{tier.description}</p>
                <div>
                    {tier.pricePerLicense > 0 ? (
                        <>
                            <p className="text-4xl font-bold">
                                Only - £{tier.pricePerLicense.toFixed(2)}
                            </p>
                            <p className={cn("text-lg font-normal", tier.isMostPopular ? "text-white/80" : "text-muted-foreground")}>
                                Per License Per year
                            </p>
                            <div className="mt-2">
                                <div className="mt-1" />
                                <p className={cn("text-sm", tier.isMostPopular ? "text-white/80" : "text-muted-foreground")}>
                                    (Total £{tier.total.toLocaleString()} per year)
                                </p>
                            </div>
                        </>
                    ) : (
                         <p className="text-4xl font-bold">
                            £{tier.total.toLocaleString()}<span className={cn("text-lg font-normal", tier.isMostPopular ? "text-white/80" : "text-muted-foreground")}> / Per year</span>
                         </p>
                    )}
                </div>
                <ul className="space-y-2 text-sm">
                  {(tier.features || []).map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                   {(!tier.features || tier.features.length === 0) && (
                    <li className={cn(tier.isMostPopular ? "text-white/80" : "text-muted-foreground")}>No features listed.</li>
                  )}
                </ul>
              </div>
            </CardContent>
            <CardFooter className="mt-auto">
              <Button className={cn("w-full", tier.isMostPopular ? "bg-white text-black hover:bg-white/90" : "bg-primary")}>
                Get Started
              </Button>
            </CardFooter>
        </Card>
    );
}


export default function LicensesPage() {
  const [licenses, setLicenses] = useState<License[]>([]);
  const [clients, setClients] = useState<Omit<Client, 'vatReturnDueDate' | 'mtdIncomeTaxDueDate'>[]>([]);
  const { toast } = useToast();
  const [pricingTiers, setPricingTiers] = useState<PricingTier[]>([]);
  const [editingTierId, setEditingTierId] = useState<string | null>(null);
  
  const [isEditingHeader, setIsEditingHeader] = useState(false);
  const [headerText, setHeaderText] = useState({
      title: 'Simple, Transparent Pricing for Every Business',
      subtitle: 'No hidden fees. No surprises. Choose the plan that fits your business needs and start building your team today.'
  });

  useEffect(() => {
    const storedLicenses = localStorage.getItem('licenses');
    setLicenses(storedLicenses ? JSON.parse(storedLicenses) : initialLicenses);
    setClients(allClients);

    const storedTiers = localStorage.getItem('pricingTiers');
    setPricingTiers(storedTiers ? JSON.parse(storedTiers) : initialPricingTiers);

    const storedHeaderText = localStorage.getItem('licensesHeaderText');
    if (storedHeaderText) {
        setHeaderText(JSON.parse(storedHeaderText));
    }
  }, []);
  
  const handleSaveTier = (updatedTier: PricingTier) => {
    let finalTiers;
    const isNewTier = !pricingTiers.some(t => t.id === updatedTier.id);

    if (isNewTier) {
        finalTiers = [...pricingTiers, updatedTier];
    } else {
        finalTiers = pricingTiers.map(t => t.id === updatedTier.id ? updatedTier : t);
    }
    
    // Handle isMostPopular and isFeatured flags
    finalTiers = finalTiers.map(t => {
        let tier = {...t};
        if (updatedTier.isMostPopular && t.id !== updatedTier.id) {
            tier.isMostPopular = false;
        }
        if (updatedTier.isFeatured && t.id !== updatedTier.id) {
            tier.isFeatured = false;
        }
        return tier;
    });

    setPricingTiers(finalTiers);
    localStorage.setItem('pricingTiers', JSON.stringify(finalTiers));
    setEditingTierId(null);
  };

  const handleAddNewTier = () => {
    const newTier: PricingTier = {
        id: `tier-${Date.now()}`,
        name: 'New Tier',
        licenses: 10,
        pricePer: 'year',
        pricePerLicense: 0,
        total: 0,
        description: 'A great new offer.',
        isMostPopular: false,
        mostPopularText: '',
        isFeatured: false,
        featuredOfferText: '',
        bannerText: '',
        icon: 'Star',
        features: ['Feature 1', 'Feature 2'],
        displayOnLicensesPage: true,
        displayOnRegistrationPage: false,
    };
    setPricingTiers([...pricingTiers, newTier]);
    setEditingTierId(newTier.id);
  }

  const handleDeleteTier = (id: string) => {
      const updatedTiers = pricingTiers.filter(t => t.id !== id);
      setPricingTiers(updatedTiers);
      localStorage.setItem('pricingTiers', JSON.stringify(updatedTiers));
      setEditingTierId(null);
  }

  const handleSaveHeader = () => {
      localStorage.setItem('licensesHeaderText', JSON.stringify(headerText));
      setIsEditingHeader(false);
  }

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast({ title: "Copied!", description: "License key copied to clipboard." });
  };
  
  const getClientName = (clientId: string | null) => {
    if (!clientId) return <Badge variant="outline">Unassigned</Badge>;
    const client = clients.find(c => c.id === clientId);
    return client ? client.name : <Badge variant="destructive">Unknown Client</Badge>;
  }

  const handleAssignClient = (licenseId: string, clientId: string) => {
    const updatedLicenses = licenses.map(lic => 
      lic.id === licenseId ? { ...lic, assignedToClientId: clientId === 'unassign' ? null : clientId } : lic
    );
    setLicenses(updatedLicenses);
    localStorage.setItem('licenses', JSON.stringify(updatedLicenses));
     toast({
      title: "License Updated",
      description: `License has been ${clientId === 'unassign' ? 'unassigned' : 'assigned'}.`,
    });
  }

  const availableLicenses = licenses.filter(l => l.assignedToClientId === null).length;
  const assignedLicenses = licenses.length - availableLicenses;

  const visibleTiers = useMemo(() => pricingTiers.filter(t => t.displayOnLicensesPage), [pricingTiers]);
  const featuredTier = useMemo(() => visibleTiers.find(t => t.isFeatured), [visibleTiers]);
  const regularTiers = useMemo(() => visibleTiers.filter(t => !t.isFeatured), [visibleTiers]);


  return (
    <div className="space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-4">
            {isEditingHeader ? (
                <div className="space-y-4 p-4 border rounded-lg">
                    <Input className="text-4xl font-bold text-center h-auto" value={headerText.title} onChange={(e) => setHeaderText(prev => ({...prev, title: e.target.value}))} />
                    <Textarea value={headerText.subtitle} onChange={(e) => setHeaderText(prev => ({...prev, subtitle: e.target.value}))} />
                    <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setIsEditingHeader(false)}>Cancel</Button>
                        <Button onClick={handleSaveHeader}>Save Header</Button>
                    </div>
                </div>
            ) : (
                <div className="relative group">
                    <h1 className="text-4xl font-bold">{headerText.title}</h1>
                    <p className="text-muted-foreground mt-4">{headerText.subtitle}</p>
                    <Button variant="ghost" size="icon" className="absolute top-0 right-0 opacity-0 group-hover:opacity-100" onClick={() => setIsEditingHeader(true)}>
                        <Edit className="h-4 w-4" />
                    </Button>
                </div>
            )}
        </div>

        <div className="max-w-5xl mx-auto">
            {featuredTier && (
                 <EditablePricingCard
                    key={featuredTier.id}
                    tier={featuredTier}
                    isEditing={editingTierId === featuredTier.id}
                    onSelect={() => setEditingTierId(featuredTier.id)}
                    onSave={handleSaveTier}
                    onDelete={handleDeleteTier}
                    onCancel={() => setEditingTierId(null)}
                />
            )}
        </div>


         <div className="flex justify-end max-w-5xl mx-auto">
            <Button onClick={handleAddNewTier}>
                <PlusCircle className="mr-2" />
                Add New Offer
            </Button>
        </div>

        <div className="grid gap-8 sm:grid-cols-1 lg:grid-cols-3 max-w-5xl mx-auto">
            {regularTiers.map(tier => (
                <EditablePricingCard
                    key={tier.id}
                    tier={tier}
                    isEditing={editingTierId === tier.id}
                    onSelect={() => setEditingTierId(tier.id)}
                    onSave={handleSaveTier}
                    onDelete={handleDeleteTier}
                    onCancel={() => setEditingTierId(null)}
                />
            ))}
        </div>

      <Card>
        <CardHeader>
          <CardTitle>Manage Licenses</CardTitle>
          <CardDescription>Assign licenses to your clients to grant them access.</CardDescription>
          <div className="pt-4 flex gap-4">
            <Badge variant="secondary" className="text-base">Total Licenses: {licenses.length}</Badge>
            <Badge variant="secondary" className="text-base bg-green-500/20 text-green-300">Available: {availableLicenses}</Badge>
             <Badge variant="secondary" className="text-base bg-blue-500/20 text-blue-300">Assigned: {assignedLicenses}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="border-r">License Key</TableHead>
                <TableHead className="border-r">Purchase Date</TableHead>
                <TableHead className="border-r">Assigned To</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {licenses.map(license => (
                <TableRow key={license.id}>
                  <TableCell className="font-mono border-r">
                     <div className="flex items-center gap-2">
                        <Key className="h-4 w-4 text-muted-foreground" />
                        <span>{license.key}</span>
                     </div>
                  </TableCell>
                  <TableCell className="border-r">{format(new Date(license.purchaseDate), 'dd MMM yyyy')}</TableCell>
                  <TableCell className="border-r">
                    {getClientName(license.assignedToClientId)}
                  </TableCell>
                  <TableCell className="text-right flex items-center justify-end gap-2">
                     <Select 
                        value={license.assignedToClientId || 'unassign'} 
                        onValueChange={(clientId) => handleAssignClient(license.id, clientId)}
                    >
                        <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Assign to client..." />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="unassign">Unassign</SelectItem>
                            {clients.map(client => (
                                <SelectItem key={client.id} value={client.id} disabled={licenses.some(l => l.assignedToClientId === client.id && l.id !== license.id)}>
                                    {client.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Button variant="ghost" size="icon" onClick={() => handleCopyKey(license.key)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
