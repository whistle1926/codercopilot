
"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useActiveClient } from '@/hooks/use-active-client';
import { Loader2 } from 'lucide-react';

export default function DashboardRootPage() {
    const router = useRouter();
    const { activeClient, isClientInitialised } = useActiveClient();

    useEffect(() => {
        if (isClientInitialised) {
            if (activeClient) {
                // If the client has not completed the questionnaire, redirect them to it.
                // This becomes the mandatory first step.
                if (!activeClient.questionnaireCompleted) {
                    router.replace('/dashboard/questionnaire');
                } else {
                    // Otherwise, send them to the main staff hub.
                    router.replace('/dashboard/staff-hub');
                }
            } else {
                 // Default for super admin, etc.
                 router.replace('/dashboard/super-admin');
            }
        }
    }, [router, activeClient, isClientInitialised]);

    return (
        <div className="flex h-full w-full items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin" />
        </div>
    );
}
