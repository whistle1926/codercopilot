
import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { ActiveClientProvider } from '@/hooks/use-active-client';

export const metadata: Metadata = {
  title: 'Coder Co-Pilot',
  description: 'On-Demand Tech Teams',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-body antialiased" suppressHydrationWarning>
        <ActiveClientProvider>
          {children}
        </ActiveClientProvider>
        <Toaster />
      </body>
    </html>
  );
}
