

"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CoderCoPilotLogo } from '@/components/icons';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import type { StaffMember } from '@/lib/types';
import { initialStaff } from '@/lib/data';

export default function TeamManagerLoginPage() {
    const router = useRouter();
    const { toast } = useToast();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        
        let allStaff: StaffMember[];
        try {
            const storedStaff = localStorage.getItem('hubStaff');
            allStaff = storedStaff ? JSON.parse(storedStaff) : initialStaff;
        } catch (error) {
            console.error("Failed to parse staff data, falling back to initial data.", error);
            allStaff = initialStaff;
        }

        const staffMember = allStaff.find(s => s.email === email && s.password === password);

        if (staffMember && staffMember.isTeamLead) {
            sessionStorage.setItem('loggedInStaffId', staffMember.id);
            toast({
                title: 'Login Successful',
                description: `Welcome back, Team Manager ${staffMember.name}!`,
            });
            router.push('/staff-dashboard');
        } else if (staffMember && !staffMember.isTeamLead) {
            toast({
                variant: 'destructive',
                title: 'Access Denied',
                description: 'You are not authorized to access the Team Manager portal.',
            });
        } else {
            toast({
                variant: 'destructive',
                title: 'Login Failed',
                description: 'Invalid email or password.',
            });
        }
    };


  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-white p-4 text-foreground">
        <div className="mb-8">
            <CoderCoPilotLogo className="h-24 w-auto text-primary" />
        </div>
        <div className="mb-8 max-w-2xl text-center">
            <h1 className="text-4xl font-bold text-foreground">
              Team Manager Portal
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              Manage your assigned companies and allocate resources.
            </p>
        </div>
      <Card className="w-full max-w-sm bg-muted/50 shadow-2xl">
        <CardHeader className="text-center">
            <CardTitle className="text-2xl">Team Manager Login</CardTitle>
            <CardDescription>
            Enter your credentials to access your dashboard.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <form className="space-y-4" onSubmit={handleLogin}>
            <div className="space-y-2">
                <Label htmlFor="email-login">Email</Label>
                <Input
                id="email-login"
                type="email"
                placeholder="manager@example.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                />
            </div>
            <div className="space-y-2">
                <Label htmlFor="password-login">Password</Label>
                <Input 
                    id="password-login" 
                    type="password" 
                    required 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
            </div>
            <Button type="submit" className="w-full">
                Login
            </Button>
            </form>
             <div className="mt-4 text-center text-sm">
                Not a Team Manager?{' '}
                <Button variant="link" asChild className="p-0 h-auto">
                    <Link href="/login">Return to Main Login</Link>
                </Button>
            </div>
        </CardContent>
        </Card>
    </div>
  );
}
