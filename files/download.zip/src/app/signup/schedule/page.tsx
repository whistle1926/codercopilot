
"use client";

import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Globe, Clock, Video, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, addDays, startOfWeek, addWeeks, isToday } from 'date-fns';

const timeSlots: Record<string, string[]> = {
  "2025-09-29": ["9:30 PM"],
  "2025-10-01": ["10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM"],
  "2025-10-02": ["9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM"],
};

export default function SchedulePage() {
  const [date, setDate] = useState<Date | undefined>(new Date('2025-09-27'));
  const [week, setWeek] = useState(startOfWeek(new Date('2025-09-27')));
  const [selectedTime, setSelectedTime] = useState<string | null>('9:30 PM');

  const daysOfWeek = Array.from({ length: 7 }, (_, i) => addDays(week, i));
  const monthName = format(daysOfWeek[0], 'MMMM yyyy');

  const handleNextWeek = () => setWeek(addWeeks(week, 1));
  const handlePrevWeek = () => setWeek(addWeeks(week, -1));
  
  const handleTimeSelect = (time: string, day: Date) => {
    setDate(day);
    setSelectedTime(time);
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 border rounded-lg bg-white dark:bg-slate-800 shadow-lg">
        {/* Left Panel */}
        <div className="p-6 border-r border-gray-200 dark:border-slate-700 flex flex-col gap-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-10 w-10">
              <AvatarImage src="https://picsum.photos/seed/es-avatar/40/40" data-ai-hint="initials logo" />
              <AvatarFallback>ES</AvatarFallback>
            </Avatar>
            <div>
                <p className="font-semibold text-sm text-gray-700 dark:text-gray-300">Emma Shevlin</p>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Hano Business Solutions</h2>
                <p className="text-gray-500 dark:text-slate-400 text-sm">Call with Emma O'Hanlon</p>
            </div>
          </div>
          <div className="space-y-2 text-sm text-gray-500 dark:text-slate-400">
            <p className="flex items-center gap-2"><Clock className="h-4 w-4" /> 1 hour</p>
            <p className="flex items-center gap-2"><Video className="h-4 w-4" /> Zoom Meeting</p>
          </div>
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="p-0"
          />
        </div>

        {/* Right Panel */}
        <div className="p-6 md:col-span-2 lg:col-span-3">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-gray-500 dark:text-slate-400" />
              <Select defaultValue="gmt">
                <SelectTrigger className="w-auto border-none shadow-none focus:ring-0 text-gray-900 dark:text-white bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gmt">(GMT+01:00) Greenwich Mean Time - Dublin</SelectItem>
                  <SelectItem value="pst">(GMT-08:00) Pacific Time</SelectItem>
                  <SelectItem value="est">(GMT-05:00) Eastern Time</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-4 text-gray-900 dark:text-white">
              <div className="flex items-center gap-2">
                <Switch id="24hr" />
                <label htmlFor="24hr" className="text-sm">24 hr</label>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="work-week" />
                <label htmlFor="work-week" className="text-sm">Work week</label>
              </div>
              <Select defaultValue="en">
                <SelectTrigger className="w-auto border-none shadow-none focus:ring-0 bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{monthName}</h3>
            <div className="flex items-center gap-2">
                <Button variant="ghost" className="text-gray-600 dark:text-white hover:bg-gray-100 dark:hover:bg-slate-700" size="icon" onClick={handlePrevWeek}><ChevronLeft/></Button>
                <Button variant="ghost" className="text-gray-600 dark:text-white hover:bg-gray-100 dark:hover:bg-slate-700" size="icon" onClick={handleNextWeek}><ChevronRight/></Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-4 text-center">
            {daysOfWeek.map((day) => {
              const dayKey = format(day, 'yyyy-MM-dd');
              const slots = timeSlots[dayKey as keyof typeof timeSlots] || [];
              const isSelectedDay = date && format(day, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd');
              return (
                <div key={day.toString()}>
                  <p className="text-sm text-gray-500 dark:text-slate-400">{format(day, 'E')}</p>
                  <p className={cn("font-semibold text-lg mb-4 text-gray-800 dark:text-gray-200", isSelectedDay && "text-blue-600 dark:text-blue-400")}>{format(day, 'd')}</p>
                  <div className="space-y-2">
                    {slots.length > 0 ? slots.map(time => (
                      <Button 
                        key={time} 
                        variant={selectedTime === time && isSelectedDay ? 'default' : 'outline'}
                        className="w-full"
                        onClick={() => handleTimeSelect(time, day)}
                      >
                        {time}
                      </Button>
                    )) : <p className="text-sm text-gray-400 dark:text-slate-500">No availability</p>}
                  </div>
                </div>
              );
            })}
          </div>
           <div className="text-center mt-8 text-xs text-gray-400 dark:text-slate-500">
                Zoom Scheduler
                <span className="mx-2">|</span>
                This site is a demo and is not affiliated with Zoom.
            </div>
        </div>
      </div>
    </div>
  );
}
