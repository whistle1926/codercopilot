
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CoderCoPilotLogo } from '@/components/icons';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

export default function SignupPage() {
  const router = useRouter();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would normally handle form validation and submission
    toast({
        title: "Details Submitted",
        description: "Please book your setup call on the next page.",
    });
    router.push('/signup/schedule');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-[#0B0C2A] to-[#1E40AF] p-4 text-white">
      <Card className="w-full max-w-sm mx-auto bg-card text-card-foreground">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex justify-center">
            <CoderCoPilotLogo className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">Create Your Account With Coder Co-Pilot</CardTitle>
          <CardDescription>Enter your details to schedule your setup call.</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" type="text" placeholder="John Doe" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="m@example.com" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required />
            </div>
             <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input id="confirm-password" type="password" required />
            </div>
            <Button type="submit" className="w-full">
              Schedule Setup Call
            </Button>
          </form>
          <div className="mt-4 text-center text-sm">
            Already have an account?{' '}
            <Link href="/" className="underline">
              Log in
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
