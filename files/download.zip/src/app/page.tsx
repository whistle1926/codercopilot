
"use client";

import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { CoderCoPilotLogo } from '@/components/icons';
import { CheckCircle, Users, FileText, Landmark, Banknote, Folder, Key, Sparkles, Workflow, ClipboardCheck, UserCheck, ShieldCheck, FileClock, Code, Rocket, Activity } from 'lucide-react';


const benefits = [
    {
        icon: Users,
        title: "On-Demand Talent",
        description: "Instantly access a pool of skilled developers, designers, and project managers ready to work, for as little or as long as you need. Scale your team up or down with zero friction."
    },
    {
        icon: Landmark,
        title: "No Contracts, No Hassle",
        description: "Forget long-term commitments and complex hiring processes. Our platform allows you to engage experts on a project-by-project basis, hassle-free."
    },
    {
        icon: Banknote,
        title: "Fully Vetted Experts",
        description: "Every professional on our platform is thoroughly vetted for technical skill and communication, ready to contribute from day one, saving you time and training costs."
    },
    {
        icon: Sparkles,
        title: "AI-Powered Matching",
        description: "Our smart system matches you with the perfect professional based on your specific project needs, ensuring the right fit for every job."
    },
    {
        icon: FileText,
        title: "Simplified Invoicing & Payments",
        description: "Handle all payments and invoicing directly through our secure platform. We streamline the financial side so you can focus on the work."
    },
    {
        icon: Workflow,
        title: "Seamless Collaboration",
        description: "Integrate our professionals directly into your existing workflow. Our platform provides the tools you need for smooth communication and project management."
    }
];

const painPoints = [
    {
        icon: Code,
        title: "Expertise On-Demand",
        description: "Need a specific tech stack or skill set? Our platform connects you with pre-vetted experts, from front-end developers to cloud engineers, ready to tackle any challenge."
    },
    {
        icon: Activity,
        title: "Reduce Management Overhead",
        description: "Every project is overseen by a dedicated, highly-trained tech project manager. They handle the day-to-day, ensuring your project stays on track so you can focus on the big picture."
    },
    {
        icon: Rocket,
        title: "Accelerate Your Roadmap",
        description: "Stop letting talent shortages slow you down. Build and scale your tech team in days, not months, and bring your ideas to market faster than ever before."
    }
];


const Feature = ({ icon, title, children }: { icon: React.ElementType, title: string, children: React.ReactNode }) => {
  const Icon = icon;
  return (
    <div className="flex items-start gap-4">
      <div className="bg-primary/10 text-primary p-2 rounded-lg">
          <Icon className="h-6 w-6" />
      </div>
      <div>
        <h3 className="font-semibold text-lg">{title}</h3>
        <p className="text-muted-foreground">{children}</p>
      </div>
    </div>
  );
};


export default function HomePage() {

  return (
    <div className="flex min-h-screen w-full flex-col bg-background text-foreground">
      <main className="flex-1">
        <section className="container grid grid-cols-1 items-center gap-12 pt-12 pb-20 md:pt-24 md:pb-32">
          <div className="flex flex-col items-center text-center gap-6">
            <Badge>
              Hire Vetted Tech Professionals
            </Badge>
            <h1 className="text-4xl font-bold md:text-5xl lg:text-6xl max-w-4xl">
              Build Your Dream Team with Coder Co-Pilot
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl">
              Access an elite pool of developers, designers, and project managers. Coder Co-Pilot is your AI-powered partner for assembling and managing a world-class, on-demand tech team.
            </p>
             <div className="flex flex-col sm:flex-row items-center gap-4">
              <Button size="lg" asChild>
                <Link href="/login">Get Started</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/staff-login">Login as Staff</Link>
              </Button>
            </div>
          </div>

          <div className="max-w-4xl mx-auto w-full">
            <Card className="bg-muted/30">
                <CardHeader>
                    <CardTitle className="text-2xl text-center">Your Go-To Hub for Flexible, Expert Tech Staffing</CardTitle>
                    <CardDescription className="text-center text-base">Hire ready-to-go staff without the contracts. Use them when you need them, for as little or as long as you need.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                    {painPoints.map((point) => (
                        <Feature key={point.title} icon={point.icon} title={point.title}>
                            {point.description}
                        </Feature>
                    ))}
                </CardContent>
            </Card>
          </div>

           <div className="relative">
             <Card className="w-full max-w-6xl mx-auto bg-card/50">
                <CardHeader className="text-center">
                    <CardTitle className="text-3xl">Why Choose Coder Co-Pilot?</CardTitle>
                    <CardDescription>Our platform is built to provide maximum flexibility and immediate value.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                       {benefits.map((benefit, index) => {
                        const Icon = benefit.icon;
                        return (
                          <Card key={index} className="flex flex-col text-left bg-card">
                            <CardHeader>
                              <div className="flex items-center gap-4">
                                <div className="bg-primary/10 text-primary p-3 rounded-lg">
                                    <Icon className="h-6 w-6" />
                                </div>
                                <CardTitle className="text-xl">{benefit.title}</CardTitle>
                              </div>
                            </CardHeader>
                            <CardContent className="flex-grow">
                              <p className="text-muted-foreground">{benefit.description}</p>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                </CardContent>
            </Card>
           </div>
        </section>
      </main>

      <footer className="container py-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
                <CoderCoPilotLogo className="h-6 w-6 text-primary" />
                <p className="text-sm text-muted-foreground">&copy; 2025 Coder Co-Pilot. All rights reserved.</p>
            </div>
            <div className="flex items-center gap-4">
                <Link href="/login" className="text-sm hover:underline text-muted-foreground" target="_blank">Login</Link>
                <Link href="/signup/schedule" className="text-sm hover:underline text-muted-foreground">Sign Up Free</Link>
            </div>
        </div>
      </footer>
    </div>
  );
}
