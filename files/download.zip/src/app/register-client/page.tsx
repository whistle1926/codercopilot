

"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

function RegistrationForm() {
    const router = useRouter();
    const { toast } = useToast();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        toast({
            title: "Registration Successful",
            description: "Please complete the payment to activate your account.",
        });
        router.push('/register-client/payment');
    };

    return (
         <Card className="w-full max-w-xl bg-white text-black shadow-2xl rounded-xl">
            <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold">Create Your MTD Simple Account</CardTitle>
            </CardHeader>
            <CardContent>
                <form className="space-y-4" onSubmit={handleSubmit}>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <Label htmlFor="first-name">First Name *</Label>
                            <Input id="first-name" className="bg-gray-50" />
                        </div>
                        <div className="space-y-1">
                            <Label htmlFor="second-name">Second Name *</Label>
                            <Input id="second-name" className="bg-gray-50" />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <Label htmlFor="email">Email Address *</Label>
                        <Input id="email" type="email" className="bg-gray-50" />
                    </div>
                     <div className="space-y-1">
                        <Label htmlFor="mobile-number">Mobile Number *</Label>
                        <Input id="mobile-number" type="tel" className="bg-gray-50" />
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold" type="submit">
                        Register
                    </Button>
                </form>
            </CardContent>
             <CardFooter className="flex justify-center items-center text-sm">
                <p className="text-gray-500">Already have an account? <Link href="/" className="font-semibold text-blue-600 hover:underline">Log in</Link></p>
            </CardFooter>
        </Card>
     )
}


export default function ClientRegistrationPage() {
  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center bg-[#1E40AF] text-white p-4">
        <div className="container grid h-full items-center gap-8 lg:grid-cols-2">
            <div className="flex flex-col justify-center text-center lg:text-center">
                    <div className="mx-auto w-full max-w-lg lg:mx-auto">
                    <div className="flex justify-center mb-8">
                        <div className="w-[200px] h-[200px] bg-gray-500/20 flex items-center justify-center rounded-lg">
                            <p className="text-gray-400">Logo Placeholder</p>
                        </div>
                    </div>
                    <h1 className="text-5xl font-extrabold tracking-tight lg:leading-[3.5rem]">
                        You have Been Invited To Making Tax Digital Simple
                    </h1>
                    <p className="mt-4 text-lg text-gray-300">
                        by <span className="font-bold">Hano Business Solutions</span>
                    </p>
                     <p className="mt-4 text-lg text-gray-300">
                        Sharing this link will allow you easily to get your current clients signed up in a few steps they enter details pay the yearly fee and once approved they will be activated to start using MTD Simple all done from one central portal.
                    </p>
                </div>
            </div>
                <div className="flex items-center justify-center p-8 lg:p-0">
                <RegistrationForm />
            </div>
        </div>
        <div className="fixed bottom-4 left-4 h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center font-bold text-sm">
            N
        </div>
    </div>
  );
}
