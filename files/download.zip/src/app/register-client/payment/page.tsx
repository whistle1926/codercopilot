
"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle, ShieldCheck } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

type Step = 'consent' | 'connecting' | 'success';

function PaymentFlow() {
  const router = useRouter();
  const { toast } = useToast();
  const [step, setStep] = useState<Step>('consent');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'connecting' && progress < 100) {
      timer = setTimeout(() => {
        setProgress(prev => {
          const newProgress = prev + Math.random() * 20;
          if (newProgress >= 100) {
            setStep('success');
            return 100;
          }
          return newProgress;
        });
      }, 500);
    }
    return () => clearTimeout(timer);
  }, [step, progress]);
  
  useEffect(() => {
    if (step === 'success') {
        toast({
            title: 'Payment Successful!',
            description: 'Your account is now pending approval.',
        });
    }
  }, [step, toast]);


  const handleConsent = () => {
    setStep('connecting');
  };
  
  const handleCancel = () => {
      router.push('/');
  }

  const renderContent = () => {
    switch (step) {
      case 'consent':
        return (
          <>
            <CardHeader className="text-center">
              <CardTitle>Pay with Open Banking</CardTitle>
              <CardDescription>You will be redirected to your bank to authorise the payment.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-start gap-4 rounded-lg border bg-muted/50 p-4">
                    <ShieldCheck className="h-8 w-8 text-primary flex-shrink-0" />
                    <div>
                        <h4 className="font-semibold">Safe and Secure</h4>
                        <p className="text-sm text-muted-foreground">We use Yapily to securely connect to your bank. We will not see or store your bank credentials.</p>
                    </div>
                </div>
                 <div className="flex items-center justify-center gap-2 rounded-lg border bg-muted/50 p-4">
                    <p className="text-sm text-muted-foreground">Securely powered by</p>
                    <span className="font-bold text-lg">Yapily</span>
                </div>
                <p className="text-sm text-muted-foreground">
                    By continuing, you agree to make a one-time payment for your account setup.
                </p>
            </CardContent>
            <CardFooter className="justify-between">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConsent}>Continue to Payment</Button>
            </CardFooter>
          </>
        );
      case 'connecting':
        return (
            <>
                <CardHeader>
                    <CardTitle>Connecting to your bank...</CardTitle>
                    <CardDescription>Please wait while we securely redirect you. Do not close this window.</CardDescription>
                </CardHeader>
                <CardContent className="py-8 flex flex-col items-center justify-center space-y-4">
                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                    <p className="text-muted-foreground">Redirecting... authorising payment... confirming...</p>
                    <Progress value={progress} className="w-[60%]" />
                </CardContent>
          </>
        );
      case 'success':
        return (
            <>
                <CardHeader className="text-center">
                    <CardTitle>Thank You!</CardTitle>
                    <CardDescription>Your payment was successful.</CardDescription>
                </CardHeader>
                <CardContent className="py-8 flex flex-col items-center justify-center space-y-4">
                    <CheckCircle className="h-16 w-16 text-green-500" />
                    <p className="text-muted-foreground text-center text-lg">
                        Thank you your account is now pending approval.
                    </p>
                </CardContent>
            </>
        );
    }
  };

  return (
      <Card className="w-full max-w-lg bg-white text-black shadow-2xl rounded-xl">
        {renderContent()}
      </Card>
  )
}


export default function PaymentPage() {
  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center bg-gradient-to-b from-[#0B0C2A] to-[#1E40AF] text-white p-4">
        <PaymentFlow />
    </div>
  );
}
