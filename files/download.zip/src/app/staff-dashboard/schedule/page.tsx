

"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import type { StaffMember, Client, TimeLimit } from '@/lib/types';
import { toZonedTime, fromZonedTime, format } from 'date-fns-tz';
import { parse } from 'date-fns';
import { cn } from '@/lib/utils';
import { Clock } from 'lucide-react';


function TimeSlot({ limit, companyTimezone, staffTimezone }: { limit: TimeLimit, companyTimezone: string, staffTimezone: string }) {
    
    const convertTime = (time: string, fromTz: string, toTz: string) => {
        if (!time) return '--:--';
        try {
            const today = new Date();
            const [hours, minutes] = time.split(':').map(Number);
            const sourceDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), hours, minutes);
            
            const zonedDate = fromZonedTime(sourceDate, fromTz);
            const targetDate = toZonedTime(zonedDate, toTz);

            return format(targetDate, 'HH:mm');
        } catch (e) {
            return 'Invalid';
        }
    };
    
    return (
        <div className="p-4 bg-primary/10 text-primary-foreground rounded-lg">
            <div className="font-semibold text-primary">{limit.day}</div>
            <div className="flex justify-between items-center mt-2">
                <div>
                    <p className="text-xs text-primary/80">Company Time ({companyTimezone.split('/')[1]})</p>
                    <p className="text-lg font-bold text-primary">{limit.startTime} - {limit.endTime}</p>
                </div>
                <div>
                    <p className="text-xs text-primary/80">Your Time ({staffTimezone.split('/')[1]})</p>
                    <p className="text-lg font-bold text-primary">{convertTime(limit.startTime, companyTimezone, staffTimezone)} - {convertTime(limit.endTime, companyTimezone, staffTimezone)}</p>
                </div>
            </div>
        </div>
    );
}

export default function StaffSchedulePage() {
    const [staff, setStaff] = useState<StaffMember | null>(null);
    const [activeCompany, setActiveCompany] = useState<Client | null>(null);

    const loadData = useCallback(() => {
        const staffId = sessionStorage.getItem('loggedInStaffId');
        if (!staffId) return;

        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const currentStaff = allStaff.find(s => s.id === staffId);
        setStaff(currentStaff || null);
        
        if (!currentStaff) return;
        
        const companyId = sessionStorage.getItem(`staff_${staffId}_activeCompany`);
        if (companyId) {
            const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
            const company = allClients.find(c => c.id === companyId);
            setActiveCompany(company || null);
        } else {
            setActiveCompany(null);
        }

    }, []);

     useEffect(() => {
        loadData();
        window.addEventListener('staffCompanyChanged', loadData);
        window.addEventListener('storage', loadData);

        return () => {
            window.removeEventListener('staffCompanyChanged', loadData);
            window.removeEventListener('storage', loadData);
        };
    }, [loadData]);


    const sortedTimeLimits = staff?.timeLimits?.sort((a, b) => {
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        return days.indexOf(a.day) - days.indexOf(b.day);
    }) || [];

    if (!staff) {
        return <p>Loading staff data...</p>;
    }
    
    if (!activeCompany) {
         return (
            <Card>
                <CardHeader>
                    <CardTitle>My Schedule</CardTitle>
                    <CardDescription>View your allocated working hours for your companies.</CardDescription>
                </CardHeader>
                <CardContent>
                     <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-48 flex items-center justify-center">
                        <p>Please select a company from the sidebar to view your schedule.</p>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>My Schedule for {activeCompany.name}</CardTitle>
                <CardDescription>
                    These are your allocated working hours. All times are shown in both company time and your local time.
                </CardDescription>
            </CardHeader>
            <CardContent>
                {sortedTimeLimits.length > 0 ? (
                    <div className="space-y-4">
                        {sortedTimeLimits.map(limit => (
                            <TimeSlot 
                                key={limit.day} 
                                limit={limit} 
                                companyTimezone={activeCompany?.timezone || 'Europe/London'}
                                staffTimezone={staff?.timezone || 'Asia/Manila'}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-48 flex items-center justify-center">
                        <p>No working hours have been set for you by this company yet.</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
