

"use client";

import { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { MessageSquare, ListChecks, Check, Flag, Clock, CalendarIcon, Play, Pause, Save, Loader2, RotateCcw } from 'lucide-react';
import type { Task, TaskStatus, TaskPriority, Comment, SubTask } from '@/lib/types';
import Link from 'next/link';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format, parse } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { initialStaff } from '@/lib/data';
import type { StaffMember, Client } from '@/lib/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StaffSchedulePage from '../schedule/page';


interface StaffTasks {
    [staffId: string]: {
        [companyId: string]: Task[];
    };
}

function StaffTaskManager() {
    const { toast } = useToast();
    const [tasks, setTasks] = useState<Task[]>([]);
    const [activeCompany, setActiveCompany] = useState<Client | null>(null);
    const [staff, setStaff] = useState<StaffMember | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    
    // State for comments
    const [commentingTask, setCommentingTask] = useState<Task | null>(null);
    const [newComment, setNewComment] = useState('');
    
    // State for subtasks
    const [subTaskingTask, setSubTaskingTask] = useState<Task | null>(null);
    const [newSubTask, setNewSubTask] = useState('');
    
    const loadTasks = useCallback(() => {
        setIsLoading(true);
        const staffId = sessionStorage.getItem('loggedInStaffId');
        if (!staffId) {
            setIsLoading(false);
            return;
        };

        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const currentStaff = allStaff.find(s => s.id === staffId);
        setStaff(currentStaff || null);

        if (!currentStaff) {
             setIsLoading(false);
            return;
        }

        let companyId = sessionStorage.getItem(`staff_${staffId}_activeCompany`);
        
        if (!companyId || !currentStaff.hiredBy?.includes(companyId)) {
            companyId = currentStaff.hiredBy?.[0] || null;
            if (companyId) {
                sessionStorage.setItem(`staff_${staffId}_activeCompany`, companyId);
            } else {
                 sessionStorage.removeItem(`staff_${staffId}_activeCompany`);
            }
        }
        
        if (companyId) {
            const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
            setActiveCompany(allClients.find(c => c.id === companyId) || null);

            const allTasks: StaffTasks = JSON.parse(localStorage.getItem('staffTasks') || '{}');
            const staffTasks = allTasks[staffId] || {};
            setTasks(staffTasks[companyId] || []);
        } else {
            setTasks([]);
            setActiveCompany(null);
        }
        setIsLoading(false);
    }, []);

    useEffect(() => {
        loadTasks();
        
        const handleCompanyChange = (event: Event) => {
            loadTasks();
        };

        window.addEventListener('staffCompanyChanged', handleCompanyChange);
        window.addEventListener('storage', loadTasks); // Also listen for broader changes

        return () => {
            window.removeEventListener('staffCompanyChanged', handleCompanyChange);
            window.removeEventListener('storage', loadTasks);
        };
    }, [loadTasks]);

    const saveTasks = (updatedTasks: Task[]) => {
        if (!activeCompany || !staff) return;

        setTasks(updatedTasks);
        const allTasks: StaffTasks = JSON.parse(localStorage.getItem('staffTasks') || '{}');
        if (!allTasks[staff.id]) {
            allTasks[staff.id] = {};
        }
        allTasks[staff.id][activeCompany.id] = updatedTasks;
        localStorage.setItem('staffTasks', JSON.stringify(allTasks));
        window.dispatchEvent(new StorageEvent('storage', { key: 'staffTasks', newValue: JSON.stringify(allTasks) }));
    };
    
    const handleAddComment = () => {
        if (!commentingTask || !newComment.trim() || !staff) return;

        const comment: Comment = {
            id: `comment-${Date.now()}`,
            author: staff.name,
            text: newComment,
            timestamp: new Date().toISOString(),
        };

        const updatedTasks = tasks.map(task =>
            task.id === commentingTask.id
                ? { ...task, comments: [...(task.comments || []), comment] }
                : task
        );
        saveTasks(updatedTasks);
        setNewComment('');
    };
    
    const handleAddSubTask = () => {
        if (!subTaskingTask || !newSubTask.trim()) return;

        const subTask: SubTask = {
            id: `subtask-${Date.now()}`,
            title: newSubTask,
            completed: false,
        };

        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id
                ? { ...task, subTasks: [...(task.subTasks || []), subTask] }
                : task
        );
        saveTasks(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: [...(prev.subTasks || []), subTask] } : null);
        setNewSubTask('');
    };
    
    const handleToggleSubTask = (subTaskId: string) => {
        if (!subTaskingTask) return;

        const updatedSubTasks = (subTaskingTask.subTasks || []).map(st =>
            st.id === subTaskId ? { ...st, completed: !st.completed } : st
        );

        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id
                ? { ...task, subTasks: updatedSubTasks }
                : task
        );
        saveTasks(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: updatedSubTasks } : null);
    };

    const completeTask = (task: Task) => {
        const updatedTasks = tasks.map(t =>
            t.id === task.id ? { ...t, status: 'Done' as TaskStatus, completionDate: new Date().toISOString() } : t
        );
        saveTasks(updatedTasks);
    };

    const startTask = (task: Task) => {
        const updatedTasks = tasks.map(t =>
            t.id === task.id ? { ...t, status: 'In Progress' as TaskStatus } : t
        );
        saveTasks(updatedTasks);
    };

    const reopenTask = (task: Task) => {
        const updatedTasks = tasks.map(t =>
            t.id === task.id ? { ...t, status: 'To Do' as TaskStatus } : t
        );
        saveTasks(updatedTasks);
        toast({
            title: 'Task Re-opened',
            description: `"${task.title}" has been moved back to your To Do list.`,
        });
    };


    const priorityConfig = {
        High: { icon: Flag, color: "text-red-500" },
        Medium: { icon: Flag, color: "text-yellow-500" },
        Low: { icon: Flag, color: "text-gray-400" },
    }

    const TaskCard = ({ task, isCompleted = false }: { task: Task; isCompleted?: boolean }) => {
        const PriorityIcon = priorityConfig[task.priority].icon;
        
        const completedSubTasks = (task.subTasks || []).filter(st => st.completed).length;
        const totalSubTasks = (task.subTasks || []).length;
        const subTaskProgress = totalSubTasks > 0 ? (completedSubTasks / totalSubTasks) * 100 : 0;

        return (
            <Card className="bg-background shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-4 space-y-3">
                    <div className="flex justify-between items-start">
                        <p className="font-semibold leading-tight">{task.title}</p>
                        <div className="flex items-center gap-1">
                             <PriorityIcon className={cn("h-4 w-4", priorityConfig[task.priority].color)} />
                        </div>
                    </div>
                    {task.details && <p className="text-sm text-muted-foreground">{task.details}</p>}
                    
                    {totalSubTasks > 0 && (
                        <div className="space-y-1">
                            <div className="flex justify-between items-center text-xs text-muted-foreground">
                                <span>Checklist Progress</span>
                                <span>{completedSubTasks} / {totalSubTasks}</span>
                            </div>
                            <Progress value={subTaskProgress} className="h-2" />
                        </div>
                    )}

                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                        {task.dueDate && (
                            <div className="flex items-center gap-1.5">
                                <CalendarIcon className="h-4 w-4"/>
                                <span>{format(new Date(task.dueDate), 'dd MMM')}</span>
                            </div>
                        )}
                        
                         <div className="flex items-center gap-1">
                             <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setSubTaskingTask(task)}>
                                <ListChecks className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setCommentingTask(task)}>
                                <MessageSquare className="h-4 w-4" />
                                {task.comments?.length > 0 && (
                                    <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 justify-center p-0">{task.comments.length}</Badge>
                                )}
                            </Button>
                         </div>
                    </div>
                </CardContent>
                 <CardFooter className="p-2 border-t flex gap-2">
                    {task.status === 'To Do' && <Button size="sm" className="w-full" onClick={() => startTask(task)}><Play className="mr-2 h-4 w-4" />Start Task</Button>}
                    {task.status === 'In Progress' && <Button size="sm" className="w-full bg-green-600 hover:bg-green-700" onClick={() => completeTask(task)}>Mark as Done</Button>}
                     {isCompleted && <Button size="sm" variant="outline" className="w-full" onClick={() => reopenTask(task)}><RotateCcw className="mr-2 h-4 w-4" />Re-open Task</Button>}
                </CardFooter>
            </Card>
        )
    }

    const tasksByStatus = {
        'To Do': tasks.filter(t => t.status === 'To Do'),
        'In Progress': tasks.filter(t => t.status === 'In Progress'),
        'Done': tasks.filter(t => t.status === 'Done'),
        'Paid': tasks.filter(t => t.status === 'Paid' || t.status === 'Approved'),
    };
    
    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
        );
    }

    if (!staff) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle>Error</CardTitle>
                    <CardDescription>Could not load staff member data.</CardDescription>
                </CardHeader>
            </Card>
        )
    }

    if (!activeCompany) {
        return (
            <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-48 flex items-center justify-center">
                <p>Please select a company from the sidebar to view tasks.</p>
            </div>
        )
    }

    return (
        <Card className="mt-6">
            <CardHeader>
                <CardTitle>My Tasks for {activeCompany.name}</CardTitle>
                <CardDescription>View and manage all tasks assigned to you for this company.</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="board">
                    <TabsList>
                        <TabsTrigger value="board">My Task Board</TabsTrigger>
                        <TabsTrigger value="schedule">My Schedule</TabsTrigger>
                    </TabsList>
                    <TabsContent value="board" className="pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            {['To Do', 'In Progress', 'Done', 'Paid'].map((status) => (
                                <div key={status} className="space-y-4 bg-muted/50 p-4 rounded-lg">
                                    <div className="flex items-center gap-2 px-2">
                                        <h4 className="font-semibold text-lg">{status === 'Paid' ? 'Company Approved' : status}</h4>
                                        <Badge variant="secondary">{tasksByStatus[status as keyof typeof tasksByStatus].length}</Badge>
                                    </div>
                                    <div className="space-y-4 rounded-lg p-2 min-h-[200px]">
                                        {tasksByStatus[status as keyof typeof tasksByStatus].length > 0 
                                            ? tasksByStatus[status as keyof typeof tasksByStatus].map(task => <TaskCard key={task.id} task={task} isCompleted={status === 'Paid'} />) 
                                            : <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-32 flex items-center justify-center">No tasks here.</div>}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </TabsContent>
                    <TabsContent value="schedule">
                       <StaffSchedulePage />
                    </TabsContent>
                </Tabs>
            </CardContent>


            <Dialog open={!!commentingTask} onOpenChange={() => setCommentingTask(null)}>
                <DialogContent className="max-w-lg">
                    <DialogHeader>
                        <DialogTitle>Comments for "{commentingTask?.title}"</DialogTitle>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <ScrollArea className="h-72 w-full rounded-md border p-4">
                            {(commentingTask?.comments || []).length > 0 ? (
                                <div className="space-y-4">
                                {(commentingTask?.comments || []).map(comment => (
                                    <div key={comment.id} className="flex gap-2.5">
                                        <Avatar className="h-8 w-8">
                                            <AvatarFallback>{comment.author.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div className="grid w-full">
                                            <div className="flex items-center gap-2">
                                                <p className="font-semibold text-sm">{comment.author}</p>
                                                <p className="text-xs text-muted-foreground">{format(new Date(comment.timestamp), 'dd MMM, p')}</p>
                                            </div>
                                            <p className="text-sm text-muted-foreground">{comment.text}</p>
                                        </div>
                                    </div>
                                ))}
                                </div>
                            ) : (
                                <p className="text-center text-muted-foreground py-12">No comments yet.</p>
                            )}
                        </ScrollArea>
                         <div className="space-y-2">
                            <Label htmlFor="new-comment">Add a comment</Label>
                            <Textarea
                                id="new-comment"
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                placeholder="Write a comment..."
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setCommentingTask(null)}>Close</Button>
                        <Button onClick={handleAddComment} disabled={!newComment.trim()}>Post Comment</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={!!subTaskingTask} onOpenChange={() => setSubTaskingTask(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Checklist for "{subTaskingTask?.title}"</DialogTitle>
                        <DialogDescription>Add, edit, and complete sub-tasks.</DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <form onSubmit={(e) => { e.preventDefault(); handleAddSubTask(); }} className="flex gap-2">
                            <Input 
                                value={newSubTask}
                                onChange={(e) => setNewSubTask(e.target.value)}
                                placeholder="Add a new sub-task..."
                            />
                            <Button type="submit" disabled={!newSubTask.trim()}>Add</Button>
                        </form>
                        <ScrollArea className="h-60 w-full rounded-md border p-2">
                           <div className="space-y-2 p-2">
                                {(subTaskingTask?.subTasks || []).length > 0 ? (
                                    (subTaskingTask?.subTasks || []).map(st => (
                                        <div key={st.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted">
                                            <Checkbox
                                                id={st.id}
                                                checked={st.completed}
                                                onCheckedChange={() => handleToggleSubTask(st.id)}
                                            />
                                            <Label htmlFor={st.id} className={cn("flex-1", st.completed && "line-through text-muted-foreground")}>
                                                {st.title}
                                            </Label>
                                        </div>
                                    ))
                                ) : (
                                    <p className="text-center text-muted-foreground py-8">No sub-tasks yet.</p>
                                )}
                           </div>
                        </ScrollArea>
                    </div>
                </DialogContent>
            </Dialog>
        </Card>
    );
}

export default function StaffTasksPage() {
    return (
        <StaffTaskManager />
    )
}
