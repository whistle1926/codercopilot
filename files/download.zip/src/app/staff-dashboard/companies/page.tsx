

"use client";

import { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { initialStaff, clients as initialClients } from '@/lib/data';
import type { StaffMember, Client, QuestionnaireSubmission } from '@/lib/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import Link from 'next/link';

function QuestionnaireReviewCard({ 
    company, 
    submission, 
    onAllocateClick,
    allStaff,
}: { 
    company: Client, 
    submission: QuestionnaireSubmission | undefined, 
    onAllocateClick: () => void,
    allStaff: StaffMember[],
}) {
    
    if (!submission) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle>{company.name}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">This company has not submitted their needs questionnaire yet.</p>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader className="flex flex-row justify-between items-start">
                <div>
                    <CardTitle>{submission.projectName || company.name}</CardTitle>
                    <CardDescription>Needs assessment submitted on {new Date(submission.submissionDate).toLocaleDateString()}</CardDescription>
                </div>
                <Button onClick={onAllocateClick}>Allocate Staff</Button>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div className="space-y-1 p-4 border rounded-lg">
                    <p className="font-semibold">Project Description</p>
                    <p className="text-muted-foreground">{submission.projectDescription || 'No description provided.'}</p>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                     <div className="space-y-1 p-4 border rounded-lg">
                        <p className="font-semibold">Expected Workload</p>
                        <p className="text-muted-foreground">{submission.workload}</p>
                    </div>
                </div>
                {submission.skills && (
                    <div className="space-y-1 p-4 border rounded-lg">
                        <p className="font-semibold">Other Information</p>
                        <p className="text-muted-foreground">{submission.skills}</p>
                    </div>
                )}
            </CardContent>
            <CardFooter>
                 <Button variant="outline" className="w-full" asChild>
                    <Link href={`/staff-dashboard/project/${company.id}`}>
                        Manage Project
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    )
}

function StaffAllocationDialog({
    open,
    onOpenChange,
    company,
    allStaff,
    onSaveAllocation,
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    company: Client | null;
    allStaff: StaffMember[];
    onSaveAllocation: (companyId: string, allocatedIds: string[]) => void;
}) {
    const [selectedStaffIds, setSelectedStaffIds] = useState<string[]>([]);

    useEffect(() => {
        if (company) {
            setSelectedStaffIds(company.allocatedStaffIds || []);
        }
    }, [company]);

    if (!company) return null;

    const availableStaff = allStaff.filter(s => !s.isTeamLead);

    const handleToggle = (staffId: string) => {
        setSelectedStaffIds(prev =>
            prev.includes(staffId) ? prev.filter(id => id !== staffId) : [...prev, staffId]
        );
    };

    const handleSave = () => {
        onSaveAllocation(company.id, selectedStaffIds);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Allocate Staff for {company.name}</DialogTitle>
                    <DialogDescription>
                        Select the professionals this company will be able to see and hire.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-4">
                        {availableStaff.map(staff => (
                            <div key={staff.id} className="flex items-center justify-between p-2 rounded-md border">
                                <div className="flex items-center gap-3">
                                    <Avatar>
                                        <AvatarImage src={staff.avatarUrl} />
                                        <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{staff.name}</p>
                                        <p className="text-sm text-muted-foreground">{staff.role}</p>
                                    </div>
                                </div>
                                <Checkbox
                                    checked={selectedStaffIds.includes(staff.id)}
                                    onCheckedChange={() => handleToggle(staff.id)}
                                />
                            </div>
                        ))}
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Allocation</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

export default function AssignedCompaniesPage() {
    const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
    const [clients, setClients] = useState<Client[]>([]);
    const [questionnaireSubmissions, setQuestionnaireSubmissions] = useState<QuestionnaireSubmission[]>([]);
    const { toast } = useToast();

    const [isAllocationOpen, setIsAllocationOpen] = useState(false);
    const [allocatingCompany, setAllocatingCompany] = useState<Client | null>(null);

    const loadData = useCallback(() => {
        const staffId = sessionStorage.getItem('loggedInStaffId');
        if (!staffId) return;

        let staffData: StaffMember[];
        try {
            const storedStaff = localStorage.getItem('hubStaff');
            staffData = storedStaff ? JSON.parse(storedStaff) : initialStaff;
        } catch {
            staffData = initialStaff;
        }
        setAllStaff(staffData);

        let clientData: Client[];
        try {
            const storedClients = localStorage.getItem('clients');
            clientData = storedClients ? JSON.parse(storedClients) : initialClients as Client[];
        } catch {
            clientData = initialClients as Client[];
        }
        // Filter clients to only those assigned to this team lead
        const assignedClients = clientData.filter(c => c.assignedTeamLeadId === staffId);
        setClients(assignedClients);

        let submissionData: QuestionnaireSubmission[];
        try {
            const storedSubmissions = localStorage.getItem('questionnaireSubmissions');
            submissionData = storedSubmissions ? JSON.parse(storedSubmissions) : [];
        } catch {
            submissionData = [];
        }
        setQuestionnaireSubmissions(submissionData);
    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);
  
    const openAllocationDialog = (company: Client) => {
        setAllocatingCompany(company);
        setIsAllocationOpen(true);
    }

    const handleSaveAllocation = (companyId: string, allocatedIds: string[]) => {
        const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
        const updatedClients = allClients.map(c => c.id === companyId ? { ...c, allocatedStaffIds: allocatedIds } : c);
        localStorage.setItem('clients', JSON.stringify(updatedClients));
        loadData(); // Reload data to reflect changes
        toast({
            title: 'Staff Allocated',
            description: `Staff allocation for ${clients.find(c => c.id === companyId)?.name} has been updated.`
        });
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Assigned Companies</CardTitle>
                    <CardDescription>Review questionnaires and allocate staff for your assigned companies.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {clients.length > 0 ? clients.map(company => {
                        const submission = questionnaireSubmissions.find(s => s.companyId === company.id);
                        return (
                            <QuestionnaireReviewCard
                                key={company.id}
                                company={company}
                                submission={submission}
                                onAllocateClick={() => openAllocationDialog(company)}
                                allStaff={allStaff}
                            />
                        )
                    }) : (
                        <p className="text-muted-foreground text-center py-8">No companies have been assigned to you yet.</p>
                    )}
                </CardContent>
            </Card>

            <StaffAllocationDialog
                open={isAllocationOpen}
                onOpenChange={setIsAllocationOpen}
                company={allocatingCompany}
                allStaff={allStaff}
                onSaveAllocation={handleSaveAllocation}
            />
        </div>
    );
}

    
