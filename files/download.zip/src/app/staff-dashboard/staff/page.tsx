
"use client";

import { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ArrowDown, ArrowUp, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { initialStaff as initialStaffData } from '@/lib/data';
import type { StaffMember } from '@/lib/types';

type SortKey = keyof StaffMember | 'rate' | 'costRate';
type SortDirection = 'asc' | 'desc';

export default function AvailableStaffPage() {
  const [staffList, setStaffList] = useState<StaffMember[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState<{
    key: SortKey;
    direction: SortDirection;
  } | null>({ key: 'rate', direction: 'asc' });

  const loadData = useCallback(() => {
    const storedStaff = localStorage.getItem('hubStaff');
    let staffData: StaffMember[];
    if (storedStaff) {
      staffData = JSON.parse(storedStaff).filter((s: StaffMember) => s.isVisible && !s.isTeamLead);
    } else {
      staffData = initialStaffData.filter(s => s.isVisible && !s.isTeamLead);
    }
    setStaffList(staffData);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);
  
  const allRoles = useMemo(() => {
      return Array.from(new Set(staffList.map(s => s.role))).sort();
  }, [staffList]);

  const sortedStaff = useMemo(() => {
    let sortableItems = [...staffList];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const valA = a[sortConfig.key as keyof StaffMember] || 0;
        const valB = b[sortConfig.key as keyof StaffMember] || 0;
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [sortConfig, staffList]);

  const filteredStaff = useMemo(() => {
    return sortedStaff.filter((staffMember) => {
        const matchesSearch =
            staffMember.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            staffMember.role.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = roleFilter === 'all' || staffMember.role === roleFilter;
        return matchesSearch && matchesRole;
    });
  }, [searchTerm, sortedStaff, roleFilter]);

  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIcon = (key: SortKey) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Available Staff for Allocation</CardTitle>
        <CardDescription>A read-only view of all professionals available on the platform.</CardDescription>
        <div className="mt-4 flex gap-4">
            <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                    placeholder="Search by name or role..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {allRoles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                </SelectContent>
            </Select>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Professional</TableHead>
              <TableHead>
                  <button className="flex items-center gap-1" onClick={() => requestSort('rate')}>
                      Rate {getSortIcon('rate')}
                  </button>
              </TableHead>
              <TableHead>Availability</TableHead>
              <TableHead>Experience</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStaff.map((staff) => (
              <TableRow key={staff.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={staff.avatarUrl} alt={staff.name} />
                      <AvatarFallback>{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{staff.name}</p>
                      <p className="text-sm text-muted-foreground">{staff.role}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="font-mono">£{staff.rate.toFixed(2)}/hr</TableCell>
                <TableCell>
                  <Badge variant={staff.availability === 'Available For Hire' ? 'default' : 'secondary'} className={cn(staff.availability === 'Available For Hire' && 'bg-green-500')}>
                    {staff.availability}
                  </Badge>
                </TableCell>
                <TableCell>{staff.experience}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
