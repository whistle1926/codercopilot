

"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { StaffMember, Client, HourRequest, TimeLimit, DayOfWeek, CostLimits, Task, TaskStatus, TaskPriority, Comment, SubTask, Skill, ProjectUpdate } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { initialStaff, clients as initialClientsData } from '@/lib/data';
import { Loader2, ArrowLeft, Send, Lock, Unlock, Eye, Users, PlusCircle, Award, UserMinus, Trash2, Edit, Pencil, Bold, Italic, Code, List, ListOrdered, ChevronsUpDown } from 'lucide-react';
import Link from 'next/link';
import { Table, TableBody, TableCell, TableHeader, TableRow, TableHead } from '@/components/ui/table';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { parse, differenceInMilliseconds, formatDistanceToNow } from 'date-fns';
import { toZonedTime, fromZonedTime, format } from 'date-fns-tz';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ListChecks, MessageSquare, CalendarIcon, RotateCcw, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface StaffTasks {
    [staffId: string]: {
        [companyId: string]: Task[];
    };
}

function StaffAllocationDialog({
    open,
    onOpenChange,
    company,
    allStaff,
    onSaveAllocation,
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    company: Client | null;
    allStaff: StaffMember[];
    onSaveAllocation: (companyId: string, allocatedIds: string[]) => void;
}) {
    const [selectedStaffIds, setSelectedStaffIds] = useState<string[]>([]);

    useEffect(() => {
        if (company) {
            setSelectedStaffIds(company.allocatedStaffIds || []);
        }
    }, [company]);

    if (!company) return null;

    const availableStaff = allStaff.filter(s => !s.isTeamLead);

    const handleToggle = (staffId: string) => {
        setSelectedStaffIds(prev =>
            prev.includes(staffId) ? prev.filter(id => id !== staffId) : [...prev, staffId]
        );
    };

    const handleSave = () => {
        onSaveAllocation(company.id, selectedStaffIds);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Allocate Staff for {company.name}</DialogTitle>
                    <DialogDescription>
                        Select the professionals this company will be able to see and hire.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-4">
                        {availableStaff.map(staff => (
                            <div key={staff.id} className="flex items-center justify-between p-2 rounded-md border">
                                <div className="flex items-center gap-3">
                                    <Avatar>
                                        <AvatarImage src={staff.avatarUrl} />
                                        <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{staff.name}</p>
                                        <p className="text-sm text-muted-foreground">{staff.role}</p>
                                    </div>
                                </div>
                                <Checkbox
                                    checked={selectedStaffIds.includes(staff.id)}
                                    onCheckedChange={() => handleToggle(staff.id)}
                                />
                            </div>
                        ))}
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Allocation</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function TeamMemberCard({ staff }: { staff: StaffMember }) {
    const SkillBar = ({ skill }: { skill: Skill }) => (
         <div>
            <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">{skill.name}</span>
                <div className="flex items-center gap-2">
                    {skill.years > 0 && <span className="text-xs text-muted-foreground w-10 text-right">{skill.years} yrs</span>}
                    <Badge 
                        variant={skill.level === 'Expert' ? 'default' : 'secondary'} 
                        className={cn(
                            'w-[85px] justify-center', 
                            skill.level === 'Expert' && 'bg-green-600'
                        )}
                    >
                        {skill.level}
                    </Badge>
                </div>
            </div>
            <Progress value={skill.level === 'Expert' ? 100 : skill.level === 'Advanced' ? 80 : 60} className="h-2" />
        </div>
    );

    return (
        <Card>
            <CardHeader className="flex flex-row items-center gap-4">
                <Avatar className="h-16 w-16">
                    <AvatarImage src={staff.avatarUrl} />
                    <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                    <CardTitle>{staff.name}</CardTitle>
                    <CardDescription>{staff.role}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <h4 className="font-semibold text-sm mb-2">About</h4>
                    <p className="text-sm text-muted-foreground">{staff.about}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <h4 className="font-semibold text-sm mb-2">Technical Skills</h4>
                        <div className="space-y-2">
                            {staff.technicalSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold text-sm mb-2">Soft Skills</h4>
                        <div className="space-y-2">
                            {staff.softSkills.map((skill, i) => <SkillBar key={i} skill={skill} />)}
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function RestrictionsManager({ staff, onStaffUpdate, company }: { staff: StaffMember, onStaffUpdate: (updatedStaff: StaffMember) => void, company: Client }) {
    const { toast } = useToast();
    const [costLimits, setCostLimits] = useState<CostLimits>(staff.costLimits || {});
    const [timeLimits, setTimeLimits] = useState<TimeLimit[]>(staff.timeLimits || []);
    const [isLocked, setIsLocked] = useState(staff.isLocked || false);
    const [isOpen, setIsOpen] = useState(false);

    const companyTimezone = company?.timezone || 'Europe/London';
    const staffTimezone = staff.timezone || 'Asia/Manila';
    
    useEffect(() => {
        let totalWeeklyHours = 0;
        let maxDailyHours = 0;

        timeLimits.forEach(limit => {
            if (limit.startTime && limit.endTime) {
                try {
                    const start = parse(limit.startTime, 'HH:mm', new Date());
                    const end = parse(limit.endTime, 'HH:mm', new Date());
                    const dailyMilliseconds = differenceInMilliseconds(end, start);
                    const dailyHours = dailyMilliseconds > 0 ? dailyMilliseconds / (1000 * 60 * 60) : 0;
                    
                    if (dailyHours > 0) {
                        totalWeeklyHours += dailyHours;
                        if (dailyHours > maxDailyHours) {
                            maxDailyHours = dailyHours;
                        }
                    }
                } catch (e) {
                }
            }
        });

        const rate = staff.rate;
        const dailyLimit = maxDailyHours * rate;
        const weeklyLimit = totalWeeklyHours * rate;
        const monthlyLimit = weeklyLimit * 4;

        setCostLimits({
            daily: parseFloat(dailyLimit.toFixed(2)),
            weekly: parseFloat(weeklyLimit.toFixed(2)),
            monthly: parseFloat(monthlyLimit.toFixed(2)),
        });
    }, [timeLimits, staff.rate]);


    const days: DayOfWeek[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    const handleTimeLimitChange = (day: DayOfWeek, field: 'startTime' | 'endTime', value: string) => {
        let updated = [...timeLimits];
        const existing = updated.find(t => t.day === day);
        if (existing) {
            updated = updated.map(t => t.day === day ? { ...t, [field]: value } : t);
        } else {
            updated.push({ day, startTime: field === 'startTime' ? value : '', endTime: field === 'endTime' ? value : '' });
        }
        setTimeLimits(updated);
    };

    const handleDayToggle = (day: DayOfWeek, checked: boolean) => {
        let updated = [...timeLimits];
        if (checked) {
            if (!updated.some(t => t.day === day)) {
                updated.push({ day, startTime: '09:00', endTime: '17:00' });
            }
        } else {
            updated = updated.filter(t => t.day !== day);
        }
        setTimeLimits(updated.sort((a, b) => days.indexOf(a.day) - days.indexOf(b.day)));
    };
    
    const handleSaveAndSubmit = () => {
        const requestId = `req_${company.id}_${staff.id}`;
        const newRequest: HourRequest = {
            id: requestId,
            companyId: company.id,
            staffId: staff.id,
            timeLimits: timeLimits,
            status: 'Pending Approval',
            requestDate: new Date().toISOString(),
        };

        const existingRequests = JSON.parse(localStorage.getItem('scheduleRequests') || '{}');
        const updatedRequests = { ...existingRequests, [requestId]: newRequest };
        localStorage.setItem('scheduleRequests', JSON.stringify(updatedRequests));

        window.dispatchEvent(new StorageEvent('storage', { key: 'scheduleRequests' }));
        
        toast({ title: 'Schedule Submitted', description: `Work schedule for ${staff.name} has been sent to ${company.name} for approval.` });
    };

    const convertAndFormatTime = (time: string, fromTz: string, toTz: string) => {
        if (!time) return '--:--';
        try {
            const today = new Date();
            const [hours, minutes] = time.split(':').map(Number);
            const sourceDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), hours, minutes);
            
            const zonedDate = fromZonedTime(sourceDate, fromTz);
            const targetDate = toZonedTime(zonedDate, toTz);

            return format(targetDate, 'HH:mm');
        } catch (e) {
            return 'Invalid';
        }
    };
    
    return (
        <Card className="mt-4 overflow-hidden">
            <Collapsible open={isOpen} onOpenChange={setIsOpen}>
                <div className="flex items-center justify-between p-4">
                     <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                            <AvatarImage src={staff.avatarUrl} />
                            <AvatarFallback>{staff.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <p className="text-xl font-bold">{staff.name}</p>
                            <p className="text-sm text-muted-foreground">{staff.role}</p>
                        </div>
                    </div>
                    <CollapsibleTrigger asChild>
                        <Button variant="outline">
                            <Eye className="mr-2 h-4 w-4" />
                            View / Edit Schedule
                        </Button>
                    </CollapsibleTrigger>
                </div>
                <CollapsibleContent className="space-y-6">
                    <CardContent className="space-y-6 pt-0">
                        <div className="space-y-4 rounded-lg border p-4">
                            <h4 className="font-semibold">Cost Limits</h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor={`daily-limit-${staff.id}`}>Daily Limit (£)</Label>
                                    <Input id={`daily-limit-${staff.id}`} type="number" value={costLimits.daily ?? ''} readOnly className="bg-muted" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`weekly-limit-${staff.id}`}>Weekly Limit (£)</Label>
                                    <Input id={`weekly-limit-${staff.id}`} type="number" value={costLimits.weekly ?? ''} readOnly className="bg-muted" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`monthly-limit-${staff.id}`}>Monthly Limit (£)</Label>
                                    <Input id={`monthly-limit-${staff.id}`} type="number" value={costLimits.monthly ?? ''} readOnly className="bg-muted" />
                                </div>
                            </div>
                        </div>
                        <div className="space-y-4 rounded-lg border p-4">
                            <div className="flex justify-between items-center">
                              <h4 className="font-semibold">Allowed Working Hours</h4>
                              <div className="flex gap-4 text-sm text-muted-foreground">
                                <span>Company Time ({companyTimezone.split('/').pop()?.replace('_', ' ')})</span>
                                <span>Staff Time ({staffTimezone.split('/').pop()?.replace('_', ' ')})</span>
                              </div>
                            </div>
                            <div className="space-y-4">
                                {days.map(day => {
                                    const limit = timeLimits.find(t => t.day === day);
                                    return (
                                        <div key={day} className="flex flex-col sm:flex-row items-center gap-4">
                                            <Checkbox id={`day-${day}-${staff.id}`} checked={!!limit} onCheckedChange={(checked) => handleDayToggle(day, !!checked)} className="sm:mt-6" />
                                            <Label htmlFor={`day-${day}-${staff.id}`} className="w-24 font-semibold">{day}</Label>
                                            <div className="grid grid-cols-2 gap-2 flex-1">
                                                <div className="space-y-1">
                                                    <Label htmlFor={`start-${day}-${staff.id}`} className="text-xs">Start Time</Label>
                                                    <Input id={`start-${day}-${staff.id}`} type="time" value={limit?.startTime || ''} onChange={e => handleTimeLimitChange(day, 'startTime', e.target.value)} disabled={!limit} />
                                                     {limit?.startTime && <p className="text-xs text-muted-foreground">Staff time: {convertAndFormatTime(limit.startTime, companyTimezone, staffTimezone)}</p>}
                                                </div>
                                                <div className="space-y-1">
                                                    <Label htmlFor={`end-${day}-${staff.id}`} className="text-xs">End Time</Label>
                                                    <Input id={`end-${day}-${staff.id}`} type="time" value={limit?.endTime || ''} onChange={e => handleTimeLimitChange(day, 'endTime', e.target.value)} disabled={!limit} />
                                                    {limit?.endTime && <p className="text-xs text-muted-foreground">Staff time: {convertAndFormatTime(limit.endTime, companyTimezone, staffTimezone)}</p>}
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    </CardContent>
                    <CardFooter>
                         <Button onClick={handleSaveAndSubmit}>
                            <Send className="mr-2 h-4 w-4" />
                            Submit Schedule to Company for Approval
                        </Button>
                    </CardFooter>
                </CollapsibleContent>
            </Collapsible>
        </Card>
    );
}

function ProjectUpdates({ company, onUpdate }: { company: Client; onUpdate: (updates: ProjectUpdate[]) => void }) {
    const [newUpdate, setNewUpdate] = useState('');
    const [teamLeadName, setTeamLeadName] = useState('Team Lead');
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const maxChars = 500;

    const [editingUpdate, setEditingUpdate] = useState<ProjectUpdate | null>(null);
    const [updateTimestamp, setUpdateTimestamp] = useState(false);
    const [deletingUpdateId, setDeletingUpdateId] = useState<string | null>(null);

    useEffect(() => {
        const staffId = localStorage.getItem('loggedInStaffId');
        if (staffId) {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const lead = allStaff.find(s => s.id === staffId);
            if (lead) {
                setTeamLeadName(lead.name);
            }
        }
    }, []);

    const handlePostUpdate = () => {
        if (!newUpdate.trim()) return;
        
        let finalUpdates: ProjectUpdate[];

        if (editingUpdate) {
            finalUpdates = (company.projectUpdates || []).map(up => {
                if (up.id === editingUpdate.id) {
                    return {
                        ...up,
                        content: newUpdate,
                        date: updateTimestamp ? new Date().toISOString() : up.date,
                    };
                }
                return up;
            });
        } else {
             const update: ProjectUpdate = {
                id: `update-${Date.now()}`,
                date: new Date().toISOString(),
                author: teamLeadName,
                content: newUpdate,
            };
            finalUpdates = [update, ...(company.projectUpdates || [])];
        }

        onUpdate(finalUpdates);
        setNewUpdate('');
        setEditingUpdate(null);
        setUpdateTimestamp(false);
    };

    const handleEditClick = (update: ProjectUpdate) => {
        setEditingUpdate(update);
        setNewUpdate(update.content);
        setUpdateTimestamp(false);
    };
    
    const handleCancelEdit = () => {
        setEditingUpdate(null);
        setNewUpdate('');
        setUpdateTimestamp(false);
    }
    
    const handleDelete = () => {
        if (!deletingUpdateId) return;
        const finalUpdates = (company.projectUpdates || []).filter(up => up.id !== deletingUpdateId);
        onUpdate(finalUpdates);
        setDeletingUpdateId(null);
    }

    const applyFormat = (formatType: 'bold' | 'italic' | 'code' | 'bullet' | 'numbered-list') => {
        const textarea = textareaRef.current;
        if (!textarea) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = newUpdate.substring(start, end);
        let formattedText;

        switch (formatType) {
            case 'bold':
                formattedText = `**${selectedText}**`;
                break;
            case 'italic':
                formattedText = `*${selectedText}*`;
                break;
            case 'code':
                formattedText = `\`${selectedText}\``;
                break;
            case 'bullet':
                 if (selectedText.length > 0) {
                    formattedText = selectedText.split('\n').map(line => `• ${line}`).join('\n');
                 } else {
                    formattedText = `• `;
                 }
                break;
            case 'numbered-list':
                 if (selectedText.length > 0) {
                    formattedText = selectedText.split('\n').map((line, index) => `${index + 1}. ${line}`).join('\n');
                 } else {
                    formattedText = `1. `;
                 }
                break;
        }

        const newText = newUpdate.substring(0, start) + formattedText + newUpdate.substring(end);
        setNewUpdate(newText);
        
        setTimeout(() => {
            textarea.focus();
            textarea.selectionStart = textarea.selectionEnd = start + formattedText.length;
        }, 0);
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter') {
            const textarea = e.currentTarget;
            const start = textarea.selectionStart;
            const text = textarea.value;
            const lineStart = text.lastIndexOf('\n', start - 1) + 1;
            const currentLine = text.substring(lineStart, start);

            const bulletMatch = currentLine.match(/^(\s*•\s)/);
            const numberMatch = currentLine.match(/^(\s*)(\d+)\.\s/);
            
            if (currentLine.trim() === '•' || (numberMatch && currentLine.trim() === `${numberMatch[2]}.`)) {
                 const newText = text.substring(0, lineStart) + text.substring(start);
                 setNewUpdate(newText);
                 setTimeout(() => {
                     textarea.selectionStart = textarea.selectionEnd = lineStart;
                 }, 0);
                 e.preventDefault();
            } else if (bulletMatch) {
                e.preventDefault();
                const newText = `${text.substring(0, start)}\n${bulletMatch[1]}`;
                setNewUpdate(newText);
                setTimeout(() => {
                    textarea.selectionStart = textarea.selectionEnd = start + bulletMatch[1].length + 1;
                }, 0);
            } else if (numberMatch) {
                e.preventDefault();
                const indent = numberMatch[1] || '';
                const nextNumber = parseInt(numberMatch[2]) + 1;
                const newItem = `${indent}${nextNumber}. `;
                const newText = `${text.substring(0, start)}\n${newItem}`;
                setNewUpdate(newText);
                 setTimeout(() => {
                    textarea.selectionStart = textarea.selectionEnd = start + newItem.length + 1;
                }, 0);
            }
        }
    };

    return (
        <Card>
            <Collapsible defaultOpen>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>Project Progress Updates</CardTitle>
                            <CardDescription>Post updates for the company to see.</CardDescription>
                        </div>
                        <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm">
                                <ChevronsUpDown className="h-4 w-4" />
                                <span className="sr-only">Toggle</span>
                            </Button>
                        </CollapsibleTrigger>
                    </div>
                </CardHeader>
                <CollapsibleContent>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="new-update">{editingUpdate ? 'Edit Update' : 'New Update'}</Label>
                            <div className="rounded-md border">
                                <div className="p-2 border-b flex items-center gap-1">
                                    <Button type="button" variant="ghost" size="icon" onClick={() => applyFormat('bold')}><Bold className="h-4 w-4" /></Button>
                                    <Button type="button" variant="ghost" size="icon" onClick={() => applyFormat('italic')}><Italic className="h-4 w-4" /></Button>
                                    <Button type="button" variant="ghost" size="icon" onClick={() => applyFormat('code')}><Code className="h-4 w-4" /></Button>
                                    <Button type="button" variant="ghost" size="icon" onClick={() => applyFormat('bullet')}><List className="h-4 w-4" /></Button>
                                    <Button type="button" variant="ghost" size="icon" onClick={() => applyFormat('numbered-list')}><ListOrdered className="h-4 w-4" /></Button>
                                </div>
                                <Textarea 
                                    id="new-update"
                                    ref={textareaRef}
                                    value={newUpdate}
                                    onChange={(e) => setNewUpdate(e.target.value)}
                                    onKeyDown={handleKeyDown}
                                    placeholder="Share an update on the project status..."
                                    rows={4}
                                    className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                                    maxLength={maxChars}
                                />
                                <div className="p-2 border-t text-xs text-right text-muted-foreground">
                                    {newUpdate.length} / {maxChars}
                                </div>
                            </div>
                        </div>
                        {editingUpdate && (
                            <div className="flex items-center space-x-2">
                                <Checkbox id="update-timestamp" checked={updateTimestamp} onCheckedChange={(checked) => setUpdateTimestamp(!!checked)} />
                                <Label htmlFor="update-timestamp">Update timestamp to current time</Label>
                            </div>
                        )}
                        <div className="flex gap-2">
                            <Button onClick={handlePostUpdate}>{editingUpdate ? 'Save Changes' : 'Post Update'}</Button>
                            {editingUpdate && (
                                <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
                            )}
                        </div>
                        <Separator />
                        <h4 className="font-semibold">Update History</h4>
                        <ScrollArea className="h-64 border rounded-md p-4">
                            <div className="space-y-4">
                                {(company.projectUpdates || []).length > 0 ? (
                                    (company.projectUpdates || []).map(update => (
                                        <div key={update.id} className="text-sm group relative">
                                            {update.author === teamLeadName && (
                                                <div className="absolute top-0 right-0 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleEditClick(update)}>
                                                        <Edit className="h-4 w-4" />
                                                    </Button>
                                                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setDeletingUpdateId(update.id)}>
                                                        <Trash2 className="h-4 w-4 text-destructive" />
                                                    </Button>
                                                </div>
                                            )}
                                            <p className="text-muted-foreground">
                                                <span className="font-semibold text-foreground">{update.author}</span> posted {formatDistanceToNow(new Date(update.date), { addSuffix: true })}
                                                {update.date !== new Date(update.date).toISOString() && ' (edited)'}
                                            </p>
                                            <p>{update.content}</p>
                                        </div>
                                    ))
                                ) : (
                                    <p className="text-muted-foreground text-center py-8">No updates have been posted yet.</p>
                                )}
                            </div>
                        </ScrollArea>
                    </CardContent>
                </CollapsibleContent>
            </Collapsible>
            <AlertDialog open={!!deletingUpdateId} onOpenChange={() => setDeletingUpdateId(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will permanently delete this update. This action cannot be undone.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </Card>
    );
}

const ProjectStaffRow: React.FC<{
  staff: StaffMember;
  tasks: Task[];
  onTasksUpdate: (updatedTasks: Task[]) => void;
  company: Client;
}> = ({ staff, tasks, onTasksUpdate, company }) => {
    const { toast } = useToast();
    const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
    const [editingTask, setEditingTask] = useState<Task | null>(null);
    const [commentingTask, setCommentingTask] = useState<Task | null>(null);
    const [newComment, setNewComment] = useState('');
    const [subTaskingTask, setSubTaskingTask] = useState<Task | null>(null);
    const [newSubTask, setNewSubTask] = useState('');
    
    const weeklyCost = useMemo(() => {
        if (!staff.timeLimits) return 0;
        let totalWeeklyHours = 0;
        staff.timeLimits.forEach(limit => {
            if (limit.startTime && limit.endTime) {
                try {
                    const start = parse(limit.startTime, 'HH:mm', new Date());
                    const end = parse(limit.endTime, 'HH:mm', new Date());
                    const dailyMilliseconds = differenceInMilliseconds(end, start);
                    if (dailyMilliseconds > 0) {
                        const dailyHours = dailyMilliseconds / (1000 * 60 * 60);
                        totalWeeklyHours += dailyHours;
                    }
                } catch (e) {}
            }
        });
        return totalWeeklyHours * staff.rate;
    }, [staff.timeLimits, staff.rate]);

    const tasksByStatus = useMemo(() => ({
        'To Do': tasks.filter(t => t.status === 'To Do'),
        'In Progress': tasks.filter(t => t.status === 'In Progress'),
        'Done': tasks.filter(t => t.status === 'Done'),
        'Approved': tasks.filter(t => t.status === 'Approved'),
        'Paid': tasks.filter(t => t.status === 'Paid'),
    }), [tasks]);

    const handleSaveTask = (taskData: { title: string, details: string, dueDate?: Date, priority: TaskPriority }) => {
        let updatedTasks;
        if (editingTask) {
            updatedTasks = tasks.map(task => 
                task.id === editingTask.id ? { ...task, ...taskData } : task
            );
        } else {
            const newTask: Task = {
                id: `task-${Date.now()}`,
                ...taskData,
                status: 'To Do',
                hoursLogged: 0,
                comments: [],
                subTasks: [],
                cost: 0,
            };
            updatedTasks = [newTask, ...tasks];
        }
        onTasksUpdate(updatedTasks);
        toast({ title: 'Task Saved', description: 'Your changes have been saved.' });
        setIsTaskFormOpen(false);
        setEditingTask(null);
    };

    const openTaskForm = (task: Task | null) => {
        setEditingTask(task);
        setIsTaskFormOpen(true);
    };

    const handleDeleteTask = (taskId: string) => {
        const updatedTasks = tasks.filter(task => task.id !== taskId);
        onTasksUpdate(updatedTasks);
    };

     const handleAddComment = () => {
        if (!commentingTask || !newComment.trim()) return;

        const comment: Comment = {
            id: `comment-${Date.now()}`,
            author: 'Team Lead',
            text: newComment,
            timestamp: new Date().toISOString(),
        };

        const updatedTasks = tasks.map(task =>
            task.id === commentingTask.id ? { ...task, comments: [...(task.comments || []), comment] } : task
        );
        onTasksUpdate(updatedTasks);
        setNewComment('');
    };

    const handleAddSubTask = () => {
        if (!subTaskingTask || !newSubTask.trim()) return;
        const subTask: SubTask = { id: `subtask-${Date.now()}`, title: newSubTask, completed: false };
        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id ? { ...task, subTasks: [...(task.subTasks || []), subTask] } : task
        );
        onTasksUpdate(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: [...(prev.subTasks || []), subTask] } : null);
        setNewSubTask('');
    };

    const handleToggleSubTask = (subTaskId: string) => {
        if (!subTaskingTask) return;
        const updatedSubTasks = (subTaskingTask.subTasks || []).map(st =>
            st.id === subTaskId ? { ...st, completed: !st.completed } : st
        );
        const updatedTasks = tasks.map(task =>
            task.id === subTaskingTask.id ? { ...task, subTasks: updatedSubTasks } : task
        );
        onTasksUpdate(updatedTasks);
        setSubTaskingTask(prev => prev ? { ...prev, subTasks: updatedSubTasks } : null);
    };

    const TaskCard = ({ task, isCompleted = false }: { task: Task; isCompleted?: boolean }) => {
        const priorityConfig = { High: { icon: Flag, color: "text-red-500" }, Medium: { icon: Flag, color: "text-yellow-500" }, Low: { icon: Flag, color: "text-gray-400" } };
        const PriorityIcon = priorityConfig[task.priority].icon;
        const completedSubTasks = (task.subTasks || []).filter(st => st.completed).length;
        const totalSubTasks = (task.subTasks || []).length;
        const subTaskProgress = totalSubTasks > 0 ? (completedSubTasks / totalSubTasks) * 100 : 0;

        return (
            <Card className="bg-background shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-4 space-y-3">
                    <div className="flex justify-between items-start">
                        <p className="font-semibold leading-tight">{task.title}</p>
                        <div className="flex items-center gap-1">
                             <PriorityIcon className={cn("h-4 w-4", priorityConfig[task.priority].color)} />
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openTaskForm(task)}><Edit className="h-4 w-4 text-muted-foreground" /></Button>
                             <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleDeleteTask(task.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </div>
                    </div>
                    {task.details && <p className="text-sm text-muted-foreground">{task.details}</p>}
                    {totalSubTasks > 0 && (
                        <div className="space-y-1">
                            <div className="flex justify-between items-center text-xs text-muted-foreground"><span>Checklist Progress</span><span>{completedSubTasks} / {totalSubTasks}</span></div>
                            <Progress value={subTaskProgress} className="h-2" />
                        </div>
                    )}
                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                        {task.dueDate && <div className="flex items-center gap-1.5"><CalendarIcon className="h-4 w-4"/><span>{format(new Date(task.dueDate), 'dd MMM')}</span></div>}
                         <div className="flex items-center gap-1">
                             <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setSubTaskingTask(task)}><ListChecks className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 relative" onClick={() => setCommentingTask(task)}>
                                <MessageSquare className="h-4 w-4" />
                                {task.comments?.length > 0 && <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 justify-center p-0">{task.comments.length}</Badge>}
                            </Button>
                         </div>
                    </div>
                </CardContent>
            </Card>
        )
    }

    return (
        <>
            <CollapsibleContent asChild>
                <TableRow>
                    <TableCell colSpan={5} className="p-0">
                        <div className="bg-muted/50 p-6">
                             <Tabs defaultValue="board">
                                <div className="flex justify-between items-center mb-6">
                                    <TabsList>
                                        <TabsTrigger value="board">Task Board</TabsTrigger>
                                        <TabsTrigger value="project-team">Project Team</TabsTrigger>
                                    </TabsList>
                                    <Button onClick={() => openTaskForm(null)}><PlusCircle className="mr-2 h-4 w-4" /> Add New Task</Button>
                                </div>
                                <TabsContent value="board">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                        {['To Do', 'In Progress', 'Done', 'Paid'].map((status) => (
                                            <div key={status} className="space-y-4 bg-card p-4 rounded-lg shadow-sm">
                                                <div className="flex items-center gap-2 px-2"><h4 className="font-semibold text-lg">{status === 'Paid' ? 'Company Approved' : status}</h4><Badge variant="secondary">{tasksByStatus[status as keyof typeof tasksByStatus].length}</Badge></div>
                                                <div className="space-y-4 rounded-lg p-2 min-h-[200px]">
                                                    {tasksByStatus[status as keyof typeof tasksByStatus].length > 0 ? tasksByStatus[status as keyof typeof tasksByStatus].map(task => <TaskCard key={task.id} task={task} isCompleted={status === 'Paid'} />) : <div className="text-center text-muted-foreground pt-8 border-2 border-dashed rounded-lg h-32 flex items-center justify-center">No tasks here.</div>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </TabsContent>
                                <TabsContent value="project-team">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <TeamMemberCard staff={staff} />
                                    </div>
                                </TabsContent>
                             </Tabs>
                        </div>
                    </TableCell>
                </TableRow>
            </CollapsibleContent>
            <TaskFormDialog open={isTaskFormOpen} onOpenChange={setIsTaskFormOpen} task={editingTask} onSave={handleSaveTask} />
            <Dialog open={!!commentingTask} onOpenChange={() => setCommentingTask(null)}>
                <DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Comments for "{commentingTask?.title}"</DialogTitle></DialogHeader>
                    <div className="py-4 space-y-4"><ScrollArea className="h-72 w-full rounded-md border p-4">{(commentingTask?.comments || []).length > 0 ? <div className="space-y-4">{(commentingTask?.comments || []).map(comment => <div key={comment.id} className="flex gap-2.5"><Avatar className="h-8 w-8"><AvatarFallback>{comment.author.charAt(0)}</AvatarFallback></Avatar><div className="grid w-full"><div className="flex items-center gap-2"><p className="font-semibold text-sm">{comment.author}</p><p className="text-xs text-muted-foreground">{format(new Date(comment.timestamp), 'dd MMM, p')}</p></div><p className="text-sm text-muted-foreground">{comment.text}</p></div></div>)}</div> : <p className="text-center text-muted-foreground py-12">No comments yet.</p>}</ScrollArea><div className="space-y-2"><Label htmlFor="new-comment">Add a comment</Label><Textarea id="new-comment" value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Write a comment..." /></div></div>
                    <DialogFooter><Button variant="outline" onClick={() => setCommentingTask(null)}>Close</Button><Button onClick={handleAddComment} disabled={!newComment.trim()}>Post Comment</Button></DialogFooter>
                </DialogContent>
            </Dialog>
            <Dialog open={!!subTaskingTask} onOpenChange={() => setSubTaskingTask(null)}>
                <DialogContent><DialogHeader><DialogTitle>Checklist for "{subTaskingTask?.title}"</DialogTitle><DialogDescription>Add, edit, and complete sub-tasks.</DialogDescription></DialogHeader>
                    <div className="py-4 space-y-4"><form onSubmit={(e) => { e.preventDefault(); handleAddSubTask(); }} className="flex gap-2"><Input value={newSubTask} onChange={(e) => setNewSubTask(e.target.value)} placeholder="Add a new sub-task..." /><Button type="submit" disabled={!newSubTask.trim()}>Add</Button></form><ScrollArea className="h-60 w-full rounded-md border p-2"><div className="space-y-2 p-2">{(subTaskingTask?.subTasks || []).length > 0 ? ((subTaskingTask?.subTasks || []).map(st => <div key={st.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted"><Checkbox id={st.id} checked={st.completed} onCheckedChange={() => handleToggleSubTask(st.id)} /><Label htmlFor={st.id} className={cn("flex-1", st.completed && "line-through text-muted-foreground")}>{st.title}</Label></div>)) : <p className="text-center text-muted-foreground py-8">No sub-tasks yet.</p>}</div></ScrollArea></div>
                </DialogContent>
            </Dialog>
        </>
    )
}

function TaskFormDialog({ open, onOpenChange, task, onSave }: { open: boolean; onOpenChange: (open: boolean) => void; task: Task | null, onSave: (taskData: { title: string, details: string, dueDate?: Date, priority: TaskPriority }) => void }) {
    const [title, setTitle] = useState('');
    const [details, setDetails] = useState('');
    const [dueDate, setDueDate] = useState<Date | undefined>();
    const [priority, setPriority] = useState<TaskPriority>('Medium');

    useEffect(() => {
        if (task) {
            setTitle(task.title);
            setDetails(task.details);
            setDueDate(task.dueDate ? new Date(task.dueDate) : undefined);
            setPriority(task.priority);
        } else {
            setTitle('');
            setDetails('');
            setDueDate(undefined);
            setPriority('Medium');
        }
    }, [task, open]);

    const handleSaveClick = () => {
        onSave({ title, details, dueDate, priority });
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader><DialogTitle>{task ? 'Edit Task' : 'Add New Task'}</DialogTitle></DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2"><Label htmlFor="task-title">Task Title</Label><Input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} /></div>
                    <div className="space-y-2"><Label htmlFor="task-details">Details</Label><Textarea id="task-details" value={details} onChange={(e) => setDetails(e.target.value)} /></div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2"><Label>Due Date</Label><Popover><PopoverTrigger asChild><Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !dueDate && "text-muted-foreground")}><CalendarIcon className="mr-2 h-4 w-4" />{dueDate ? format(new Date(dueDate), "PPP") : <span>Pick a date</span>}</Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar mode="single" selected={dueDate} onSelect={setDueDate} initialFocus /></PopoverContent></Popover></div>
                        <div className="space-y-2"><Label>Priority</Label><Select value={priority} onValueChange={(v: TaskPriority) => setPriority(v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="High">High</SelectItem><SelectItem value="Medium">Medium</SelectItem><SelectItem value="Low">Low</SelectItem></SelectContent></Select></div>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSaveClick}>Save Task</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

export default function ProjectManagementPage() {
    const params = useParams();
    const router = useRouter();
    const companyId = params.id as string;
    const { toast } = useToast();

    const [teamLead, setTeamLead] = useState<StaffMember | null>(null);
    const [company, setCompany] = useState<Client | null>(null);
    const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
    const [allocatedStaff, setAllocatedStaff] = useState<StaffMember[]>([]);
    const [allTasks, setAllTasks] = useState<StaffTasks>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isAllocationOpen, setIsAllocationOpen] = useState(false);

    const projectTeam = useMemo(() => {
        if (!teamLead) return allocatedStaff;
        const otherMembers = allocatedStaff.filter(s => s.id !== teamLead.id);
        return [teamLead, ...otherMembers];
    }, [teamLead, allocatedStaff]);


    const loadData = useCallback(() => {
        if (!companyId) return;
        setIsLoading(true);

        const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
        const currentCompany = allClients.find(c => c.id === companyId);
        setCompany(currentCompany || null);
        
        const tasksData: StaffTasks = JSON.parse(localStorage.getItem('staffTasks') || '{}');
        setAllTasks(tasksData);

        if (currentCompany) {
            const allStaffData: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            setAllStaff(allStaffData);
            
            const lead = allStaffData.find(s => s.id === currentCompany.assignedTeamLeadId);
            setTeamLead(lead || null);

            const allocated = allStaffData.filter(s => currentCompany.allocatedStaffIds?.includes(s.id));
            setAllocatedStaff(allocated);
        }

        setIsLoading(false);
    }, [companyId]);

    useEffect(() => {
        loadData();
    }, [loadData]);
    
    const handleStaffUpdate = (updatedStaff: StaffMember) => {
        const updatedList = allocatedStaff.map(s => s.id === updatedStaff.id ? updatedStaff : s);
        setAllocatedStaff(updatedList);
        
        const allStaffFromStorage: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const updatedAllStaff = allStaffFromStorage.map(s => s.id === updatedStaff.id ? updatedStaff : s);
        localStorage.setItem('hubStaff', JSON.stringify(updatedAllStaff));
    };
    
    const handleTasksUpdate = (staffId: string, updatedTasks: Task[]) => {
        if (!company) return;
        const newAllTasks = { ...allTasks, [staffId]: { ...allTasks[staffId], [company.id]: updatedTasks }};
        setAllTasks(newAllTasks);
        localStorage.setItem('staffTasks', JSON.stringify(newAllTasks));
    };

    const handleSaveAllocation = (companyId: string, allocatedIds: string[]) => {
        const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
        const updatedClients = allClients.map(c => c.id === companyId ? { ...c, allocatedStaffIds: allocatedIds } : c);
        localStorage.setItem('clients', JSON.stringify(updatedClients));
        loadData(); 
        toast({
            title: 'Staff Allocated',
            description: `Staff allocation for ${company?.name} has been updated.`
        });
    }

    const handleProjectUpdate = (updates: ProjectUpdate[]) => {
        if (!company) return;
        const updatedCompany = { ...company, projectUpdates: updates };
        setCompany(updatedCompany);
        const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
        const updatedClients = allClients.map(c => c.id === company.id ? updatedCompany : c);
        localStorage.setItem('clients', JSON.stringify(updatedClients));
        toast({ title: "Progress updated" });
    };

    if (isLoading) {
        return <div className="flex items-center justify-center h-full"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    if (!company) {
        return (
            <Card>
                <CardHeader><CardTitle>Company Not Found</CardTitle><CardDescription>The requested company could not be found.</CardDescription></CardHeader>
                <CardContent><Button asChild variant="outline"><Link href="/staff-dashboard/companies">Go Back</Link></Button></CardContent>
            </Card>
        )
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>Manage Project: {company.name}</CardTitle>
                            <CardDescription>Manage the staff and tasks for this project.</CardDescription>
                        </div>
                         <div className="flex items-center gap-2">
                            <Button variant="outline" asChild><Link href="/staff-dashboard/companies"><ArrowLeft className="mr-2 h-4 w-4" />Back to Companies</Link></Button>
                        </div>
                    </div>
                </CardHeader>
                 <CardContent className="space-y-6">
                     <ProjectUpdates company={company} onUpdate={handleProjectUpdate} />
                    <Card>
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle className="text-xl">Project Team</CardTitle>
                                <Button variant="outline" onClick={() => setIsAllocationOpen(true)}>Manage Team</Button>
                            </div>
                        </CardHeader>
                        <CardContent>
                             <Table>
                                <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Role</TableHead><TableHead>Rate</TableHead><TableHead>Weekly Cost</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                                {projectTeam.length > 0 ? (
                                    projectTeam.map(staff => (
                                        <Collapsible asChild key={staff.id}>
                                           <tbody className="border-b">
                                             <TableRow>
                                                <TableCell className="font-semibold">{staff.name}</TableCell>
                                                <TableCell><Badge variant={staff.isTeamLead ? 'default' : 'secondary'}>{staff.role}</Badge></TableCell>
                                                <TableCell className="font-mono">£{staff.rate.toFixed(2)}/hr</TableCell>
                                                <TableCell className="font-mono">£{(staff.timeLimits ? staff.timeLimits.reduce((acc, limit) => acc + (limit.startTime && limit.endTime ? (parse(limit.endTime, 'HH:mm', new Date()).getTime() - parse(limit.startTime, 'HH:mm', new Date()).getTime()) / 36e5 : 0), 0) * staff.rate : 0).toFixed(2)}/week</TableCell>
                                                <TableCell className="text-right">
                                                    <CollapsibleTrigger asChild>
                                                         <Button variant="outline" size="sm">
                                                            <Pencil className="mr-2 h-4 w-4" />
                                                            Manage
                                                        </Button>
                                                    </CollapsibleTrigger>
                                                </TableCell>
                                             </TableRow>
                                            <ProjectStaffRow 
                                                staff={staff} 
                                                tasks={allTasks[staff.id]?.[company.id] || []}
                                                onTasksUpdate={(updatedTasks) => handleTasksUpdate(staff.id, updatedTasks)}
                                                company={company}
                                            />
                                           </tbody>
                                        </Collapsible>
                                    ))
                                ) : (
                                    <TableBody><TableRow><TableCell colSpan={5} className="text-center h-24">No staff allocated to this project.</TableCell></TableRow></TableBody>
                                )}
                            </Table>
                             {projectTeam.map(staff => (
                                <RestrictionsManager 
                                    key={`restrictions-${staff.id}`} 
                                    staff={staff}
                                    onStaffUpdate={handleStaffUpdate} 
                                    company={company}
                                />
                            ))}
                        </CardContent>
                    </Card>
                </CardContent>
            </Card>
            <StaffAllocationDialog 
                open={isAllocationOpen}
                onOpenChange={setIsAllocationOpen}
                company={company}
                allStaff={allStaff}
                onSaveAllocation={handleSaveAllocation}
            />
        </div>
    );
}
