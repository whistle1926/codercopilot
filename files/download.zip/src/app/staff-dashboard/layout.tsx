

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ListChecks, Wallet, Building, ChevronsUpDown, Check, MessageSquare, CalendarClock, User, Users } from "lucide-react";
import { SidebarProvider, Sidebar, SidebarHeader, SidebarContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarSeparator } from "@/components/ui/sidebar";
import { UserNav } from "@/components/user-nav";
import { CoderCoPilotLogo } from '@/components/icons';
import { useState, useEffect, useMemo, useCallback } from "react";
import type { StaffMember, Task, Client } from "@/lib/types";
import { initialStaff, clients as initialClients } from "@/lib/data";
import { differenceInMilliseconds, parse, format } from "date-fns";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const navItems = [
  { href: '/staff-dashboard/tasks', icon: ListChecks, label: 'My Tasks' },
  { href: '/staff-dashboard/messages', icon: MessageSquare, label: 'Messages' },
  { href: '/staff-dashboard/profile', icon: User, label: 'My Profile' },
];

const managerNavItems = [
  { href: '/staff-dashboard/companies', icon: Building, label: 'Assigned Companies' },
  { href: '/staff-dashboard/staff', icon: Users, label: 'Available Staff' },
]

function EarningsBreakdownDialog({
    open,
    onOpenChange,
    earnings,
    companies,
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    earnings: { companyId: string; amount: number; breakdown: Task[] }[];
    companies: Client[];
}) {

    const totalEarnings = earnings.reduce((acc, e) => acc + e.amount, 0);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Earnings Breakdown</DialogTitle>
                    <DialogDescription>
                        A summary of your earnings from all companies.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto pr-4">
                     <div className="p-4 rounded-lg bg-muted text-center">
                        <p className="text-sm font-medium text-muted-foreground">Total Earnings Due</p>
                        <p className="text-3xl font-bold">£{totalEarnings.toFixed(2)}</p>
                    </div>
                    {earnings.map(({ companyId, amount, breakdown }) => {
                        const company = companies.find(c => c.id === companyId);
                        if (!company) return null;
                        return (
                            <Card key={companyId}>
                                <CardHeader>
                                    <div className="flex justify-between items-center">
                                        <CardTitle>{company.name}</CardTitle>
                                        <span className="text-xl font-bold font-mono">£{amount.toFixed(2)}</span>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <Table>
                                        <TableHeader>
                                            <TableRow>
                                                <TableHead>Date</TableHead>
                                                <TableHead>Task</TableHead>
                                                <TableHead className="text-right">Amount</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {breakdown.map(task => (
                                                <TableRow key={task.id}>
                                                    <TableCell>{task.completionDate ? format(new Date(task.completionDate), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                                    <TableCell>{task.title}</TableCell>
                                                    <TableCell className="text-right font-mono">£{task.cost.toFixed(2)}</TableCell>
                                                </TableRow>
                                            ))}
                                             {breakdown.length === 0 && (
                                                <TableRow>
                                                    <TableCell colSpan={3} className="text-center text-muted-foreground">No earnings recorded for this company yet.</TableCell>
                                                </TableRow>
                                            )}
                                        </TableBody>
                                    </Table>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            </DialogContent>
        </Dialog>
    )
}

function StaffDashboardLayoutContent({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const [staffMember, setStaffMember] = useState<StaffMember | null>(null);
    const [clients, setClients] = useState<Client[]>([]);
    const [activeCompanyId, setActiveCompanyId] = useState<string | null>(null);
    const [allTasks, setAllTasks] = useState<Record<string, Record<string, Task[]>>>({});
    const [isEarningsOpen, setIsEarningsOpen] = useState(false);

    const loadData = useCallback(() => {
        const staffId = sessionStorage.getItem('loggedInStaffId');
        if (staffId) {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const member = allStaff.find(s => s.id === staffId);
            setStaffMember(member || null);

            const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
            // Filter clients to only those the staff member is hired by
            const hiredClients = allClients.filter(c => member?.hiredBy?.includes(c.id));
            setClients(hiredClients);

            const tasksData: Record<string, Record<string, Task[]>> = JSON.parse(localStorage.getItem('staffTasks') || '{}');
            setAllTasks(tasksData);

            const storedCompanyId = sessionStorage.getItem(`staff_${staffId}_activeCompany`);
            if (storedCompanyId && member?.hiredBy?.includes(storedCompanyId)) {
                setActiveCompanyId(storedCompanyId);
            } else if (member?.hiredBy && member.hiredBy.length > 0) {
                setActiveCompanyId(member.hiredBy[0]);
            } else {
                setActiveCompanyId(null);
            }
        }
    }, []);

    useEffect(() => {
        loadData();
        window.addEventListener('storage', loadData);
        return () => window.removeEventListener('storage', loadData);
    }, [loadData]);
    
    const earningsBreakdown = useMemo(() => {
        if (!staffMember || !staffMember.hiredBy) return [];
        
        const hiredByArray = Array.isArray(staffMember.hiredBy) ? staffMember.hiredBy : [staffMember.hiredBy];

        return hiredByArray.map(companyId => {
            const companyTasks = allTasks[staffMember.id]?.[companyId] || [];
            const paidTasks = companyTasks.filter(task => (task.status === 'Approved' || task.status === 'Paid'));
            const totalAmount = paidTasks.reduce((acc, task) => acc + (task.cost || 0), 0);
            return {
                companyId,
                amount: totalAmount,
                breakdown: paidTasks,
            };
        });
    }, [staffMember, allTasks]);
    
    const totalEarningsDue = useMemo(() => {
        return earningsBreakdown.reduce((acc, company) => acc + company.amount, 0);
    }, [earningsBreakdown]);

    const hiredByCompanies = useMemo(() => {
        if (!staffMember || !staffMember.hiredBy) return [];
        return clients.filter(client => staffMember.hiredBy?.includes(client.id));
    }, [staffMember, clients]);

    const handleCompanySelect = (companyId: string) => {
        setActiveCompanyId(companyId);
        if (staffMember) {
            sessionStorage.setItem(`staff_${staffMember.id}_activeCompany`, companyId);
        }
        // Force a reload of the tasks page or pass state down
        window.dispatchEvent(new CustomEvent('staffCompanyChanged', { detail: companyId }));
    };
    
    return (
        <>
            <Sidebar>
                <SidebarHeader>
                    <div className="flex items-center gap-2">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        <CoderCoPilotLogo className="h-6 w-6" />
                        </div>
                        <h2 className="text-lg font-semibold">{staffMember?.isTeamLead ? 'Team Manager' : 'Staff Portal'}</h2>
                    </div>
                </SidebarHeader>
                <SidebarContent>
                    {hiredByCompanies.length > 0 && (
                        <div className="p-2 space-y-2">
                            <label className="px-2 text-xs font-semibold text-muted-foreground">Companies</label>
                            <div className="flex flex-col gap-1">
                                {hiredByCompanies.map(company => (
                                    <Button
                                        key={company.id}
                                        variant={activeCompanyId === company.id ? "secondary" : "ghost"}
                                        className="w-full justify-start"
                                        onClick={() => handleCompanySelect(company.id)}
                                    >
                                        <Building className="mr-2 h-4 w-4" />
                                        <span className="truncate">{company.name}</span>
                                    </Button>
                                ))}
                            </div>
                        </div>
                    )}
                    <SidebarMenu className="p-2">
                        {navItems.map((item) => (
                        <SidebarMenuItem key={item.href}>
                            <SidebarMenuButton
                            asChild
                            isActive={pathname.startsWith(item.href)}
                            tooltip={item.label}
                            >
                            <Link href={item.href}>
                                <item.icon />
                                <span>{item.label}</span>
                            </Link>
                            </SidebarMenuButton>
                        </SidebarMenuItem>
                        ))}
                    </SidebarMenu>
                     {staffMember?.isTeamLead && (
                        <>
                            <SidebarSeparator />
                            <div className="p-2 space-y-2">
                                <label className="px-2 text-xs font-semibold text-muted-foreground">Manager Tools</label>
                                 <SidebarMenu className="p-0">
                                    {managerNavItems.map((item) => (
                                    <SidebarMenuItem key={item.href}>
                                        <SidebarMenuButton
                                        asChild
                                        isActive={pathname.startsWith(item.href)}
                                        tooltip={item.label}
                                        >
                                        <Link href={item.href}>
                                            <item.icon />
                                            <span>{item.label}</span>
                                        </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                    ))}
                                </SidebarMenu>
                            </div>
                        </>
                    )}
                </SidebarContent>
            </Sidebar>
             <main className="flex-1">
                <header className="flex h-14 items-center justify-between gap-4 border-b bg-background px-4 sm:px-6">
                    <div>
                        {staffMember && (
                            <div className="font-semibold text-lg">
                                Welcome, {staffMember.name} - <span className="text-muted-foreground">{staffMember.role}</span>
                            </div>
                        )}
                    </div>
                    <div className="flex items-center gap-4">
                        {staffMember && staffMember.showPricing && (
                            <Button variant="ghost" className="flex items-center gap-2 text-sm font-semibold p-2 rounded-md bg-muted" onClick={() => setIsEarningsOpen(true)}>
                                <Wallet className="h-5 w-5 text-primary" />
                                <span className="whitespace-nowrap">Earnings Due: <span className="font-mono">£{totalEarningsDue.toFixed(2)}</span></span>
                            </Button>
                        )}
                        <UserNav />
                    </div>
                </header>
                <div className="p-4 sm:p-6">{children}</div>
            </main>
            <EarningsBreakdownDialog
                open={isEarningsOpen}
                onOpenChange={setIsEarningsOpen}
                earnings={earningsBreakdown}
                companies={clients}
            />
        </>
    );
}

export default function StaffDashboardLayout({ children }: { children: React.ReactNode }) {
    return (
        <SidebarProvider>
            <StaffDashboardLayoutContent>{children}</StaffDashboardLayoutContent>
        </SidebarProvider>
    );
}
