

"use client";

import { useState, useEffect, useCallback } from 'react';
import type { StaffMember, Client } from '@/lib/types';
import { initialStaff, clients as initialClientsData } from '@/lib/data';
import { ChatInterface } from './chat-interface';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useSearchParams } from 'next/navigation';

export default function MessagesClientPage() {
    const searchParams = useSearchParams();
    const companyId = searchParams.get('companyId');
    const [staffId, setStaffId] = useState<string | null>(null);

    const [staffMember, setStaffMember] = useState<StaffMember | null>(null);
    const [hiredByCompanies, setHiredByCompanies] = useState<Client[]>([]);
    const [selectedCompany, setSelectedCompany] = useState<Client | null>(null);

    const loadData = useCallback(() => {
        const id = sessionStorage.getItem('loggedInStaffId');
        setStaffId(id);

        if (id) {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const member = allStaff.find(s => s.id === id);
            setStaffMember(member || null);

            const allClients: Client[] = JSON.parse(localStorage.getItem('clients') || '[]');
            
            const hiredCompanies = allClients.filter(c => member?.hiredBy?.includes(c.id));
            setHiredByCompanies(hiredCompanies);

            const companyToSelectId = companyId || sessionStorage.getItem(`staff_${id}_activeCompany`);

            if (companyToSelectId) {
                const company = hiredCompanies.find(c => c.id === companyToSelectId);
                setSelectedCompany(company || (hiredCompanies.length > 0 ? hiredCompanies[0] : null));
            } else if (hiredCompanies.length > 0) {
                setSelectedCompany(hiredCompanies[0]);
            }
        }
    }, [companyId]);

    useEffect(() => {
        loadData();
        window.addEventListener('storage', loadData);
        return () => window.removeEventListener('storage', loadData);
    }, [loadData]);


    return (
        <div className="flex flex-col h-full space-y-6">
             <Card>
                <CardHeader>
                    <CardTitle>Messages</CardTitle>
                    <CardDescription>Communicate with your assigned companies.</CardDescription>
                </CardHeader>
            </Card>
            <div className="flex-grow">
                <ChatInterface 
                    companyList={hiredByCompanies} 
                    selectedCompany={selectedCompany}
                    onSelectCompany={setSelectedCompany}
                    staffMember={staffMember}
                />
            </div>
        </div>
    );
}
