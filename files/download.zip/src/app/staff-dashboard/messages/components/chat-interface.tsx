
"use client";

import { useState, useRef, useEffect } from 'react';
import type { Client, StaffMember, ChatMessage, UserStatus } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { initialConversations } from '@/lib/data';
import { Badge } from '@/components/ui/badge';

const statusColors: Record<UserStatus, string> = {
    Online: 'bg-green-500',
    Offline: 'bg-gray-500',
    Busy: 'bg-yellow-500',
};

export function ChatInterface({ 
    companyList, 
    selectedCompany, 
    onSelectCompany, 
    staffMember 
}: { 
    companyList: Client[], 
    selectedCompany: Client | null, 
    onSelectCompany: (company: Client) => void,
    staffMember: StaffMember | null 
}) {
  const [conversations, setConversations] = useState<Record<string, ChatMessage[]>>({});
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const getConversationKey = (staffId: string, clientId: string) => `staff-${staffId}_client-${clientId}`;
  
  useEffect(() => {
    const loadConversations = () => {
      try {
          const storedConversations = localStorage.getItem('chatConversations');
          if (storedConversations) {
              setConversations(JSON.parse(storedConversations));
          } else {
              setConversations(initialConversations);
          }
      } catch (error) {
          console.error("Failed to load conversations from localStorage", error);
          setConversations(initialConversations);
      }
    };

    loadConversations();
    window.addEventListener('storage', loadConversations);
    return () => window.removeEventListener('storage', loadConversations);
  }, []);

  const saveConversations = (newConversations: Record<string, ChatMessage[]>) => {
    setConversations(newConversations);
    localStorage.setItem('chatConversations', JSON.stringify(newConversations));
    window.dispatchEvent(new StorageEvent('storage', { key: 'chatConversations', newValue: JSON.stringify(newConversations) }));
  };

  const conversationKey = selectedCompany && staffMember ? getConversationKey(staffMember.id, selectedCompany.id) : null;
  const currentConversation = conversationKey ? conversations[conversationKey] || [] : [];
  
  const filteredCompanyList = companyList.filter(company => company.name.toLowerCase().includes(searchTerm.toLowerCase()));

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversation]);

   useEffect(() => {
    // Mark messages as read when a conversation is opened
    if (conversationKey && conversations[conversationKey]) {
      let hasUnread = false;
      const updatedConversation = conversations[conversationKey].map(msg => {
        if (msg.sender === 'user' && !msg.read) {
          hasUnread = true;
          return { ...msg, read: true };
        }
        return msg;
      });

      if (hasUnread) {
        saveConversations({
          ...conversations,
          [conversationKey]: updatedConversation,
        });
      }
    }
  }, [conversationKey, conversations]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !conversationKey || !staffMember) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: staffMember.id,
      sender: 'staff',
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
    };
    
    const updatedConversation = [...currentConversation, newMsg];
    saveConversations({
      ...conversations,
      [conversationKey]: updatedConversation,
    });
    setNewMessage('');
  };

  const getCompanyStatus = (company: Client): UserStatus => {
      if (company.status === 'Active') return 'Online';
      if (company.status === 'Inactive') return 'Offline';
      return 'Offline';
  }

  return (
    <div className="flex h-full border rounded-lg">
      <div className="w-1/3 border-r flex flex-col">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search companies..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <ScrollArea className="flex-1">
          {filteredCompanyList.map(company => {
            const convKey = staffMember ? getConversationKey(staffMember.id, company.id) : null;
            const conversation = convKey ? conversations[convKey] || [] : [];
            const lastMessage = conversation.length > 0 ? conversation[conversation.length - 1] : null;
            const hasUnread = conversation.some(msg => msg.sender === 'user' && !msg.read);

            return (
            <div
              key={company.id}
              className={cn(
                "flex items-center gap-4 p-4 cursor-pointer hover:bg-muted",
                selectedCompany?.id === company.id && 'bg-muted'
              )}
              onClick={() => onSelectCompany(company)}
            >
              <div className="relative">
                <Avatar>
                   <AvatarFallback>{company.name.split(' ').map(n => n[0]).join('').substring(0,2)}</AvatarFallback>
                </Avatar>
                <span className={cn(
                    "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-background",
                    statusColors[getCompanyStatus(company)]
                )} />
              </div>
              <div className="flex-1 overflow-hidden flex justify-between items-center">
                <div>
                    <p className="font-semibold">{company.name}</p>
                    <p className="text-sm text-muted-foreground truncate">
                        {lastMessage?.text || 'No messages yet'}
                    </p>
                </div>
                {hasUnread && <div className="h-2.5 w-2.5 rounded-full bg-blue-500 shrink-0" />}
              </div>
            </div>
          )})}
        </ScrollArea>
      </div>

      <div className="w-2/3 flex flex-col">
        {selectedCompany && staffMember ? (
          <>
            <div className="p-4 border-b flex items-center gap-4">
              <div className="relative">
                <Avatar>
                   <AvatarFallback>{selectedCompany.name.split(' ').map(n => n[0]).join('').substring(0,2)}</AvatarFallback>
                </Avatar>
                 <span className={cn(
                    "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-background",
                    statusColors[getCompanyStatus(selectedCompany)]
                )} />
              </div>
              <div>
                  <p className="font-semibold">{selectedCompany.name}</p>
                  <p className="text-sm text-muted-foreground">Main contact: {selectedCompany.mainContactPerson}</p>
              </div>
            </div>

            <ScrollArea className="flex-1 p-6 space-y-4 bg-gray-50 dark:bg-gray-900/50">
              {currentConversation.map(msg => (
                <div key={msg.id} className={cn("flex items-end gap-2", msg.sender === 'staff' && 'justify-end')}>
                  {msg.sender === 'user' && (
                    <Avatar className="h-8 w-8">
                       <AvatarFallback>{selectedCompany.mainContactPerson.charAt(0)}</AvatarFallback>
                    </Avatar>
                  )}
                  <div className={cn(
                    "p-3 rounded-lg max-w-md",
                    msg.sender === 'staff' ? 'bg-primary text-primary-foreground' : 'bg-muted'
                  )}>
                    <p>{msg.text}</p>
                    <p className={cn("text-xs mt-1", msg.sender === 'staff' ? 'text-primary-foreground/70' : 'text-muted-foreground')}>{msg.timestamp}</p>
                  </div>
                   {msg.sender === 'staff' && (
                    <Avatar className="h-8 w-8">
                       <AvatarImage src={staffMember.avatarUrl} />
                       <AvatarFallback>{staffMember.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
               <div ref={messagesEndRef} />
            </ScrollArea>

            <div className="p-4 border-t">
              <form onSubmit={handleSendMessage} className="flex items-center gap-4">
                <Input 
                  placeholder="Type a message..." 
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
                <Button type="submit" disabled={!newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <p>Select a company to start chatting.</p>
          </div>
        )}
      </div>
    </div>
  );
}
