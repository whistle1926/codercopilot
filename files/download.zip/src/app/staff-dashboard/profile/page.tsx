

"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import type { StaffMember, Skill } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { PlusCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

function SkillEditDialog({
  open,
  onOpenChange,
  skill: initialSkill,
  onSave,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  skill: Skill | null;
  onSave: (skill: Skill) => void;
  onDelete: () => void;
}) {
  const [skill, setSkill] = useState<Skill | null>(initialSkill);

  useEffect(() => {
    setSkill(initialSkill);
  }, [initialSkill]);

  if (!open || !skill) return null;

  const handleSave = () => {
    onSave(skill);
    onOpenChange(false);
  };
  
  const handleDeleteClick = () => {
      onDelete();
      onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initialSkill?.name ? 'Edit Skill' : 'Add New Skill'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="skill-name">Skill Name</Label>
            <Input
              id="skill-name"
              value={skill.name}
              onChange={(e) => setSkill({ ...skill, name: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="skill-years">Years of Experience</Label>
                <Input
                  id="skill-years"
                  type="number"
                  value={skill.years || ''}
                  onChange={(e) => setSkill({ ...skill, years: parseInt(e.target.value) || 0 })}
                />
            </div>
            <div className="space-y-2">
              <Label htmlFor="skill-level">Proficiency Level</Label>
              <Select
                value={skill.level}
                onValueChange={(value: Skill['level']) => setSkill({ ...skill, level: value })}
              >
                <SelectTrigger id="skill-level">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Intermediate">Intermediate</SelectItem>
                  <SelectItem value="Advanced">Advanced</SelectItem>
                  <SelectItem value="Expert">Expert</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter className="justify-between">
            {initialSkill?.name && (
                <Button variant="destructive" onClick={handleDeleteClick}>Delete Skill</Button>
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save Skill</Button>
            </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


export default function StaffProfilePage() {
    const [staff, setStaff] = useState<StaffMember | null>(null);
    const { toast } = useToast();
    const [editingSkill, setEditingSkill] = useState<{skill: Skill | null, type: 'technicalSkills' | 'softSkills', index: number | null}>({ skill: null, type: 'technicalSkills', index: null });

    const loadStaffData = useCallback(() => {
        const staffId = sessionStorage.getItem('loggedInStaffId');
        if (staffId) {
            const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
            const currentStaff = allStaff.find(s => s.id === staffId);
            setStaff(currentStaff || null);
        }
    }, []);

    useEffect(() => {
        loadStaffData();
    }, [loadStaffData]);

    const handleInputChange = (field: keyof StaffMember, value: any) => {
        setStaff(prev => {
            if (!prev) return null;
            return { ...prev, [field]: value };
        });
    };

    const openSkillEditor = (skill: Skill | null, type: 'technicalSkills' | 'softSkills', index: number | null = null) => {
        setEditingSkill({ skill: skill ? {...skill} : { name: '', level: 'Intermediate', years: 0 }, type, index });
    };

    const handleSaveSkill = (updatedSkill: Skill) => {
        setStaff(prev => {
            if (!prev) return null;
            const { type, index } = editingSkill;
            const newSkills = [...(prev[type] || [])];
            if (index !== null) { // Editing existing skill
                newSkills[index] = updatedSkill;
            } else { // Adding new skill
                newSkills.push(updatedSkill);
            }
            return { ...prev, [type]: newSkills };
        });
    };

    const handleDeleteSkill = () => {
         setStaff(prev => {
            if (!prev) return null;
            const { type, index } = editingSkill;
            if (index === null) return prev; // Should not happen
            const newSkills = (prev[type] || []).filter((_, i) => i !== index);
            return { ...prev, [type]: newSkills };
        });
    };

    const handleSaveChanges = () => {
        if (!staff) return;

        const allStaff: StaffMember[] = JSON.parse(localStorage.getItem('hubStaff') || '[]');
        const updatedStaffList = allStaff.map(s => s.id === staff.id ? staff : s);
        localStorage.setItem('hubStaff', JSON.stringify(updatedStaffList));
        toast({
            title: 'Profile Updated',
            description: 'Your profile has been successfully updated.',
        });
    };

    const SkillEditorSection = ({ title, skillType }: { title: string, skillType: 'technicalSkills' | 'softSkills' }) => (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{title}</CardTitle>
                 <Button type="button" size="sm" variant="outline" onClick={() => openSkillEditor(null, skillType, null)}>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add Skill
                </Button>
            </CardHeader>
            <CardContent className="space-y-2">
                {(staff?.[skillType] || []).map((skill, index) => (
                     <div key={index} className="flex items-center gap-2 rounded-md p-2 bg-muted hover:bg-muted/80 cursor-pointer" onClick={() => openSkillEditor(skill, skillType, index)}>
                         <span className="flex-1 font-medium">{skill.name}</span>
                         <span className="text-sm text-muted-foreground">{skill.years} yrs</span>
                         <Badge variant="secondary">{skill.level}</Badge>
                    </div>
                ))}
                {(staff?.[skillType] || []).length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">No {title.toLowerCase()} added.</p>
                )}
            </CardContent>
        </Card>
    );

    if (!staff) {
        return <div>Loading profile...</div>;
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>My Profile</CardTitle>
                    <CardDescription>Manage your professional information that companies see.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>About Me</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="about">Your Bio</Label>
                                <Textarea 
                                    id="about" 
                                    value={staff.about || ''}
                                    onChange={(e) => handleInputChange('about', e.target.value)}
                                    rows={5}
                                    placeholder="Tell companies about your experience, expertise, and what makes you a great hire."
                                />
                            </div>
                            {staff.showPricing && (
                                <div className="space-y-2">
                                    <Label htmlFor="rate">Your Expected Hourly Rate (£)</Label>
                                    <Input
                                        id="rate"
                                        type="number"
                                        value={staff.rate}
                                        onChange={(e) => handleInputChange('rate', parseFloat(e.target.value) || 0)}
                                        className="w-48"
                                        placeholder="e.g., 50"
                                    />
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    <div className="grid md:grid-cols-2 gap-6">
                        <SkillEditorSection title="Technical Skills" skillType="technicalSkills" />
                        <SkillEditorSection title="Soft Skills" skillType="softSkills" />
                    </div>

                </CardContent>
                <CardFooter>
                    <Button onClick={handleSaveChanges}>Save Changes</Button>
                </CardFooter>
            </Card>

            <SkillEditDialog 
                open={!!editingSkill.skill}
                onOpenChange={() => setEditingSkill({ skill: null, type: 'technicalSkills', index: null })}
                skill={editingSkill.skill}
                onSave={handleSaveSkill}
                onDelete={handleDeleteSkill}
            />
        </div>
    );
}
