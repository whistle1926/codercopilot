import type { SVGProps } from "react";

export function CoderCoPilotLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 280 40"
      fill="none"
    >
        <text x="50%" y="30" fontFamily="Inter, sans-serif" fontSize="30" fontWeight="bold" fill="currentColor" textAnchor="middle">
            Coder Co-Pilot
        </text>
    </svg>
  );
}
