
"use client";

import { useState, useEffect } from 'react';
import { format } from 'date-fns';

export function Clock() {
  const [time, setTime] = useState<Date | null>(null);

  useEffect(() => {
    // Set the initial time on the client
    setTime(new Date());

    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  if (time === null) {
      // Render a placeholder or nothing on the server and initial client render
      return null;
  }

  return (
    <div className="hidden md:flex items-center gap-2 text-sm font-medium text-muted-foreground">
      <span>{format(time, 'dd MMM yyyy,')}</span>
      <span className="font-mono">{format(time, 'HH:mm:ss')}</span>
    </div>
  );
}
