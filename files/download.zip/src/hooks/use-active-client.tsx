

"use client";

import { createContext, useContext, useState, ReactNode, useMemo, useEffect, useCallback } from 'react';
import type { Client } from '@/lib/types';
import { clients as initialClientsData } from '@/lib/data';


interface ActiveClientContextType {
    activeClient: Client | null;
    setActiveClient: (client: Client | null) => void;
    isClientInitialised: boolean;
}

const ActiveClientContext = createContext<ActiveClientContextType | undefined>(undefined);

export function ActiveClientProvider({ children }: { children: ReactNode }) {
    const [activeClient, setActiveClientState] = useState<Client | null>(null);
    const [isClientInitialised, setIsClientInitialised] = useState(false);

    useEffect(() => {
        // This effect should only run once on the client to initialize state from sessionStorage
        if (typeof window !== 'undefined') {
            try {
                let allClients: Client[] = [];
                const storedClients = sessionStorage.getItem('clients');

                if (storedClients) {
                    allClients = JSON.parse(storedClients);
                } else {
                    // If no clients in storage, this is a fresh session.
                    // Load the initial data AND save it back to sessionStorage.
                    allClients = initialClientsData as Client[];
                    sessionStorage.setItem('clients', JSON.stringify(allClients));
                }

                const storedClientId = sessionStorage.getItem('activeClientId');
                if (storedClientId) {
                    const client = allClients.find(c => c.id === storedClientId);
                    if (client) {
                        setActiveClientState(client);
                    } else {
                        // If client ID is invalid, clear it
                        sessionStorage.removeItem('activeClientId');
                        setActiveClientState(null);
                    }
                } else {
                    // No client ID means super admin or not logged in
                    setActiveClientState(null);
                }
            } catch (error) {
                console.error("Failed to parse clients from sessionStorage", error);
                // On error, default to logged out state
                setActiveClientState(null);
            } finally {
                setIsClientInitialised(true);
            }
        }
    }, []);

    const setActiveClient = useCallback((client: Client | null) => {
        setActiveClientState(client);
        if (client) {
            sessionStorage.setItem('activeClientId', client.id);
        } else {
            sessionStorage.removeItem('activeClientId');
        }
    }, []);
    
    const value = useMemo(() => ({ activeClient, setActiveClient, isClientInitialised }), [activeClient, setActiveClient, isClientInitialised]);

    return (
        <ActiveClientContext.Provider value={value}>
            {children}
        </ActiveClientContext.Provider>
    );
}

export function useActiveClient() {
    const context = useContext(ActiveClientContext);
    if (context === undefined) {
        throw new Error('useActiveClient must be used within an ActiveClientProvider');
    }
    return context;
}
